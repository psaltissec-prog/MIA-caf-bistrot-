from __future__ import annotations

import csv
import io
from dataclasses import replace

from conftest import ADMIN_PASSWORD, ORIGIN
from fastapi.testclient import TestClient

from mia.app import create_app
from mia.security import hash_password, verify_password


def test_password_hash_is_salted_and_does_not_store_plaintext():
    password = "A long password unique for this test 73!"
    first = hash_password(password)
    second = hash_password(password)
    assert first != second
    assert password not in first
    assert verify_password(password, first)
    assert not verify_password("incorrect", first)
    assert not verify_password(password, "malformed hash")


def test_staff_endpoints_require_login(client):
    for path in ("/api/admin/session", "/api/admin/orders", "/api/admin/rejected.csv"):
        response = client.get(path)
        assert response.status_code in (401, 403), path


def test_invalid_credentials_do_not_create_session(client):
    response = client.post(
        "/api/admin/login", json={"username": "admin", "password": "incorrect"},
        headers={"Origin": ORIGIN},
    )
    assert response.status_code == 401
    assert client.get("/api/admin/orders").status_code in (401, 403)


def test_login_cookie_and_logout(admin):
    response = admin.post(
        "/api/admin/login", json={"username": "admin", "password": ADMIN_PASSWORD},
        headers={"Origin": ORIGIN},
    )
    cookie = response.headers["set-cookie"].lower()
    assert "httponly" in cookie
    assert "samesite=strict" in cookie
    assert admin.get("/api/admin/session").status_code == 200
    assert admin.post("/api/admin/logout", headers={"Origin": ORIGIN}).status_code in (200, 204)
    assert admin.get("/api/admin/orders").status_code in (401, 403)


def test_cross_origin_login_and_checkout_are_blocked(client, payload, order_headers):
    response = client.post(
        "/api/admin/login", json={"username": "admin", "password": ADMIN_PASSWORD},
        headers={"Origin": "https://attacker.example"},
    )
    assert response.status_code == 403
    response = client.post(
        "/api/orders", json=payload,
        headers={**order_headers, "Origin": "https://attacker.example"},
    )
    assert response.status_code == 403


def test_cross_origin_staff_mutation_is_blocked(admin, order):
    response = admin.post(
        f"/api/admin/orders/{order['order']['id']}/transition",
        json={"status": "ACCEPTED"}, headers={"Origin": "https://attacker.example"},
    )
    assert response.status_code == 403
    assert admin.get("/api/admin/orders").json()["orders"][0]["status"] == "PENDING"


def test_login_rate_limit_blocks_repeated_wrong_passwords(client):
    statuses = []
    for _ in range(15):
        response = client.post(
            "/api/admin/login", json={"username": "admin", "password": "incorrect"},
            headers={"Origin": ORIGIN},
        )
        statuses.append(response.status_code)
        if response.status_code == 429:
            break
    assert statuses[0] == 401
    assert 429 in statuses


def test_csv_neutralizes_spreadsheet_formulas(admin, payload, order_headers):
    dangerous_name = '=HYPERLINK("https://attacker.example")'
    payload["customer_name"] = dangerous_name
    created = admin.post("/api/orders", json=payload, headers=order_headers)
    assert created.status_code == 201, created.text
    order_id = created.json()["order"]["id"]
    rejected = admin.post(
        f"/api/admin/orders/{order_id}/transition", json={"status": "REJECTED"},
        headers={"Origin": ORIGIN},
    )
    assert rejected.status_code == 200
    response = admin.get("/api/admin/rejected.csv")
    assert response.status_code == 200
    assert "text/csv" in response.headers["content-type"]
    rows = list(csv.reader(io.StringIO(response.text.lstrip("\ufeff"))))
    assert len(rows) == 2
    assert dangerous_name not in rows[1]
    assert any(cell.lstrip("'\t") == dangerous_name for cell in rows[1])
    assert not any(cell.startswith(("=", "+", "-", "@")) for cell in rows[1])


def test_expired_orders_reconciled_after_restart(settings, clock, client, order):
    clock.advance(301)
    with TestClient(create_app(settings, clock=clock), base_url=ORIGIN) as restarted:
        response = restarted.get(
            f"/api/orders/{order['order']['id']}",
            headers={"Authorization": f"Bearer {order['access_token']}"},
        )
        assert response.status_code == 200
        assert response.json()["order"]["status"] == "REJECTED"
        assert response.json()["order"]["rejection_reason"] == "AUTO_TIMEOUT_5_MIN"


def test_manual_rejection_survives_restart(settings, clock, admin, order):
    response = admin.post(
        f"/api/admin/orders/{order['order']['id']}/transition",
        json={"status": "REJECTED"}, headers={"Origin": ORIGIN},
    )
    assert response.status_code == 200
    with TestClient(create_app(settings, clock=clock), base_url=ORIGIN) as restarted:
        saved = restarted.get(
            f"/api/orders/{order['order']['id']}",
            headers={"Authorization": f"Bearer {order['access_token']}"},
        ).json()["order"]
        assert saved["status"] == "REJECTED"
        assert saved["rejection_reason"] == "MANUAL"


def test_health_is_minimal_and_responses_not_cached(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    lower = response.text.lower()
    for forbidden in ("password", "sqlite", "customer_name", "access_token", "secret"):
        assert forbidden not in lower
    assert response.headers.get("x-content-type-options") == "nosniff"
    assert "no-store" in response.headers.get("cache-control", "")


def test_non_ascii_username_is_invalid_credentials_not_server_error(client):
    response = client.post(
        "/api/admin/login", json={"username": "διαχειριστής", "password": ADMIN_PASSWORD},
        headers={"Origin": ORIGIN},
    )
    assert response.status_code == 401


def test_malformed_host_is_bad_request_not_server_error(client):
    response = client.get("/api/health", headers={"Host": "["})
    assert response.status_code == 400


def test_non_ascii_bearer_is_unauthorized_not_server_error(client, order):
    response = client.get(
        f"/api/orders/{order['order']['id']}",
        headers=[(b"authorization", b"Bearer invalid-caf\xe9")],
    )
    assert response.status_code == 404


def test_oversized_request_is_rejected_before_validation(client, payload, order_headers):
    payload["notes"] = "x" * (20 * 1024)
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 413


def test_validation_errors_do_not_echo_personal_information(client, payload, order_headers):
    unique_private_value = "private-customer-phone-incorrect-976123"
    payload["phone"] = unique_private_value
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 422
    assert unique_private_value not in response.text
    assert payload["customer_name"] not in response.text


def test_password_rotation_invalidates_existing_sessions(settings, clock, admin):
    rotated = replace(settings, admin_password_hash=hash_password("A different admin password 95!"))
    with TestClient(create_app(rotated, clock=clock), base_url=ORIGIN) as restarted:
        restarted.cookies.update(admin.cookies)
        response = restarted.get("/api/admin/orders")
        assert response.status_code == 401


def test_expired_staff_session_is_not_accepted(admin, clock, settings):
    clock.advance(settings.session_seconds)
    response = admin.get("/api/admin/orders")
    assert response.status_code == 401
