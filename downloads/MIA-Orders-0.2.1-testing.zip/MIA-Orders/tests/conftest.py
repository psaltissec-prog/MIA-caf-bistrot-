from __future__ import annotations

import uuid
from dataclasses import dataclass

import pytest
from fastapi.testclient import TestClient

from mia.app import create_app
from mia.config import Settings
from mia.security import hash_password

ADMIN_PASSWORD = "Correct horse battery staple 84!"
ORIGIN = "http://testserver"


@dataclass
class Clock:
    value: float = 1_800_000_000

    def __call__(self) -> float:
        return self.value

    def advance(self, seconds: float) -> None:
        self.value += seconds


@pytest.fixture(scope="session")
def password_hash():
    return hash_password(ADMIN_PASSWORD)


@pytest.fixture
def clock():
    return Clock()


@pytest.fixture
def settings(tmp_path, password_hash):
    return Settings(
        db_path=tmp_path / "orders.sqlite3",
        admin_password_hash=password_hash,
        public_origin=ORIGIN,
    )


@pytest.fixture
def client(settings, clock):
    with TestClient(create_app(settings, clock=clock), base_url=ORIGIN) as instance:
        yield instance


@pytest.fixture
def payload(client):
    products = client.get("/api/menu").json()["products"]
    product = next(p for p in products if p["available"])
    return {
        "customer_name": "Μαρία Παπαδοπούλου",
        "phone": "+306912345678",
        "fulfillment": "pickup",
        "notes": "Χωρίς καλαμάκι",
        "items": [{"product_id": product["id"], "quantity": 2, "notes": ""}],
    }


@pytest.fixture
def order_headers():
    return {"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4())}


@pytest.fixture
def order(client, payload, order_headers):
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 201, response.text
    return response.json()


@pytest.fixture
def admin(client):
    response = client.post(
        "/api/admin/login",
        json={"username": "admin", "password": ADMIN_PASSWORD},
        headers={"Origin": ORIGIN},
    )
    assert response.status_code == 200, response.text
    return client
