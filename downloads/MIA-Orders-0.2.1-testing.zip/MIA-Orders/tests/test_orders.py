from __future__ import annotations

import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy

import pytest
from conftest import ORIGIN


def token_headers(order):
    return {"Authorization": f"Bearer {order['access_token']}"}


def test_menu_is_explicitly_demo_and_prices_are_integer_cents(client):
    response = client.get("/api/menu")
    assert response.status_code == 200
    menu = response.json()
    assert menu["store"]["demo"] is True
    assert menu["store"]["delivery_enabled"] is False
    assert menu["store"]["currency"] == "EUR"
    assert menu["products"]
    for product in menu["products"]:
        assert isinstance(product["price_cents"], int)
        assert product["price_cents"] > 0
        assert product["name"]


def test_create_order_prices_and_deadline_are_server_controlled(client, payload, order, clock):
    saved = order["order"]
    menu = client.get("/api/menu").json()["products"]
    prices = {p["id"]: p["price_cents"] for p in menu}
    expected = sum(prices[item["product_id"]] * item["quantity"] for item in payload["items"])
    assert saved["total_cents"] == expected
    assert saved["status"] == "PENDING"
    assert saved["expires_at"] - saved["created_at"] == 300
    assert saved["created_at"] == int(clock())
    assert len(order["access_token"]) >= 32
    result = client.get(f"/api/orders/{saved['id']}", headers=token_headers(order))
    assert result.status_code == 200
    assert result.json()["order"]["id"] == saved["id"]


def test_injected_client_price_is_rejected_or_ignored(client, payload, order_headers):
    payload["items"][0]["unit_price_cents"] = 1
    payload["total_cents"] = 1
    response = client.post("/api/orders", json=payload, headers=order_headers)
    if response.status_code == 201:
        product_id = payload["items"][0]["product_id"]
        price = next(p["price_cents"] for p in client.get("/api/menu").json()["products"] if p["id"] == product_id)
        assert response.json()["order"]["total_cents"] == price * 2
    else:
        assert response.status_code == 422


@pytest.mark.parametrize("quantity", [0, -1, 1000, 1.5, True])
def test_invalid_quantities_cannot_create_orders(client, payload, order_headers, quantity):
    payload["items"][0]["quantity"] = quantity
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 422, response.text


@pytest.mark.parametrize("phone", ["", "123", "not-a-phone", "+30<script>"])
def test_invalid_phone_is_rejected(client, payload, order_headers, phone):
    payload["phone"] = phone
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 422


def test_unknown_product_cannot_be_ordered(client, payload, order_headers):
    payload["items"][0]["product_id"] = "nonexistent-product"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code in (400, 404, 422)


def test_delivery_fails_closed_without_verified_configuration(client, payload, order_headers):
    payload["fulfillment"] = "delivery"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code in (400, 422, 503)


def test_empty_cart_is_rejected(client, payload, order_headers):
    payload["items"] = []
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 422


def test_idempotency_key_required(client, payload):
    response = client.post("/api/orders", json=payload, headers={"Origin": ORIGIN})
    assert response.status_code in (400, 422)


def test_retry_reuses_order_and_access_token(client, payload, order_headers, order):
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 200
    assert response.json() == order


def test_same_idempotency_key_with_different_cart_is_conflict(client, payload, order_headers, order):
    payload["items"][0]["quantity"] = 3
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 409


def test_simultaneous_identical_submissions_create_one_order(client, payload, order_headers, admin):
    def submit(_):
        return client.post("/api/orders", json=deepcopy(payload), headers=order_headers)

    with ThreadPoolExecutor(max_workers=4) as pool:
        responses = list(pool.map(submit, range(4)))
    assert sorted(r.status_code for r in responses) == [200, 200, 200, 201]
    ids = {r.json()["order"]["id"] for r in responses}
    assert len(ids) == 1
    assert len(admin.get("/api/admin/orders").json()["orders"]) == 1


def test_customer_token_is_required_and_isolated(client, payload, order_headers, order):
    order_id = order["order"]["id"]
    assert client.get(f"/api/orders/{order_id}").status_code in (401, 403, 404)
    assert client.get(f"/api/orders/{order_id}", headers={"Authorization": "Bearer invalid"}).status_code in (401, 403, 404)
    headers = {**order_headers, "Idempotency-Key": str(uuid.uuid4())}
    second = client.post("/api/orders", json=payload, headers=headers).json()
    assert client.get(f"/api/orders/{second['order']['id']}", headers=token_headers(order)).status_code in (401, 403, 404)


def test_pending_order_expires_at_exactly_five_minutes(client, order, clock):
    path = f"/api/orders/{order['order']['id']}"
    clock.advance(299)
    assert client.get(path, headers=token_headers(order)).json()["order"]["status"] == "PENDING"
    clock.advance(1)
    expired = client.get(path, headers=token_headers(order)).json()["order"]
    assert expired["status"] == "REJECTED"
    assert expired["rejection_reason"] == "AUTO_TIMEOUT_5_MIN"


def test_late_staff_acceptance_cannot_revive_expired_order(admin, order, clock):
    clock.advance(300)
    response = admin.post(
        f"/api/admin/orders/{order['order']['id']}/transition",
        json={"status": "ACCEPTED"}, headers={"Origin": ORIGIN},
    )
    assert response.status_code == 409
    saved = admin.get("/api/admin/orders?status=REJECTED").json()["orders"]
    assert saved[0]["rejection_reason"] == "AUTO_TIMEOUT_5_MIN"


def test_expiry_is_checked_after_obtaining_transition_write_lock(admin, order, clock, monkeypatch):
    """Model a write-lock wait that crosses the deadline after authentication."""
    clock.advance(299)
    database = admin.app.state.database
    original_transaction = database.transaction
    calls = 0

    @contextmanager
    def delayed_transaction():
        nonlocal calls
        with original_transaction() as connection:
            calls += 1
            # Authentication reads first; the transition acquires the second lock.
            if calls == 2:
                clock.advance(1)
            yield connection

    monkeypatch.setattr(database, "transaction", delayed_transaction)
    response = admin.post(
        f"/api/admin/orders/{order['order']['id']}/transition",
        json={"status": "ACCEPTED"}, headers={"Origin": ORIGIN},
    )
    assert response.status_code == 409
    saved = admin.get("/api/admin/orders?status=REJECTED").json()["orders"]
    assert saved[0]["rejection_reason"] == "AUTO_TIMEOUT_5_MIN"


def test_accepted_order_does_not_expire_and_can_be_completed(admin, order, clock):
    path = f"/api/admin/orders/{order['order']['id']}/transition"
    response = admin.post(path, json={"status": "ACCEPTED"}, headers={"Origin": ORIGIN})
    assert response.status_code == 200
    clock.advance(600)
    saved = admin.get("/api/admin/orders?status=ACCEPTED").json()["orders"]
    assert len(saved) == 1
    response = admin.post(path, json={"status": "COMPLETED"}, headers={"Origin": ORIGIN})
    assert response.status_code == 200
    assert admin.get("/api/admin/orders?status=COMPLETED").json()["orders"][0]["id"] == order["order"]["id"]


def test_illegal_transition_is_rejected(admin, order):
    path = f"/api/admin/orders/{order['order']['id']}/transition"
    assert admin.post(path, json={"status": "COMPLETED"}, headers={"Origin": ORIGIN}).status_code == 409
    assert admin.post(path, json={"status": "REJECTED"}, headers={"Origin": ORIGIN}).status_code == 200
    assert admin.post(path, json={"status": "ACCEPTED"}, headers={"Origin": ORIGIN}).status_code == 409


def test_competing_accept_reject_has_one_winner(admin, order):
    path = f"/api/admin/orders/{order['order']['id']}/transition"

    def transition(status):
        return admin.post(path, json={"status": status}, headers={"Origin": ORIGIN})

    with ThreadPoolExecutor(max_workers=2) as pool:
        responses = list(pool.map(transition, ("ACCEPTED", "REJECTED")))
    assert sorted(r.status_code for r in responses) == [200, 409]
    saved = admin.get("/api/admin/orders").json()["orders"]
    assert len(saved) == 1
    assert saved[0]["status"] in ("ACCEPTED", "REJECTED")


def test_order_rate_limit_rejects_burst(client, payload):
    statuses = []
    for _ in range(12):
        response = client.post(
            "/api/orders", json=payload,
            headers={"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4())},
        )
        statuses.append(response.status_code)
        if response.status_code == 429:
            assert "Retry-After" in response.headers
            break
    assert statuses[0] == 201
    assert 429 in statuses
