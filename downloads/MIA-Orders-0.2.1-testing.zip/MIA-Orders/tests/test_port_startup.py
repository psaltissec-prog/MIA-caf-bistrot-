"""Exercise the downloaded launcher against a real, unrelated local HTTP service."""

from __future__ import annotations

import json
import os
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import httpx
import pytest

from mia.security import hash_password

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def stop_launcher(process: subprocess.Popen) -> None:
    """Signal only the process group created by this test, including its server child."""
    if process.poll() is not None:
        return
    if os.name == "nt":
        process.send_signal(signal.CTRL_BREAK_EVENT)
    else:
        os.killpg(process.pid, signal.SIGINT)
    try:
        process.wait(timeout=12)
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            process.terminate()
        else:
            os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)


def wait_for_launcher(process, app, client, log):
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        if process.poll() is not None:
            pytest.fail("Actual bootstrap stopped before readiness:\n" + log.read_text())
        try:
            state = json.loads((app / "runtime/desktop.json").read_text())
            origin = f"http://127.0.0.1:{state['port']}"
            health = client.get(origin + "/api/health").json()
            if (health.get("installation_id") == state["installation_id"]
                    and health.get("public_origin") == origin):
                return state, origin
        except (OSError, ValueError, KeyError, httpx.HTTPError):
            pass
        time.sleep(0.1)
    pytest.fail("Actual bootstrap did not become ready:\n" + log.read_text())


def test_downloaded_bootstrap_falls_back_without_stopping_foreign_service(tmp_path):
    # Use the reviewed environment already running pytest. Never install packages as a test.
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "port_regression_bootstrap", PROJECT_ROOT / "START_MIA_ORDERS.py"
    )
    bootstrap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bootstrap)
    if (not (Path(sys.prefix) / "pyvenv.cfg").is_file()
            or not bootstrap.runtime_ready(Path(sys.executable), PROJECT_ROOT / "requirements.txt")):
        pytest.skip("The bootstrap smoke test requires the reviewed runtime pins in a virtualenv")

    app = tmp_path / "MIA Orders with spaces"
    app.mkdir()
    for filename in ("START_MIA_ORDERS.py", "requirements.txt"):
        shutil.copy2(PROJECT_ROOT / filename, app / filename)
    shutil.copytree(PROJECT_ROOT / "mia", app / "mia", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(PROJECT_ROOT / "data/menu", app / "data/menu")

    class ForeignService(BaseHTTPRequestHandler):
        def do_GET(self):
            body = b'{"service":"unrelated-work-application","status":"ok"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    try:
        foreign = ThreadingHTTPServer(("127.0.0.1", 8000), ForeignService)
    except OSError:
        # Preserve any existing service even in the regression test itself.
        foreign = ThreadingHTTPServer(("127.0.0.1", 0), ForeignService)
    thread = threading.Thread(target=foreign.serve_forever, daemon=True)
    thread.start()
    foreign_origin = f"http://127.0.0.1:{foreign.server_port}"
    password = secrets.token_urlsafe(32)
    environment = {key: value for key, value in os.environ.items() if not key.startswith("MIA_")}
    environment.pop("PYTHONPATH", None)
    environment.update({
        "MIA_VENV_PATH": sys.prefix,
        "MIA_ADMIN_USERNAME": "startup-test",
        "MIA_ADMIN_PASSWORD_HASH": hash_password(password),
        "MIA_ENV": "test",
        "PYTHONUNBUFFERED": "1",
    })
    if foreign.server_port != 8000:
        environment["MIA_PORT"] = str(foreign.server_port)
    command = [sys.executable, str(app / "START_MIA_ORDERS.py"), "--no-browser"]
    log = tmp_path / "launcher.log"
    process = None
    try:
        with log.open("w", encoding="utf-8") as output, httpx.Client(
            timeout=2, trust_env=False
        ) as client:
            process = subprocess.Popen(
                command, cwd=app, env=environment, stdout=output, stderr=subprocess.STDOUT,
                start_new_session=os.name != "nt",
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
            )
            state, origin = wait_for_launcher(process, app, client, log)
            assert state["port"] != foreign.server_port
            assert set(state) == {"version", "installation_id", "port"}
            assert password not in (app / "runtime/desktop.json").read_text()
            assert environment["MIA_ADMIN_PASSWORD_HASH"] not in log.read_text()

            # The chosen address must also be the server's CSRF origin.
            login = {"username": "startup-test", "password": password}
            assert client.post(
                origin + "/api/admin/login", json=login, headers={"Origin": foreign_origin}
            ).status_code == 403
            response = client.post(
                origin + "/api/admin/login", json=login, headers={"Origin": origin}
            )
            assert response.status_code == 200, response.text
            products = client.get(origin + "/api/menu").json()["products"]
            product = next(item for item in products if item["available"])
            response = client.post(
                origin + "/api/admin/test-orders",
                headers={"Origin": origin, "Idempotency-Key": str(uuid.uuid4())},
                json={
                    "customer_name": "Δοκιμή εκκίνησης", "phone": "+306912345678",
                    "fulfillment": "pickup", "notes": "Temporary regression test",
                    "items": [{"product_id": product["id"], "quantity": 1, "notes": ""}],
                },
            )
            assert response.status_code == 201, response.text
            order_id = response.json()["order"]["id"]

            # A second double-click must find this installation on its fallback port.
            second = subprocess.run(
                command, cwd=app, env=environment, capture_output=True, text=True, timeout=15,
            )
            assert second.returncode == 0, second.stdout + second.stderr
            assert "already running" in second.stdout
            assert process.poll() is None
            assert json.loads((app / "runtime/desktop.json").read_text()) == state
            saved = client.get(origin + "/api/admin/orders").json()["orders"]
            assert any(order["id"] == order_id for order in saved)
            assert client.get(foreign_origin).json()["service"] == "unrelated-work-application"
    finally:
        if process is not None:
            stop_launcher(process)
        foreign.shutdown()
        foreign.server_close()
        thread.join(timeout=2)
