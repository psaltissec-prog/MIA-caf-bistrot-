from __future__ import annotations

import csv
import io
import uuid
from copy import deepcopy

import pytest
from conftest import ADMIN_PASSWORD, ORIGIN
from fastapi.testclient import TestClient

from mia.app import create_app


def product_item(product, variant_index=0, **overrides):
    item = {
        "product_id": product["id"],
        "variant_id": product["variants"][variant_index]["id"],
        "option_ids": {
            group["id"]: group["options"][0]["id"]
            for group in product["option_groups"] if group["required"]
        },
        "quantity": 1,
        "notes": "",
    }
    return item | overrides


def submit(client, payload, *, key=None):
    return client.post(
        "/api/orders", json=payload,
        headers={"Origin": ORIGIN, "Idempotency-Key": key or str(uuid.uuid4())},
    )


def login(client):
    response = client.post(
        "/api/admin/login", json={"username": "admin", "password": ADMIN_PASSWORD},
        headers={"Origin": ORIGIN},
    )
    assert response.status_code == 200, response.text


def update(client, path, body):
    return client.post(path, json=body, headers={"Origin": ORIGIN})


def multi_variant(client):
    return next(
        p for p in client.get("/api/menu").json()["products"]
        if len(p["variants"]) > 1 and not p["option_groups"]
    )


def grouped_product(client):
    return next(p for p in client.get("/api/menu").json()["products"] if p["option_groups"])


def test_selected_size_price_is_derived_from_server_and_saved(admin, payload):
    product = multi_variant(admin)
    payload["items"] = [product_item(product, -1, quantity=2)]
    response = submit(admin, payload)
    assert response.status_code == 201, response.text
    order = response.json()["order"]
    item = order["items"][0]
    assert order["total_cents"] == 2 * product["variants"][-1]["price_cents"]
    assert item["unit_price_cents"] == product["variants"][-1]["price_cents"]
    assert item["variant_id"] == product["variants"][-1]["id"]
    assert item["variant_label"] == product["variants"][-1]["label"]


@pytest.mark.parametrize("variant", ["does-not-exist", "<script>"])
def test_unknown_size_cannot_silently_charge_the_default_size(client, payload, variant):
    product = multi_variant(client)
    payload["items"] = [product_item(product, variant_id=variant)]
    response = submit(client, payload)
    assert response.status_code == 422


def test_two_different_sizes_of_same_drink_are_separate_valid_lines(client, payload):
    product = multi_variant(client)
    payload["items"] = [product_item(product, 0), product_item(product, -1)]
    response = submit(client, payload)
    assert response.status_code == 201, response.text
    assert response.json()["order"]["total_cents"] == sum(
        product["variants"][index]["price_cents"] for index in (0, -1)
    )
    assert len(response.json()["order"]["items"]) == 2


def test_duplicate_exact_configuration_is_rejected(client, payload):
    product = multi_variant(client)
    item = product_item(product)
    payload["items"] = [item, deepcopy(item)]
    assert submit(client, payload).status_code == 422


def test_required_flavor_must_be_selected_and_unknown_choices_are_rejected(client, payload):
    product = grouped_product(client)
    item = product_item(product)
    group = product["option_groups"][0]
    payload["items"] = [item | {"option_ids": {}}]
    assert submit(client, payload).status_code == 422
    payload["items"] = [item | {"option_ids": {group["id"]: "invented-choice"}}]
    assert submit(client, payload).status_code == 422
    payload["items"] = [item | {"option_ids": item["option_ids"] | {"invented-group": "anything"}}]
    assert submit(client, payload).status_code == 422


def test_valid_flavor_is_recorded_without_inventing_extra_charges(client, payload):
    product = grouped_product(client)
    item = product_item(product, -1)
    group = product["option_groups"][0]
    item["option_ids"][group["id"]] = group["options"][-1]["id"]
    payload["items"] = [item]
    response = submit(client, payload)
    assert response.status_code == 201, response.text
    saved = response.json()["order"]
    assert saved["total_cents"] == product["variants"][-1]["price_cents"]
    assert group["options"][-1]["label"] in saved["items"][0]["name"]


def test_staff_can_mark_unavailable_but_existing_order_is_unchanged(admin, payload):
    product = multi_variant(admin)
    payload["items"] = [product_item(product)]
    key = str(uuid.uuid4())
    created = submit(admin, payload, key=key)
    assert created.status_code == 201
    unavailable = update(admin, f"/api/admin/menu/{product['id']}", {"available": False})
    assert unavailable.status_code == 200
    listed = next(p for p in admin.get("/api/menu").json()["products"] if p["id"] == product["id"])
    assert listed["available"] is False
    assert submit(admin, payload).status_code == 422
    retried = submit(admin, payload, key=key)
    assert retried.status_code == 200
    assert retried.json()["order"]["id"] == created.json()["order"]["id"]
    assert retried.json()["order"]["total_cents"] == created.json()["order"]["total_cents"]


def test_pause_blocks_new_orders_but_not_recovery_of_saved_order(admin, payload):
    key = str(uuid.uuid4())
    created = submit(admin, payload, key=key)
    assert created.status_code == 201
    paused = update(admin, "/api/admin/settings", {"accepting_orders": False})
    assert paused.status_code == 200
    assert admin.get("/api/menu").json()["store"]["accepting_orders"] is False
    blocked = submit(admin, payload)
    assert blocked.status_code == 503
    assert submit(admin, payload, key=key).json()["order"]["id"] == created.json()["order"]["id"]
    assert update(admin, "/api/admin/settings", {"accepting_orders": True}).status_code == 200
    assert submit(admin, payload).status_code == 201


def test_store_pause_and_availability_survive_restart(settings, clock, admin):
    product = multi_variant(admin)
    assert update(admin, f"/api/admin/menu/{product['id']}", {"available": False}).status_code == 200
    assert update(admin, "/api/admin/settings", {"accepting_orders": False}).status_code == 200
    with TestClient(create_app(settings, clock=clock), base_url=ORIGIN) as restarted:
        menu = restarted.get("/api/menu").json()
        assert menu["store"]["accepting_orders"] is False
        assert next(p for p in menu["products"] if p["id"] == product["id"])["available"] is False
        login(restarted)
        assert restarted.get("/api/admin/settings").json()["accepting_orders"] is False


def test_menu_and_store_controls_require_staff_authentication(client):
    assert client.get("/api/admin/menu").status_code == 401
    assert client.get("/api/admin/settings").status_code == 401
    assert update(client, "/api/admin/settings", {"accepting_orders": False}).status_code == 401
    product = multi_variant(client)
    assert update(client, f"/api/admin/menu/{product['id']}", {"available": False}).status_code == 401


@pytest.mark.parametrize("bad", ["false", 0, None])
def test_control_flags_require_real_booleans(admin, bad):
    product = multi_variant(admin)
    assert update(admin, "/api/admin/settings", {"accepting_orders": bad}).status_code == 422
    assert update(admin, f"/api/admin/menu/{product['id']}", {"available": bad}).status_code == 422


def test_pagination_keeps_all_history_accessible(admin, payload):
    ids = []
    for index in range(3):
        payload["phone"] = f"+30690000000{index}"
        response = submit(admin, payload)
        assert response.status_code == 201
        ids.append(response.json()["order"]["id"])
    first = admin.get("/api/admin/orders?limit=2&offset=0").json()
    second = admin.get("/api/admin/orders?limit=2&offset=2").json()
    assert first["total"] == second["total"] == 3
    assert first["limit"] == 2 and first["offset"] == 0
    assert {o["id"] for o in first["orders"] + second["orders"]} == set(ids)
    assert not ({o["id"] for o in first["orders"]} & {o["id"] for o in second["orders"]})
    assert first["counts"]["PENDING"] == 3


def test_all_orders_csv_exports_every_status_and_neutralizes_formulas(admin, payload):
    payload["customer_name"] = '=HYPERLINK("https://invalid.example")'
    first = submit(admin, payload).json()["order"]
    payload["phone"] = "+306900000009"
    second = submit(admin, payload).json()["order"]
    assert update(admin, f"/api/admin/orders/{first['id']}/transition", {"status": "REJECTED"}).status_code == 200
    assert update(admin, f"/api/admin/orders/{second['id']}/transition", {"status": "ACCEPTED"}).status_code == 200
    response = admin.get("/api/admin/orders.csv")
    assert response.status_code == 200
    rows = list(csv.DictReader(io.StringIO(response.text.lstrip("\ufeff"))))
    assert len(rows) == 2
    assert {row["status"] for row in rows} == {"ACCEPTED", "REJECTED"}
    for row in rows:
        assert not row["customer_name"].startswith("=")


def test_receipt_is_authenticated_escaped_and_not_cached(admin, payload):
    payload["customer_name"] = '<script>alert("name")</script>'
    payload["notes"] = '<img src=x onerror="alert(1)">'
    created = submit(admin, payload)
    assert created.status_code == 201
    path = f"/api/admin/orders/{created.json()['order']['id']}/receipt"
    with TestClient(admin.app, base_url=ORIGIN) as anonymous:
        assert anonymous.get(path).status_code == 401
    receipt = admin.get(path)
    assert receipt.status_code == 200
    assert "text/html" in receipt.headers["content-type"]
    assert "<script>alert" not in receipt.text
    assert '<img src=x onerror=' not in receipt.text
    assert "&lt;script&gt;" in receipt.text
    assert "&lt;img" in receipt.text
    assert "no-store" in receipt.headers.get("cache-control", "")


def test_staff_test_order_entry_can_test_more_than_three_orders_without_customer_rate_bypass(admin, payload):
    for _ in range(5):
        response = admin.post(
            "/api/admin/test-orders", json=payload,
            headers={"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4())},
        )
        assert response.status_code == 201, response.text
        assert response.json()["order"]["demo"] is True
    public_response = submit(admin, payload)
    assert public_response.status_code == 429


def test_staff_test_entry_requires_authentication_and_obeys_pause(client, payload, admin):
    anonymous = TestClient(create_app(admin.app.state.settings), base_url=ORIGIN)
    with anonymous:
        denied = anonymous.post(
            "/api/admin/test-orders", json=payload,
            headers={"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4())},
        )
        assert denied.status_code == 401
    assert update(admin, "/api/admin/settings", {"accepting_orders": False}).status_code == 200
    paused = admin.post(
        "/api/admin/test-orders", json=payload,
        headers={"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4())},
    )
    assert paused.status_code == 503


def test_client_headers_cannot_enable_staff_rate_limit_bypass(client, payload):
    for _ in range(3):
        assert submit(client, payload).status_code == 201
    response = client.post(
        "/api/orders", json=payload,
        headers={"Origin": ORIGIN, "Idempotency-Key": str(uuid.uuid4()),
                 "X-MIA-Staff": "true", "X-MIA-Admin": "true"},
    )
    assert response.status_code == 429
