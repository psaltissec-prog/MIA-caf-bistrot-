from dataclasses import replace

import httpx
import pytest
from conftest import ORIGIN
from fastapi.testclient import TestClient

from mia.app import create_app


class VerificationProvider:
    """In-process provider double; this suite never connects to Cloudflare."""

    def __init__(self):
        self.result = {"success": True, "hostname": "testserver"}
        self.status = 200
        self.error = None
        self.invalid_json = False
        self.calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return None

    async def post(self, url, *, data):
        self.calls.append((url, data))
        if self.error:
            raise self.error
        request = httpx.Request("POST", url)
        if self.invalid_json:
            return httpx.Response(self.status, content=b"not-json", request=request)
        return httpx.Response(self.status, json=self.result, request=request)


@pytest.fixture
def verified_client(settings, clock, monkeypatch):
    provider = VerificationProvider()
    monkeypatch.setattr("mia.app.httpx.AsyncClient", lambda **_: provider)
    configured = replace(
        settings,
        turnstile_site_key="test-public-site-key",
        turnstile_secret="test-provider-secret-not-a-real-credential",
    )
    with TestClient(create_app(configured, clock=clock), base_url=ORIGIN) as client:
        yield client, provider


def assert_no_orders(client):
    with client.app.state.database.transaction() as database:
        assert database.execute("SELECT count(*) FROM orders").fetchone()[0] == 0


def test_configured_turnstile_requires_token(verified_client, payload, order_headers):
    client, provider = verified_client
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 400
    assert not provider.calls
    assert_no_orders(client)


def test_verified_token_and_hostname_allow_order(verified_client, payload, order_headers):
    client, provider = verified_client
    payload["turnstile_token"] = "valid-browser-token"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 201
    assert len(provider.calls) == 1
    url, data = provider.calls[0]
    assert url == "https://challenges.cloudflare.com/turnstile/v0/siteverify"
    assert data["response"] == "valid-browser-token"
    assert data["secret"] == client.app.state.settings.turnstile_secret
    assert provider.calls[0][1]["secret"] not in response.text
    health = client.get("/api/health")
    assert health.status_code == 200
    assert "no-store" in health.headers["cache-control"]
    assert data["secret"] not in health.text


@pytest.mark.parametrize(
    "result",
    [
        {"success": False, "hostname": "testserver"},
        {"success": True, "hostname": "attacker.example"},
        {"success": True},
        {"success": "false", "hostname": "testserver"},
        {},
        ["unexpected-provider-response"],
    ],
)
def test_provider_rejection_or_malformed_success_cannot_create_order(
    verified_client, payload, order_headers, result,
):
    client, provider = verified_client
    provider.result = result
    payload["turnstile_token"] = "invalid-browser-token"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 400
    assert_no_orders(client)


def test_provider_timeout_returns_retryable_error_without_order(
    verified_client, payload, order_headers,
):
    client, provider = verified_client
    provider.error = httpx.ReadTimeout("Synthetic provider timeout")
    payload["turnstile_token"] = "browser-token"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 503
    assert "Synthetic provider timeout" not in response.text
    assert_no_orders(client)


@pytest.mark.parametrize("failure", ["http-error", "invalid-json"])
def test_invalid_provider_response_fails_closed(verified_client, payload, order_headers, failure):
    client, provider = verified_client
    if failure == "http-error":
        provider.status = 503
    else:
        provider.invalid_json = True
    payload["turnstile_token"] = "browser-token"
    response = client.post("/api/orders", json=payload, headers=order_headers)
    assert response.status_code == 503
    assert_no_orders(client)


def test_idempotent_retry_does_not_reconsume_single_use_turnstile_token(
    verified_client, payload, order_headers,
):
    client, provider = verified_client
    payload["turnstile_token"] = "single-use-browser-token"
    created = client.post("/api/orders", json=payload, headers=order_headers)
    assert created.status_code == 201
    payload.pop("turnstile_token")
    provider.error = httpx.ReadTimeout("Must not contact provider on retry")
    retried = client.post("/api/orders", json=payload, headers=order_headers)
    assert retried.status_code == 200
    assert retried.json() == created.json()
    assert len(provider.calls) == 1
