import shlex
import sqlite3
from pathlib import Path

import pytest

from mia.cli import main
from mia.security import verify_password


def run_cli(monkeypatch, *args):
    monkeypatch.setattr("sys.argv", ["mia-admin", *map(str, args)])
    main()


def test_init_admin_creates_private_shell_safe_hash_config(tmp_path, monkeypatch, capsys):
    output = tmp_path / "private" / "admin.env"
    password = "A local generated-test password 58!"
    username = "admin'; injected shell text"
    answers = iter([password, password])
    monkeypatch.setattr("mia.cli.getpass.getpass", lambda _: next(answers))
    run_cli(monkeypatch, "init-admin", "--output", output, "--username", username)
    assert output.stat().st_mode & 0o777 == 0o600
    assert output.parent.stat().st_mode & 0o777 == 0o700
    contents = output.read_text()
    assert password not in contents
    assignments = {}
    for line in contents.splitlines():
        export, assignment = shlex.split(line)
        assert export == "export"
        key, value = assignment.split("=", 1)
        assignments[key] = value
    assert assignments["MIA_ADMIN_USERNAME"] == username
    assert verify_password(password, assignments["MIA_ADMIN_PASSWORD_HASH"])
    stdout = capsys.readouterr().out
    assert password not in stdout
    assert assignments["MIA_ADMIN_PASSWORD_HASH"] not in stdout


def test_init_admin_preserves_existing_configuration(tmp_path, monkeypatch):
    output = tmp_path / "admin.env"
    output.write_text("existing user configuration")
    with pytest.raises(SystemExit) as error:
        run_cli(monkeypatch, "init-admin", "--output", output)
    assert error.value.code == 2
    assert output.read_text() == "existing user configuration"


def test_init_admin_password_mismatch_writes_nothing(tmp_path, monkeypatch):
    output = tmp_path / "admin.env"
    answers = iter(["Valid long password 12!", "Different long password 34!"])
    monkeypatch.setattr("mia.cli.getpass.getpass", lambda _: next(answers))
    with pytest.raises(SystemExit) as error:
        run_cli(monkeypatch, "init-admin", "--output", output)
    assert error.value.code == 2
    assert not output.exists()


def test_backup_preserves_order_data_and_database_integrity(
    tmp_path, monkeypatch, settings, order, capsys,
):
    destination = tmp_path / "backups" / "snapshot.sqlite3"
    run_cli(monkeypatch, "backup", settings.db_path, destination)
    assert destination.stat().st_mode & 0o777 == 0o600
    with sqlite3.connect(Path(destination).as_uri() + "?mode=ro", uri=True) as backup:
        assert backup.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        saved = backup.execute("SELECT id,total_cents,status FROM orders").fetchall()
    expected = order["order"]
    assert saved == [(expected["id"], expected["total_cents"], "PENDING")]
    assert "integrity checked" in capsys.readouterr().out


def test_backup_never_overwrites_existing_file(tmp_path, monkeypatch, settings, order):
    destination = tmp_path / "existing.sqlite3"
    destination.write_bytes(b"existing backup contents")
    with pytest.raises(FileExistsError):
        run_cli(monkeypatch, "backup", settings.db_path, destination)
    assert destination.read_bytes() == b"existing backup contents"


def test_backup_rejects_source_as_destination(monkeypatch, settings, order):
    before = settings.db_path.read_bytes()
    with pytest.raises(SystemExit) as error:
        run_cli(monkeypatch, "backup", settings.db_path, settings.db_path)
    assert error.value.code == 2
    assert settings.db_path.read_bytes() == before
