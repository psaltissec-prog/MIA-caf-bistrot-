from dataclasses import replace

import pytest


def test_real_orders_cannot_be_enabled_by_accident(settings):
    with pytest.raises(ValueError, match="Live orders are disabled"):
        replace(settings, live_orders=True).validate()


def test_production_requires_https_and_secure_cookie(settings):
    with pytest.raises(ValueError, match="HTTPS"):
        replace(settings, environment="production").validate()
    with pytest.raises(ValueError, match="HTTPS"):
        replace(settings, environment="production", public_origin="https://orders.example").validate()


def test_production_requires_real_admin_hash(settings):
    with pytest.raises(ValueError, match="MIA_ADMIN_PASSWORD_HASH"):
        replace(
            settings, environment="production", public_origin="https://orders.example",
            secure_cookie=True, admin_password_hash="",
        ).validate()


def test_secure_production_demo_configuration_is_valid(settings):
    replace(
        settings, environment="production", public_origin="https://orders.example",
        secure_cookie=True,
    ).validate()


@pytest.mark.parametrize("origin", ["https://orders.example/path", "https://user:password@orders.example", "ftp://orders.example", "https://orders.example?query=1"])
def test_ambiguous_or_credentialed_origins_are_rejected(settings, origin):
    with pytest.raises(ValueError, match="MIA_PUBLIC_ORIGIN"):
        replace(settings, public_origin=origin).validate()


def test_turnstile_requires_both_public_and_private_keys(settings):
    with pytest.raises(ValueError, match="both Turnstile"):
        replace(settings, turnstile_site_key="a-public-site-key").validate()
