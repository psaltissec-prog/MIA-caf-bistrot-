from __future__ import annotations

import importlib.util
import json
import os
import shlex
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from mia import desktop

BOOTSTRAP_PATH = Path(__file__).resolve().parents[1] / "START_MIA_ORDERS.py"
spec = importlib.util.spec_from_file_location("mia_bootstrap", BOOTSTRAP_PATH)
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)


def write_config(path, username, password_hash):
    path.write_text(
        "export MIA_ADMIN_USERNAME=" + shlex.quote(username) + "\n"
        "export MIA_ADMIN_PASSWORD_HASH=" + shlex.quote(password_hash) + "\n",
        encoding="utf-8",
    )


def test_private_config_is_parsed_as_data_without_executing_shell(tmp_path, password_hash):
    marker = tmp_path / "should-never-exist"
    username = f"$(touch {marker}); ' untrusted literal"
    config = tmp_path / "admin.env"
    write_config(config, username, password_hash)
    values = desktop.load_admin_config(config)
    assert values == {"MIA_ADMIN_USERNAME": username, "MIA_ADMIN_PASSWORD_HASH": password_hash}
    assert not marker.exists()


@pytest.mark.parametrize("contents", [
    "export PATH=/tmp/attacker\n",
    "export MIA_ADMIN_USERNAME=admin\nexport MIA_ADMIN_USERNAME=other\n",
    "export MIA_ADMIN_USERNAME=admin; touch unwanted\n",
    "export MIA_ADMIN_USERNAME='unterminated\n",
    "export MIA_ADMIN_USERNAME=admin\n",
])
def test_unsupported_or_partial_private_config_fails_closed(tmp_path, contents):
    config = tmp_path / "admin.env"
    config.write_text(contents)
    with pytest.raises(ValueError):
        desktop.load_admin_config(config)


def test_missing_config_is_distinct_from_corrupt_config(tmp_path):
    assert desktop.load_admin_config(tmp_path / "not-created.env") == {}
    corrupt = tmp_path / "too-large.env"
    corrupt.write_bytes(b"x" * 17000)
    with pytest.raises(ValueError):
        desktop.load_admin_config(corrupt)


def test_health_identity_requires_matching_local_installation_and_service():
    origin = "http://127.0.0.1:8000"
    identifier = "a" * 32
    health = {"status": "ok", "service": "mia-orders", "version": "0.2.0-testing",
              "installation_id": identifier, "public_origin": origin}
    assert desktop.is_expected_health(health, identifier, origin)
    for altered in (
        health | {"service": "another-service"},
        health | {"installation_id": "b" * 32},
        health | {"public_origin": "http://127.0.0.1:9000"},
        health | {"version": "0.1.0"},
        health | {"status": "starting"},
    ):
        assert not desktop.is_expected_health(altered, identifier, origin)
    assert not desktop.is_expected_health(health, None, origin)


def test_installation_id_reader_accepts_only_valid_public_metadata(tmp_path):
    database = tmp_path / "identity.sqlite3"
    assert desktop.read_installation_id(database) is None
    with sqlite3.connect(database) as connection:
        connection.execute("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT)")
        connection.execute("INSERT INTO metadata VALUES ('installation_id',?)", ("c" * 32,))
    assert desktop.read_installation_id(database) == "c" * 32
    with sqlite3.connect(database) as connection:
        connection.execute("UPDATE metadata SET value='malformed' WHERE key='installation_id'")
    assert desktop.read_installation_id(database) is None


@pytest.mark.parametrize("origin", ["https://remote.example", "http://localhost:8000", "file:///tmp/private"])
def test_readiness_probe_cannot_contact_non_launcher_destination(origin):
    with pytest.raises(ValueError):
        desktop.probe_server(origin)


def test_local_health_redirect_is_not_followed_to_another_destination():
    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            received.append(self.path)
            self.send_response(302)
            self.send_header("Location", "/unexpected-redirect")
            self.end_headers()

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        assert desktop.probe_server(f"http://127.0.0.1:{server.server_port}") is None
        assert received == ["/api/health"]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_deeply_nested_local_health_json_is_rejected_without_crashing():
    body = ("[" * 1200 + "0" + "]" * 1200).encode("ascii")

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        assert desktop.probe_server(f"http://127.0.0.1:{server.server_port}") is None
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def simulated_launcher(tmp_path, monkeypatch, password_hash):
    """Replace only server processes, preserving the launcher's actual selection/configuration."""
    monkeypatch.chdir(tmp_path)
    environment = {key: value for key, value in os.environ.items() if not key.startswith("MIA_")}
    environment.update({"MIA_ADMIN_PASSWORD_HASH": password_hash, "MIA_ENV": "test"})
    monkeypatch.setattr(desktop.os, "environ", environment)
    monkeypatch.setattr(desktop, "read_installation_id", lambda path: "a" * 32)
    started, stopped = [], []

    class OwnProcess:
        def __init__(self, command, **kwargs):
            self.port = int(command[command.index("--port") + 1])
            self.origin = f"http://127.0.0.1:{self.port}"
            started.append(self)

        def poll(self):
            return None

        def wait(self):
            return 0

    def health(origin):
        if started and origin == started[-1].origin:
            return {"service": "mia-orders", "status": "ok", "version": "0.2.1-testing",
                    "installation_id": "a" * 32, "public_origin": origin}
        return {"service": "unrelated"}

    monkeypatch.setattr(desktop.subprocess, "Popen", OwnProcess)
    monkeypatch.setattr(desktop, "stop_owned_server", stopped.append)
    monkeypatch.setattr(desktop, "probe_server", health)
    return environment, started, stopped


def test_unrelated_occupied_default_port_is_preserved_and_another_port_starts(
    tmp_path, monkeypatch, password_hash
):
    environment, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: port == 8000)
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert len(started) == 1
    assert started[0].port != 8000
    assert stopped == started  # Cleanup receives only the child this launcher created.
    assert environment["MIA_PUBLIC_ORIGIN"] == started[0].origin
    assert desktop.load_desktop_state(tmp_path / "runtime/desktop.json")["port"] == started[0].port


def test_all_normal_ports_occupied_uses_os_assigned_port(tmp_path, monkeypatch, password_hash):
    _, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    attempted = []

    def unavailable(port):
        attempted.append(port)
        return port != 49152

    monkeypatch.setattr(desktop, "port_in_use", unavailable)
    monkeypatch.setattr(desktop, "ephemeral_port", lambda: 49152)
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert [process.port for process in started] == [49152]
    assert stopped == started
    assert len(attempted) < 100  # A denied range cannot cause an unbounded scan.


def test_windows_excluded_port_bind_denial_is_unavailable(monkeypatch):
    class DeniedSocket:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def setsockopt(self, *args):
            pass

        def bind(self, address):
            error = PermissionError(10013, "Windows excluded port")
            error.winerror = 10013
            raise error

    monkeypatch.setattr(desktop.socket, "socket", lambda *a, **kw: DeniedSocket())
    assert desktop.port_in_use(8000) is True


def test_all_ports_denied_exits_without_starting_or_stopping_any_process(
    tmp_path, monkeypatch, password_hash
):
    _, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    attempts = []

    def unavailable(port):
        attempts.append(port)
        return True

    def denied_ephemeral():
        raise PermissionError(10013, "Windows excluded port")

    monkeypatch.setattr(desktop, "port_in_use", unavailable)
    monkeypatch.setattr(desktop, "ephemeral_port", denied_ephemeral)
    with pytest.raises((RuntimeError, OSError)):
        desktop.run(tmp_path, no_browser=True, skip_admin_init=True)
    assert started == stopped == []
    assert len(attempts) < 100


def test_explicit_origin_does_not_silently_change_when_its_port_is_occupied(
    tmp_path, monkeypatch, password_hash
):
    environment, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    environment["MIA_PUBLIC_ORIGIN"] = "http://127.0.0.1:8000"
    monkeypatch.setattr(desktop, "port_in_use", lambda port: True)
    with pytest.raises(RuntimeError):
        desktop.run(tmp_path, no_browser=True, skip_admin_init=True)
    assert environment["MIA_PUBLIC_ORIGIN"] == "http://127.0.0.1:8000"
    assert started == stopped == []


def test_remembered_port_reuses_only_verified_server_for_this_database(
    tmp_path, monkeypatch, password_hash
):
    _, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    state = tmp_path / "runtime/desktop.json"
    assert desktop.save_desktop_state(state, "a" * 32, 8017)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: port in {8000, 8017})
    origin = "http://127.0.0.1:8017"
    monkeypatch.setattr(desktop, "probe_server", lambda url: {
        "service": "mia-orders", "status": "ok", "version": "0.2.1-testing",
        "installation_id": "a" * 32, "public_origin": origin,
    } if url == origin else {"service": "unrelated"})
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert started == stopped == []
    assert desktop.load_desktop_state(state)["port"] == 8017


@pytest.mark.parametrize("saved_identity,listener_identity,saved_port", [
    ("b" * 32, "a" * 32, 49152), ("a" * 32, "b" * 32, 8017),
])
def test_remembered_port_never_adopts_a_foreign_installation(
    tmp_path, monkeypatch, password_hash, saved_identity, listener_identity, saved_port
):
    _, started, _ = simulated_launcher(tmp_path, monkeypatch, password_hash)
    state = tmp_path / "runtime/desktop.json"
    assert desktop.save_desktop_state(state, saved_identity, saved_port)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: port in {8000, saved_port})
    own_probe = desktop.probe_server

    def probe(origin):
        if origin == f"http://127.0.0.1:{saved_port}":
            return {"service": "mia-orders", "status": "ok", "version": "0.2.1-testing",
                    "installation_id": listener_identity, "public_origin": origin}
        return own_probe(origin)

    monkeypatch.setattr(desktop, "probe_server", probe)
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert len(started) == 1 and started[0].port not in {8000, saved_port}


def test_bind_race_retries_after_stopping_only_its_failed_child(
    tmp_path, monkeypatch, password_hash
):
    environment, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    spawn = desktop.subprocess.Popen
    health = desktop.probe_server

    def race_child(*args, **kwargs):
        process = spawn(*args, **kwargs)
        if len(started) == 1:
            process.poll = lambda: 1
        return process

    monkeypatch.setattr(desktop.subprocess, "Popen", race_child)
    monkeypatch.setattr(desktop, "probe_server", lambda origin: (
        {"service": "unrelated"} if origin == "http://127.0.0.1:8000" else health(origin)
    ))
    monkeypatch.setattr(desktop, "port_in_use", lambda port: bool(started) and port == 8000)
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert [process.port for process in started] == [8000, 8001]
    assert stopped == started
    assert environment["MIA_PUBLIC_ORIGIN"] == "http://127.0.0.1:8001"


def test_parallel_launcher_bind_race_reuses_verified_winning_server(
    tmp_path, monkeypatch, password_hash
):
    _, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    spawn = desktop.subprocess.Popen

    def losing_child(*args, **kwargs):
        process = spawn(*args, **kwargs)
        process.poll = lambda: 1
        return process

    monkeypatch.setattr(desktop.subprocess, "Popen", losing_child)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: bool(started) and port == 8000)
    assert desktop.run(tmp_path, no_browser=True, skip_admin_init=True) == 0
    assert [process.port for process in started] == [8000]
    assert stopped == started
    assert desktop.load_desktop_state(tmp_path / "runtime/desktop.json")["port"] == 8000


def test_application_startup_error_is_not_hidden_by_port_retries(
    tmp_path, monkeypatch, password_hash
):
    _, started, stopped = simulated_launcher(tmp_path, monkeypatch, password_hash)
    spawn = desktop.subprocess.Popen

    def failed_child(*args, **kwargs):
        process = spawn(*args, **kwargs)
        process.poll = lambda: 1
        return process

    monkeypatch.setattr(desktop.subprocess, "Popen", failed_child)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: False)
    with pytest.raises(RuntimeError, match="stopped during startup"):
        desktop.run(tmp_path, no_browser=True, skip_admin_init=True)
    assert len(started) == 1
    assert stopped == started


@pytest.mark.parametrize("contents", [
    "not json", "{}", "[]", "x" * 4097,
    json.dumps({"version": 1, "installation_id": "a" * 32, "port": True}),
    json.dumps({"version": 1, "installation_id": "a" * 32, "port": 65536}),
    json.dumps({"version": 1, "installation_id": "a" * 32, "port": 8001, "password": "private"}),
    json.dumps({"version": 1, "installation_id": "../untrusted", "port": 8001}),
])
def test_unknown_desktop_state_is_ignored_and_preserved(tmp_path, contents):
    path = tmp_path / "desktop.json"
    path.write_text(contents)
    assert desktop.load_desktop_state(path) is None
    assert not desktop.save_desktop_state(path, "a" * 32, 8001)
    assert path.read_text() == contents
    assert list(tmp_path.glob(".desktop-*.tmp")) == []


def test_deeply_nested_desktop_state_is_ignored_and_preserved(tmp_path):
    path = tmp_path / "desktop.json"
    body = "[" * 1200 + "0" + "]" * 1200
    path.write_text(body)
    assert desktop.load_desktop_state(path) is None
    assert not desktop.save_desktop_state(path, "a" * 32, 8001)
    assert path.read_text() == body


def test_desktop_state_stores_only_public_identity_and_port_and_updates_atomically(tmp_path):
    path = tmp_path / "runtime/desktop.json"
    assert desktop.save_desktop_state(path, "a" * 32, 8001)
    assert desktop.load_desktop_state(path) == {
        "version": 1, "installation_id": "a" * 32, "port": 8001,
    }
    assert desktop.save_desktop_state(path, "a" * 32, 8002)
    assert desktop.load_desktop_state(path)["port"] == 8002
    assert not desktop.save_desktop_state(path, "b" * 32, 8003)
    assert desktop.load_desktop_state(path)["port"] == 8002
    if os.name != "nt":
        assert path.stat().st_mode & 0o777 == 0o600
    assert list(path.parent.glob(".desktop-*.tmp")) == []


def test_desktop_state_never_follows_or_replaces_an_existing_symlink(tmp_path):
    target = tmp_path / "personal-file.json"
    original = '{"private":"keep this file"}'
    target.write_text(original)
    path = tmp_path / "desktop.json"
    try:
        path.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("Symbolic links are unavailable for this account")
    assert desktop.load_desktop_state(path) is None
    assert not desktop.save_desktop_state(path, "a" * 32, 8001)
    assert path.is_symlink()
    assert target.read_text() == original


def test_optional_state_tempfile_cleanup_error_does_not_abort_successful_startup(
    tmp_path, monkeypatch
):
    original_unlink = Path.unlink

    def denied_temporary_unlink(path, *args, **kwargs):
        if path.name.startswith(".desktop-"):
            raise PermissionError("Temporary file is locked by the workstation")
        return original_unlink(path, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", denied_temporary_unlink)
    path = tmp_path / "desktop.json"
    assert desktop.save_desktop_state(path, "a" * 32, 8001)
    assert desktop.load_desktop_state(path)["port"] == 8001


@pytest.mark.parametrize("foreign_file_races", [False, True])
def test_windows_new_state_uses_fat_compatible_exclusive_rename(
    tmp_path, monkeypatch, foreign_file_races
):
    path = tmp_path / "desktop.json"
    foreign_contents = b"Foreign application data: preserve this file"
    original_rename = desktop.os.rename
    renames = []

    def windows_rename(source, destination):
        renames.append((source, destination))
        if foreign_file_races:
            destination.write_bytes(foreign_contents)
        if destination.exists():
            raise FileExistsError("Windows rename cannot replace an existing destination")
        return original_rename(source, destination)

    monkeypatch.setattr(desktop, "WINDOWS_STATE_RENAME", True)
    monkeypatch.setattr(desktop.os, "rename", windows_rename)
    monkeypatch.setattr(desktop.os, "link", lambda *a, **k: pytest.fail(
        "Windows state creation must work on FAT without hard links"
    ))
    assert desktop.save_desktop_state(path, "a" * 32, 8001) is not foreign_file_races
    assert len(renames) == 1
    if foreign_file_races:
        assert path.read_bytes() == foreign_contents
    else:
        assert desktop.load_desktop_state(path) == {
            "version": 1, "installation_id": "a" * 32, "port": 8001,
        }
    assert list(tmp_path.glob(".desktop-*.tmp")) == []


def test_warm_runtime_starts_without_installation_or_network(tmp_path, monkeypatch):
    requirements = tmp_path / "requirements.txt"
    requirements.write_text("fastapi==1.2.3\n")
    environment = tmp_path / ".venv"
    environment.mkdir()
    (environment / "pyvenv.cfg").write_text("test environment")
    monkeypatch.setattr(bootstrap, "runtime_ready", lambda python, req: True)
    monkeypatch.setattr(bootstrap.subprocess, "run", lambda *a, **k: pytest.fail("warm runtime must not invoke pip"))
    assert bootstrap.ensure_runtime(tmp_path, environment) == bootstrap.venv_python_path(environment)
    assert (environment / ".mia-runtime.json").is_file()


def test_bootstrap_preserves_nonempty_unknown_runtime_directory(tmp_path):
    (tmp_path / "requirements.txt").write_text("fastapi==1.2.3\n")
    selected = tmp_path / "personal-files"
    selected.mkdir()
    marker = selected / "important.txt"
    marker.write_text("keep me")
    with pytest.raises(RuntimeError, match="not a virtual environment"):
        bootstrap.ensure_runtime(tmp_path, selected)
    assert marker.read_text() == "keep me"


@pytest.mark.parametrize("requirement", ["fastapi>=1", "--index-url=https://unexpected.example", "-r other.txt", "fastapi==1\nfastapi==2"])
def test_launcher_refuses_unpinned_or_interpreted_requirement_text(tmp_path, requirement):
    path = tmp_path / "requirements.txt"
    path.write_text(requirement)
    with pytest.raises(ValueError):
        bootstrap.pinned_requirements(path)


def test_windows_python_path_is_computed_without_assuming_unix_layout(tmp_path):
    assert bootstrap.venv_python_path(tmp_path, windows=True) == tmp_path / "Scripts" / "python.exe"
    assert bootstrap.venv_python_path(tmp_path, windows=False) == tmp_path / "bin" / "python"


def test_startup_backup_preserves_saved_order_and_never_overwrites_previous(settings, order, tmp_path):
    directory = tmp_path / "startup-backups"
    first = desktop.backup_before_start(settings.db_path, directory)
    second = desktop.backup_before_start(settings.db_path, directory)
    assert first != second
    assert first.is_file() and second.is_file()
    assert first.stat().st_mode & 0o777 == 0o600
    with sqlite3.connect(first) as connection:
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        saved = connection.execute("SELECT id,total_cents FROM orders").fetchall()
    assert saved == [(order["order"]["id"], order["order"]["total_cents"])]


def test_corrupt_database_does_not_leave_misleading_backup(tmp_path):
    database = tmp_path / "broken.sqlite3"
    database.write_bytes(b"not a database")
    directory = tmp_path / "backups"
    with pytest.raises(sqlite3.DatabaseError):
        desktop.backup_before_start(database, directory)
    assert list(directory.glob("*.sqlite3")) == []
