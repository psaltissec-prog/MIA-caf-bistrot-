from __future__ import annotations

import hashlib
import json
from pathlib import Path

from mia.catalog import catalog_metadata, load_catalog

DATA = Path(__file__).resolve().parents[1] / "data" / "menu"


def test_every_real_menu_price_is_imported_without_missing_products():
    source = json.loads((DATA / "menu-current.json").read_text(encoding="utf-8"))
    products = load_catalog()
    assert len(products) == len(source["entries"]) == 123
    assert sum(len(p["variants"]) for p in products) == 215
    by_source = {p["source_paragraph"]: p for p in products}
    assert len(by_source) == 123
    for entry in source["entries"]:
        product = by_source[entry["source_paragraph"]]
        assert product["name"] == entry["name"]
        assert [variant["price_cents"] for variant in product["variants"]] == entry["prices_cents"]
        assert product["price_cents"] == min(entry["prices_cents"])
    metadata = catalog_metadata()
    assert metadata["source_sha256"] == hashlib.sha256((DATA / metadata["source_filename"]).read_bytes()).hexdigest()


def test_owner_corrections_and_removed_salad_are_reflected_in_actual_catalogue():
    products = load_catalog()
    assert not any("Lentil & Quinoa" in p["name"] for p in products)
    penne = next(p for p in products if p["name"] == "Penne Pomodoro")
    assert "vegan" not in penne["name"].casefold()
    assert "παρμεζάνα" in penne["description"]
    assert "Parmesan" in penne["description"]
    waffle = next(p for p in products if p["name"] == "Waffle Κοτόπουλο / Chicken Waffle")
    assert "κοτόπουλο" in waffle["description"]
    assert "chicken" in waffle["description"]
    assert any("Vegan Samali" in p["name"] for p in products)


def test_catalogue_preserves_long_bilingual_descriptions_and_food_choices():
    products = load_catalog()
    croque = next(p for p in products if p["name"] == "Croque Madame")
    assert "μπεσαμέλ" in croque["description"]
    assert "béchamel" in croque["description"]
    chicken = next(p for p in products if "Juicy Chicken Fillet" in p["name"])
    assert {option["id"] for option in chicken["option_groups"][0]["options"]} == {"rice", "fries"}
    toast = next(p for p in products if p["id"] == "toast")
    assert {option["id"] for option in toast["option_groups"][0]["options"]} == {"ham", "turkey"}


def test_callers_cannot_mutate_the_canonical_catalogue():
    first = load_catalog()
    first[0]["name"] = "tampered"
    first[0]["variants"][0]["price_cents"] = 1
    grouped = next(p for p in first if p["option_groups"])
    grouped["option_groups"][0]["options"].clear()
    fresh = load_catalog()
    assert fresh[0]["name"] != "tampered"
    assert fresh[0]["variants"][0]["price_cents"] != 1
    assert next(p for p in fresh if p["id"] == grouped["id"])["option_groups"][0]["options"]


def test_api_exposes_real_prices_but_keeps_orders_explicitly_in_test_mode(client):
    menu = client.get("/api/menu").json()
    assert menu["store"]["demo"] is True
    assert menu["store"]["live_orders"] is False
    assert menu["store"]["catalog_source"] == "owner_menu"
    assert len(menu["products"]) == 123
    freddo = next(p for p in menu["products"] if p["id"] == "freddo-espresso")
    assert [v["price_cents"] for v in freddo["variants"]] == [250, 310, 370]
