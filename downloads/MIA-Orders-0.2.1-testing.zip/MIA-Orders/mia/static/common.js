export const money = cents => new Intl.NumberFormat('el-GR', {style: 'currency', currency: 'EUR'}).format(Number(cents || 0) / 100);
export const statusLabels = {PENDING: 'Αναμονή αποδοχής', ACCEPTED: 'Σε προετοιμασία', REJECTED: 'Απορρίφθηκε', COMPLETED: 'Ολοκληρώθηκε'};
let serverOffset = 0;
export const serverNow = () => Date.now() + serverOffset;
export function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = String(text);
  return node;
}
export function timestamp(value) {
  if (typeof value === 'string' && /^\d+(\.\d+)?$/.test(value)) value = Number(value);
  if (typeof value === 'number') return value < 1e12 ? value * 1000 : value;
  return Date.parse(value);
}
export function countdown(expiresAt) {
  const seconds = Math.max(0, Math.ceil((timestamp(expiresAt) - serverNow()) / 1000));
  if (!Number.isFinite(seconds)) return '—';
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}
export function showMessage(node, text, kind = '') {
  node.textContent = text;
  node.className = `notice ${kind}`;
  node.hidden = !text;
}
export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}
export async function api(path, options = {}) {
  const started = Date.now();
  const headers = new Headers(options.headers || {});
  if (options.body) headers.set('Content-Type', 'application/json');
  let response;
  try {
    response = await fetch(path, {credentials: 'same-origin', cache: 'no-store', ...options, headers, signal: options.signal || AbortSignal.timeout(15000)});
  } catch (error) {
    throw new ApiError('Δεν ήταν δυνατή η σύνδεση. Έλεγξε το δίκτυο και δοκίμασε ξανά.', 0);
  }
  let body;
  try { body = await response.json(); } catch { body = {}; }
  if (typeof body.server_time === 'number') serverOffset = timestamp(body.server_time) - (started + Date.now()) / 2;
  if (!response.ok) {
    let message = typeof body.detail === 'string' ? body.detail : 'Δεν ήταν δυνατή η ολοκλήρωση της ενέργειας.';
    if (response.status === 422) message = 'Έλεγξε τα στοιχεία και τις ποσότητες της παραγγελίας.';
    if (response.status === 429) message = 'Έγιναν πολλές προσπάθειες. Περίμενε λίγο πριν δοκιμάσεις ξανά.';
    if (response.status >= 500 && typeof body.detail !== 'string') message = 'Το σύστημα δεν απάντησε κανονικά. Δοκίμασε ξανά σε λίγο.';
    throw new ApiError(message, response.status);
  }
  return body;
}
