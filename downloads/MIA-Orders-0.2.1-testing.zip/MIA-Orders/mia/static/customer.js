import {api, element, money, statusLabels, countdown, showMessage} from '/static/common.js';

const $ = id => document.getElementById(id);
const cart = new Map();
let products = [];
let category = null;
let search = '';
let acceptingOrders = true;
let staffTesting = false;
const selections = new Map();
const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('el-GR');
let demo = true;
let submitting = false;
let pendingSubmission = null;
let tracking = null;
let currentOrder = null;
let polling = false;
let turnstileToken = '';
let turnstileRequired = false;
let turnstileWidget = null;
const trackingStorageKey = 'mia-current-order';
const pendingStorageKey = 'mia-pending-submission';

function storePending(value) {
  pendingSubmission = value;
  try {
    if (value) sessionStorage.setItem(pendingStorageKey, JSON.stringify(value));
    else sessionStorage.removeItem(pendingStorageKey);
  } catch { /* Retry remains possible in this tab when session storage is unavailable. */ }
}

function storeTracking(value) {
  tracking = value;
  try {
    if (value) sessionStorage.setItem(trackingStorageKey, JSON.stringify(value));
    else sessionStorage.removeItem(trackingStorageKey);
  } catch { /* Private browsing may disallow session storage; current tab still works. */ }
}

function cartQuantity() { return [...cart.values()].reduce((total, item) => total + item.quantity, 0); }
function locked() { return submitting || pendingSubmission !== null; }

function configurationKey(product, variantId, optionIds, notes) {
  return JSON.stringify([product.id, variantId, Object.entries(optionIds).sort(([a], [b]) => a.localeCompare(b)), notes]);
}

function selectionFor(product) {
  if (!selections.has(product.id)) selections.set(product.id, {variant_id: product.variants?.[0]?.id || 'standard', option_ids: {}, notes: ''});
  return selections.get(product.id);
}

function configurationLabel(product, selection) {
  const parts = [];
  const variant = product.variants?.find(item => item.id === selection.variant_id);
  if (product.variants?.length > 1 && variant) parts.push(variant.label);
  for (const group of product.option_groups || []) {
    const option = group.options.find(item => item.id === selection.option_ids[group.id]);
    if (option) parts.push(`${group.label}: ${option.label}`);
  }
  return parts.join(' · ');
}

function renderProducts() {
  const focusedId = document.activeElement?.id;
  $('products').replaceChildren();
  const visible = products.filter(item => (!category || item.category === category) && normalize(`${item.name} ${item.description} ${item.category}`).includes(normalize(search)));
  $('menu-results').textContent = `${visible.length} ${visible.length === 1 ? 'επιλογή' : 'επιλογές'}`;
  $('menu-empty').hidden = visible.length > 0;
  for (const product of visible) {
    const selected = selectionFor(product);
    const card = element('article', `product-card${product.available ? '' : ' unavailable'}`);
    card.dataset.productId = product.id;
    card.append(element('p', 'product-category', product.category), element('h3', '', product.name));
    if (product.description) {
      const details = element('details', 'product-details');
      details.append(element('summary', '', 'Περιγραφή & υλικά'), element('p', 'product-description', product.description));
      card.append(details);
    }
    const fields = element('div', 'product-configuration');
    const variants = product.variants || [{id: 'standard', label: 'Κανονικό', price_cents: product.price_cents}];
    if (variants.length > 1) {
      const id = `variant-${product.id}`;
      const label = element('label', '', 'Μέγεθος'); label.htmlFor = id;
      const select = element('select', 'variant-select'); select.id = id;
      for (const variant of variants) {
        const option = element('option', '', `${variant.label} · ${money(variant.price_cents)}`);
        option.value = variant.id; select.append(option);
      }
      select.value = selected.variant_id;
      select.disabled = locked();
      select.addEventListener('change', () => { selected.variant_id = select.value; renderProducts(); });
      fields.append(label, select);
    }
    for (const group of product.option_groups || []) {
      const id = `option-${product.id}-${group.id}`;
      const label = element('label', '', `${group.label}${group.required ? ' *' : ''}`); label.htmlFor = id;
      const select = element('select', 'option-select'); select.id = id; select.required = Boolean(group.required);
      const placeholder = element('option', '', group.required ? 'Επίλεξε…' : 'Χωρίς επιλογή'); placeholder.value = ''; select.append(placeholder);
      for (const choice of group.options) { const option = element('option', '', choice.label); option.value = choice.id; select.append(option); }
      select.value = selected.option_ids[group.id] || '';
      select.disabled = locked();
      select.addEventListener('change', () => { if (select.value) selected.option_ids[group.id] = select.value; else delete selected.option_ids[group.id]; renderProducts(); });
      fields.append(label, select);
    }
    const noteDetails = element('details', 'product-notes');
    const noteId = `note-${product.id}`;
    const noteLabel = element('label', '', 'Σημείωση προϊόντος'); noteLabel.htmlFor = noteId;
    const note = element('input', 'item-note-input'); note.id = noteId; note.type = 'text'; note.maxLength = 200;
    note.value = selected.notes; note.placeholder = 'π.χ. χωρίς πάγο'; note.disabled = locked();
    note.addEventListener('input', () => { selected.notes = note.value; });
    noteDetails.append(element('summary', '', 'Προσθήκη σημείωσης'), noteLabel, note);
    fields.append(noteDetails); card.append(fields);
    const variant = variants.find(item => item.id === selected.variant_id) || variants[0];
    const complete = (product.option_groups || []).every(group => !group.required || selected.option_ids[group.id]);
    const bottom = element('div', 'product-bottom');
    bottom.append(element('span', 'product-price', money(variant.price_cents)));
    const add = element('button', 'add-button', '+'); add.type = 'button'; add.id = `add-${product.id}`;
    add.disabled = !product.available || !acceptingOrders || locked() || cartQuantity() >= 50 || !complete;
    add.setAttribute('aria-label', `Προσθήκη ${product.name} στο καλάθι`);
    add.addEventListener('click', () => {
      const entry = {product, variant_id: variant.id, option_ids: {...selected.option_ids}, notes: selected.notes.trim(), unit_price_cents: variant.price_cents, label: configurationLabel(product, selected)};
      const key = configurationKey(product, entry.variant_id, entry.option_ids, entry.notes);
      changeQuantity(key, entry, 1);
    });
    bottom.append(add); card.append(bottom);
    if (!product.available) card.append(element('span', 'small muted', 'Προσωρινά μη διαθέσιμο'));
    else if (!complete) card.append(element('span', 'small muted', 'Επίλεξε τις απαιτούμενες επιλογές.'));
    $('products').append(card);
  }
  if (focusedId) document.getElementById(focusedId)?.focus({preventScroll: true});
}

function renderCategories() {
  $('categories').replaceChildren();
  for (const value of [null, ...new Set(products.map(product => product.category))]) {
    const button = element('button', `category-tab${value === category ? ' active' : ''}`, value || 'Όλα');
    button.type = 'button'; button.setAttribute('aria-pressed', String(value === category));
    button.addEventListener('click', () => { category = value; renderCategories(); renderProducts(); });
    $('categories').append(button);
  }
}

function changeQuantity(key, entry, amount) {
  if (locked()) return;
  const quantity = (cart.get(key)?.quantity || 0) + amount;
  if (quantity > 20 || (amount > 0 && cartQuantity() >= 50)) return;
  if (quantity <= 0) cart.delete(key);
  else cart.set(key, {...entry, quantity});
  renderCart(); renderProducts();
  $('cart-announcement').textContent = `${entry.product.name}. ${quantity > 0 ? `${quantity} στο καλάθι.` : 'Αφαιρέθηκε από το καλάθι.'}`;
}

function renderCart() {
  const list = $('cart-items'); list.replaceChildren();
  if (!cart.size) list.append(element('p', 'empty-cart', 'Το καλάθι περιμένει την πρώτη σου επιλογή.'));
  let total = 0;
  for (const [key, entry] of cart) {
    const {product, quantity} = entry;
    total += entry.unit_price_cents * quantity;
    const row = element('div', 'cart-item');
    const description = element('div');
    description.append(element('span', 'cart-item-name', product.name));
    if (entry.label) description.append(element('span', 'cart-item-options', entry.label));
    if (entry.notes) description.append(element('span', 'cart-item-options', entry.notes));
    if (!product.available) description.append(element('span', 'cart-item-options unavailable-warning', 'Δεν είναι διαθέσιμο. Αφαίρεσέ το για να συνεχίσεις.'));
    row.append(description, element('span', 'cart-item-price', money(entry.unit_price_cents * quantity)));
    const controls = element('div', 'quantity-controls');
    for (const amount of [-1, 1]) {
      const button = element('button', 'quantity-button', amount === -1 ? '−' : '+'); button.type = 'button';
      button.setAttribute('aria-label', `${amount === -1 ? 'Μείωση' : 'Αύξηση'} ποσότητας ${product.name}`);
      button.disabled = locked() || (amount === 1 && (quantity >= 20 || cartQuantity() >= 50));
      button.addEventListener('click', () => changeQuantity(key, entry, amount));
      if (amount === 1) controls.append(element('span', '', quantity)); controls.append(button);
    }
    const remove = element('button', 'remove-button', 'Αφαίρεση'); remove.type = 'button'; remove.disabled = locked();
    remove.setAttribute('aria-label', `Αφαίρεση ${product.name}`); remove.addEventListener('click', () => changeQuantity(key, entry, -quantity));
    row.append(controls, remove); list.append(row);
  }
  $('cart-total').textContent = money(total); $('cart-count').textContent = cartQuantity();
  $('checkout-fields').disabled = locked();
  $('checkout-button').disabled = (!cart.size && !pendingSubmission) || submitting || (currentOrder?.status === 'PENDING') || (!acceptingOrders && !pendingSubmission) || (!pendingSubmission && [...cart.values()].some(entry => !entry.product.available)) || (turnstileRequired && !turnstileToken && !pendingSubmission);
  $('checkout-button').textContent = submitting ? 'Αποστολή…' : pendingSubmission ? 'Έλεγχος και επανάληψη αποστολής' : demo ? 'Στείλε δοκιμαστική παραγγελία →' : 'Στείλε την παραγγελία σου →';
}

async function loadMenu() {
  try {
    const data = await api('/api/menu');
    if (!Array.isArray(data.products) || !data.products.length) throw new Error('Το μενού δεν είναι ακόμα διαθέσιμο.');
    products = data.products;
    for (const entry of cart.values()) {
      const updated = products.find(product => product.id === entry.product.id);
      if (!updated) { entry.product = {...entry.product, available: false}; continue; }
      entry.product = updated;
      const variant = updated.variants?.find(item => item.id === entry.variant_id);
      const groups = updated.option_groups || [];
      const validOptions = groups.every(group => (!group.required && !entry.option_ids[group.id]) || group.options.some(option => option.id === entry.option_ids[group.id])) && Object.keys(entry.option_ids).every(id => groups.some(group => group.id === id));
      if (!variant || !validOptions) entry.product = {...updated, available: false};
      if (variant && !pendingSubmission) entry.unit_price_cents = variant.price_cents;
    }
    acceptingOrders = data.store?.accepting_orders !== false;
    if (pendingSubmission && !cart.size) {
      for (const item of pendingSubmission.body.items) {
        const product = products.find(candidate => candidate.id === item.product_id);
        if (!product) continue;
        const variant = product.variants?.find(candidate => candidate.id === item.variant_id) || product.variants?.[0];
        const entry = {product, variant_id: item.variant_id || variant?.id || 'standard', option_ids: item.option_ids || {}, notes: item.notes || '', quantity: item.quantity, unit_price_cents: variant?.price_cents || product.price_cents};
        entry.label = configurationLabel(product, entry);
        cart.set(configurationKey(product, entry.variant_id, entry.option_ids, entry.notes), entry);
      }
      $('customer-name').value = pendingSubmission.body.customer_name;
      $('customer-phone').value = pendingSubmission.body.phone;
      $('customer-notes').value = pendingSubmission.body.notes || '';
      showMessage($('checkout-message'), 'Βρέθηκε αποστολή χωρίς επιβεβαιωμένο αποτέλεσμα. Πάτησε έλεγχο και επανάληψη: χρησιμοποιείται το ίδιο κλειδί για να αποφευχθεί διπλή παραγγελία.', 'warning');
    }
    demo = data.store?.demo !== false; $('demo-banner').hidden = !demo;
    const details = [];
    if (data.store?.address) details.push(data.store.address);
    if (data.store?.opening_days?.length === 7) details.push('Καθημερινά, Δευτέρα–Κυριακή');
    if (data.store?.opening_time && data.store?.closing_time) details.push(`Ωράριο ${data.store.opening_time}–${data.store.closing_time} (ώρα Ελλάδας)`);
    $('store-details').textContent = details.join(' · ');
    if (!acceptingOrders) showMessage($('store-state'), 'Η λήψη νέων παραγγελιών έχει τεθεί προσωρινά σε παύση από το κατάστημα.', 'warning');
    else if (data.store?.is_open === false) showMessage($('store-state'), 'Το δηλωμένο ωράριο είναι 09:00–17:00. Η δοκιμαστική λειτουργία παραμένει διαθέσιμη για τις δοκιμές σου.', 'subtle');
    else showMessage($('store-state'), '');
    if (data.store?.turnstile_site_key && !turnstileRequired) setupTurnstile(data.store.turnstile_site_key);
    showMessage($('menu-message'), ''); renderCategories(); renderProducts(); renderCart();
  } catch (error) { showMessage($('menu-message'), `${error.message} Ανανέωσε τη σελίδα για νέα προσπάθεια.`, 'error'); }
}

$('menu-search').addEventListener('input', event => { search = event.target.value; renderProducts(); });
$('refresh-menu').addEventListener('click', async () => { $('refresh-menu').disabled = true; try { await loadMenu(); } finally { $('refresh-menu').disabled = false; } });

function setupTurnstile(sitekey) {
  turnstileRequired = true;
  $('turnstile-widget').hidden = false;
  const script = document.createElement('script');
  script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
  script.async = true;
  script.addEventListener('load', () => {
    if (!window.turnstile) return;
    turnstileWidget = window.turnstile.render($('turnstile-widget'), {
      sitekey,
      theme: 'light',
      language: 'el',
      callback: token => { turnstileToken = token; renderCart(); },
      'expired-callback': () => { turnstileToken = ''; renderCart(); },
      'error-callback': () => {
        turnstileToken = '';
        renderCart();
        showMessage($('checkout-message'), 'Η επαλήθευση ασφαλείας δεν είναι διαθέσιμη. Ανανέωσε τη σελίδα και δοκίμασε ξανά.', 'error');
      }
    });
  });
  script.addEventListener('error', () => showMessage($('checkout-message'), 'Δεν φορτώθηκε η επαλήθευση ασφαλείας. Έλεγξε τη σύνδεση και ανανέωσε τη σελίδα.', 'error'));
  document.head.append(script);
}

function resetTurnstile() {
  turnstileToken = '';
  if (turnstileWidget !== null && window.turnstile) window.turnstile.reset(turnstileWidget);
}

$('checkout-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (submitting || (!cart.size && !pendingSubmission) || currentOrder?.status === 'PENDING' || (!pendingSubmission && (!acceptingOrders || [...cart.values()].some(entry => !entry.product.available))) || (turnstileRequired && !turnstileToken && !pendingSubmission)) return;
  if (!pendingSubmission) {
    storePending({
      key: crypto.randomUUID(),
      route: staffTesting ? '/api/admin/test-orders' : '/api/orders',
      body: {
        customer_name: $('customer-name').value.trim(),
        phone: $('customer-phone').value.trim(),
        fulfillment: 'pickup',
        notes: $('customer-notes').value.trim(),
        turnstile_token: turnstileToken,
        items: [...cart.values()].map(({product, variant_id, option_ids, quantity, notes}) => ({product_id: product.id, variant_id, option_ids, quantity, notes}))
      }
    });
  }
  submitting = true;
  renderCart();
  renderProducts();
  showMessage($('checkout-message'), 'Η παραγγελία αποστέλλεται. Περίμενε την επιβεβαίωση.');
  try {
    const route = pendingSubmission.route === '/api/admin/test-orders' ? '/api/admin/test-orders' : '/api/orders';
    const data = await api(route, {method: 'POST', headers: {'Idempotency-Key': pendingSubmission.key}, body: JSON.stringify(pendingSubmission.body)});
    storeTracking({id: data.order.id, access_token: data.access_token});
    currentOrder = data.order;
    storePending(null);
    resetTurnstile();
    cart.clear();
    $('checkout-form').reset();
    renderTracking();
    showMessage($('checkout-message'), 'Η παραγγελία καταχωρίστηκε. Παρακολούθησε παρακάτω την αποδοχή της.');
    $('order-tracking').scrollIntoView({behavior: 'smooth', block: 'center'});
  } catch (error) {
    const staffSessionExpired = error.status === 401 && pendingSubmission?.route === '/api/admin/test-orders';
    if (error.status >= 400 && error.status < 500 && error.status !== 408 && !staffSessionExpired) { storePending(null); resetTurnstile(); }
    const uncertain = pendingSubmission ? ' Το αποτέλεσμα είναι άγνωστο. Πάτησε επανάληψη σε αυτή την καρτέλα: θα χρησιμοποιηθεί ο ίδιος αριθμός αποστολής για αποφυγή διπλής παραγγελίας.' : '';
    const sessionHint = staffSessionExpired ? ' Συνδέσου ξανά στον χώρο προσωπικού και επέστρεψε για επανάληψη της ίδιας αποστολής.' : '';
    showMessage($('checkout-message'), error.message + sessionHint + uncertain, 'error');
  } finally {
    submitting = false;
    renderCart();
    renderProducts();
  }
});

function renderTracking() {
  if (!currentOrder) return;
  $('order-tracking').hidden = false;
  $('tracking-number').textContent = `Παραγγελία #${currentOrder.number} · ${money(currentOrder.total_cents)}`;
  $('tracking-status').textContent = statusLabels[currentOrder.status] || currentOrder.status;
  $('tracking-status').className = `status-badge ${currentOrder.status}`;
  $('tracking-countdown').hidden = currentOrder.status !== 'PENDING';
  updateCountdown();
  const descriptions = {
    PENDING: 'Η παραγγελία στάλθηκε και περιμένει αποδοχή από το κατάστημα.',
    ACCEPTED: 'Το κατάστημα αποδέχτηκε την παραγγελία σου. Η προετοιμασία ξεκίνησε.',
    COMPLETED: 'Η παραγγελία ολοκληρώθηκε. Σε ευχαριστούμε!',
    REJECTED: currentOrder.rejection_reason === 'AUTO_TIMEOUT_5_MIN' ? 'Η παραγγελία απορρίφθηκε αυτόματα, επειδή δεν έγινε αποδοχή μέσα σε 5 λεπτά. Δεν πραγματοποιήθηκε χρέωση.' : 'Το κατάστημα δεν αποδέχτηκε την παραγγελία. Δεν πραγματοποιήθηκε χρέωση.'
  };
  $('tracking-description').textContent = descriptions[currentOrder.status] || 'Αναμονή ενημέρωσης.';
  $('tracking-clear').hidden = ['PENDING', 'ACCEPTED'].includes(currentOrder.status);
  renderCart();
}

function updateCountdown() {
  if (currentOrder?.status === 'PENDING') {
    const remaining = countdown(currentOrder.expires_at);
    $('tracking-countdown').textContent = remaining === '00:00' ? 'Έλεγχος λήξης…' : remaining;
  }
}

async function refreshOrder() {
  if (!tracking || polling || document.hidden) return;
  polling = true;
  try {
    const data = await api(`/api/orders/${encodeURIComponent(tracking.id)}`, {headers: {Authorization: `Bearer ${tracking.access_token}`}});
    currentOrder = data.order || data;
    showMessage($('connectivity'), '');
    renderTracking();
  } catch (error) {
    if (error.status === 401 || error.status === 404) {
      showMessage($('connectivity'), 'Δεν είναι διαθέσιμη η παρακολούθηση αυτής της παραγγελίας. Επικοινώνησε με το κατάστημα πριν επαναλάβεις την παραγγελία.', 'warning');
    } else showMessage($('connectivity'), 'Η κατάσταση της παραγγελίας δεν ενημερώθηκε. Η σύνδεση θα δοκιμαστεί ξανά αυτόματα.', 'warning');
  } finally { polling = false; }
}

$('tracking-clear').addEventListener('click', () => {
  if (!['REJECTED', 'COMPLETED'].includes(currentOrder?.status)) return;
  storeTracking(null);
  currentOrder = null;
  $('order-tracking').hidden = true;
  renderCart();
  $('menu').scrollIntoView({behavior: 'smooth'});
});
window.addEventListener('online', refreshOrder);
window.addEventListener('focus', () => { refreshOrder(); if (!locked()) loadMenu(); });
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshOrder(); });
setInterval(refreshOrder, 5000);
setInterval(updateCountdown, 1000);
try {
  const saved = JSON.parse(sessionStorage.getItem(trackingStorageKey));
  if (typeof saved?.id === 'string' && typeof saved?.access_token === 'string') tracking = saved;
  const pending = JSON.parse(sessionStorage.getItem(pendingStorageKey));
  if (typeof pending?.key === 'string' && typeof pending?.body?.customer_name === 'string' && typeof pending?.body?.phone === 'string' && Array.isArray(pending?.body?.items)) pendingSubmission = pending;
} catch { /* Storage is optional. */ }
api('/api/admin/session').then(session => { staffTesting = session.authenticated === true; $('staff-test-hint').hidden = !staffTesting; }).catch(() => {});
renderCart();
loadMenu();
refreshOrder();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js', {scope: '/'}).catch(() => {});
