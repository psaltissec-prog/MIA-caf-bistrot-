import {api, element, money, statusLabels, countdown, timestamp, serverNow, showMessage} from '/static/common.js';

const $ = id => document.getElementById(id);
let orders = [];
let counts = {};
let offset = 0;
const pageSize = 24;
let total = 0;
let acceptingOrders = true;
let menuProducts = [];
let menuSearch = '';
let settingsBusy = false;
let refreshQueued = false;
let pollingGeneration = 0;
const busyProducts = new Set();
const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('el-GR');
let filter = 'PENDING';
let authenticated = false;
let polling = false;
let audioContext = null;
let audioEnabled = false;
let lastAlert = 0;
let seenPending = new Set();
const busyOrders = new Set();
const filterTitles = {PENDING: 'Σε αναμονή', ACCEPTED: 'Σε προετοιμασία', REJECTED: 'Απορριφθείσες', COMPLETED: 'Ολοκληρωμένες'};

function setAuthenticated(value, username = '') {
  authenticated = value;
  $('login-panel').hidden = value;
  $('dashboard').hidden = !value;
  $('logout-button').hidden = !value;
  $('session-name').textContent = value ? username : '';
  if (!value) { orders = []; counts = {}; offset = 0; seenPending.clear(); audioEnabled = false; updateAudioButton(); }
}

async function checkSession() {
  try {
    const session = await api('/api/admin/session');
    setAuthenticated(session.authenticated !== false, session.username);
    await Promise.all([refreshOrders(), refreshSettings(), refreshAdminMenu()]);
  } catch (error) {
    setAuthenticated(false);
    if (error.status !== 401) showMessage($('login-message'), error.message, 'error');
  }
}

$('login-form').addEventListener('submit', async event => {
  event.preventDefault();
  $('login-button').disabled = true;
  showMessage($('login-message'), '');
  try {
    await api('/api/admin/login', {method: 'POST', body: JSON.stringify({username: $('username').value.trim(), password: $('password').value})});
    $('password').value = '';
    await checkSession();
  } catch (error) {
    $('password').value = '';
    showMessage($('login-message'), error.status === 401 ? 'Το όνομα χρήστη ή ο κωδικός δεν είναι σωστά.' : error.message, 'error');
  } finally { $('login-button').disabled = false; }
});

$('logout-button').addEventListener('click', async () => {
  $('logout-button').disabled = true;
  try {
    await api('/api/admin/logout', {method: 'POST'});
    setAuthenticated(false);
  } catch (error) { showMessage($('admin-message'), error.message, 'error'); }
  finally { $('logout-button').disabled = false; }
});

function updateAudioButton() {
  $('audio-button').textContent = audioEnabled ? 'Ήχος ενεργός · Απενεργοποίηση' : 'Ενεργοποίηση ήχου';
  $('audio-button').setAttribute('aria-pressed', String(audioEnabled));
}

function playAlert() {
  if (!audioEnabled || !audioContext || audioContext.state !== 'running') return;
  const now = audioContext.currentTime;
  for (const [offset, frequency] of [[0, 659.25], [0.18, 830.61], [0.38, 987.77]]) {
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0, now + offset);
    gain.gain.linearRampToValueAtTime(0.16, now + offset + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.5);
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start(now + offset);
    oscillator.stop(now + offset + 0.55);
    oscillator.addEventListener('ended', () => { oscillator.disconnect(); gain.disconnect(); }, {once: true});
  }
  lastAlert = Date.now();
}

$('audio-button').addEventListener('click', async () => {
  if (audioEnabled) { audioEnabled = false; updateAudioButton(); return; }
  try {
    const Audio = window.AudioContext || window.webkitAudioContext;
    if (!Audio) throw new Error('Ο περιηγητής δεν υποστηρίζει ηχητικές ειδοποιήσεις.');
    audioContext ||= new Audio();
    await audioContext.resume();
    audioEnabled = true;
    updateAudioButton();
    playAlert();
  } catch (error) { showMessage($('admin-message'), error.message, 'error'); }
});

function alertPending() {
  if (authenticated && Number(counts.PENDING || 0) > 0 && Date.now() - lastAlert >= 15000) playAlert();
}

function dateText(value) {
  const date = new Date(timestamp(value));
  return Number.isNaN(date.valueOf()) ? '—' : new Intl.DateTimeFormat('el-GR', {dateStyle: 'short', timeStyle: 'short', timeZone: 'Europe/Athens'}).format(date);
}

function actionButton(order, status, label, style) {
  const button = element('button', `button ${style}`, label);
  button.type = 'button';
  button.dataset.transition = status;
  button.disabled = busyOrders.has(order.id);
  button.addEventListener('click', () => transition(order, status));
  return button;
}

function renderOrder(order) {
  const card = element('article', 'order-card');
  card.dataset.orderId = order.id;
  const header = element('div', 'order-card-header');
  const title = element('div');
  title.append(element('h3', 'order-number', `#${order.number}`), element('span', 'order-time', dateText(order.created_at)));
  header.append(title, element('span', `status-badge ${order.status}`, statusLabels[order.status] || order.status));
  card.append(header);
  if (order.status === 'PENDING') {
    const deadline = element('div', 'order-deadline');
    deadline.append(element('span', '', 'Προθεσμία αποδοχής'), element('strong', 'countdown', countdown(order.expires_at)));
    deadline.dataset.expires = order.expires_at;
    card.append(deadline);
  }
  card.append(element('p', 'order-customer', order.customer_name || 'Πελάτης'));
  if (order.phone) {
    const phone = element('a', 'order-phone', order.phone);
    const digits = String(order.phone).replace(/[^+\d]/g, '');
    if (digits) phone.href = `tel:${digits}`;
    card.append(phone);
  }
  card.append(element('p', 'small muted', order.fulfillment === 'delivery' ? 'Διανομή' : 'Παραλαβή από το κατάστημα'));
  const items = element('ul', 'order-line-items');
  for (const item of order.items || []) {
    const row = element('li');
    const description = element('span', '', `${item.quantity} × ${item.name}`);
    if (item.notes) description.append(element('span', 'order-item-note', item.notes));
    row.append(description, element('span', '', money(item.quantity * item.unit_price_cents)));
    items.append(row);
  }
  card.append(items);
  if (order.notes) card.append(element('p', 'order-notes', order.notes));
  const total = element('div', 'order-total');
  total.append(element('span', '', 'Σύνολο'), element('strong', '', money(order.total_cents)));
  card.append(total);
  const actions = element('div', 'order-actions');
  if (order.status === 'PENDING') actions.append(actionButton(order, 'ACCEPTED', 'Αποδοχή ✓', 'primary'), actionButton(order, 'REJECTED', 'Απόρριψη', 'danger'));
  if (order.status === 'ACCEPTED') actions.append(actionButton(order, 'COMPLETED', 'Ολοκλήρωση παραγγελίας', 'primary'));
  const receipt = element('a', 'button secondary compact receipt-link', 'Εκτύπωση δελτίου');
  receipt.href = `/api/admin/orders/${encodeURIComponent(order.id)}/receipt`;
  receipt.target = '_blank'; receipt.rel = 'noopener';
  card.append(actions, receipt);
  if (order.status === 'REJECTED') {
    card.append(element('p', 'order-reason', order.rejection_reason === 'AUTO_TIMEOUT_5_MIN' ? 'Αυτόματη απόρριψη · Παρήλθαν 5 λεπτά' : 'Χειροκίνητη απόρριψη'));
    if (order.rejected_at) card.append(element('span', 'small muted', `Απόρριψη: ${dateText(order.rejected_at)}`));
  }
  return card;
}

function renderOrders() {
  const active = document.activeElement;
  const focusedOrder = active?.closest('.order-card')?.dataset.orderId;
  const focusedAction = active?.dataset.transition;
  for (const node of document.querySelectorAll('[data-count]')) node.textContent = counts[node.dataset.count] || 0;
  $('orders-title').textContent = filterTitles[filter];
  $('orders-list').replaceChildren();
  const visible = orders.filter(order => order.status === filter).sort((a, b) => filter === 'PENDING' ? timestamp(a.created_at) - timestamp(b.created_at) : timestamp(b.created_at) - timestamp(a.created_at));
  if (!visible.length) {
    const empty = element('div', 'empty-state');
    empty.append(element('h3', '', filter === 'PENDING' ? 'Όλα τακτοποιημένα.' : 'Δεν υπάρχουν παραγγελίες εδώ.'), element('p', '', filter === 'PENDING' ? 'Οι νέες παραγγελίες θα εμφανιστούν αυτόματα.' : 'Επίλεξε άλλη κατάσταση για να συνεχίσεις.'));
    $('orders-list').append(empty);
  } else for (const order of visible) $('orders-list').append(renderOrder(order));
  $('page-summary').textContent = total ? `${offset + 1}–${Math.min(offset + pageSize, total)} από ${total}` : '0 παραγγελίες';
  $('previous-page').disabled = offset === 0;
  $('next-page').disabled = offset + pageSize >= total;
  tickCountdowns();
  if (focusedOrder && focusedAction) {
    $('orders-list').querySelector(`[data-order-id="${CSS.escape(focusedOrder)}"] [data-transition="${CSS.escape(focusedAction)}"]`)?.focus();
  }
}

function tickCountdowns() {
  for (const deadline of document.querySelectorAll('[data-expires]')) {
    const remaining = countdown(deadline.dataset.expires);
    deadline.querySelector('.countdown').textContent = remaining === '00:00' ? 'Έλεγχος…' : remaining;
    const expires = /^\d+(\.\d+)?$/.test(deadline.dataset.expires) ? Number(deadline.dataset.expires) * 1000 : timestamp(deadline.dataset.expires);
    deadline.closest('.order-card').classList.toggle('urgent', expires - serverNow() < 60000);
  }
}

for (const button of $('order-filters').querySelectorAll('button')) button.addEventListener('click', () => {
  filter = button.dataset.status; offset = 0; pollingGeneration += 1;
  for (const candidate of $('order-filters').querySelectorAll('button')) {
    candidate.classList.toggle('active', candidate === button);
    candidate.setAttribute('aria-pressed', String(candidate === button));
  }
  refreshOrders();
});

$('previous-page').addEventListener('click', () => { offset = Math.max(0, offset - pageSize); pollingGeneration += 1; refreshOrders(); });
$('next-page').addEventListener('click', () => { if (offset + pageSize < total) { offset += pageSize; pollingGeneration += 1; refreshOrders(); } });

async function transition(order, status) {
  if (busyOrders.has(order.id)) return;
  if (status === 'REJECTED' && !window.confirm(`Να απορριφθεί η παραγγελία #${order.number};`)) return;
  busyOrders.add(order.id);
  renderOrders();
  try {
    await api(`/api/admin/orders/${encodeURIComponent(order.id)}/transition`, {method: 'POST', body: JSON.stringify({status})});
    showMessage($('admin-message'), 'Η αλλαγή επιβεβαιώθηκε από το σύστημα.');
    await refreshOrders();
  } catch (error) {
    if (error.status === 401) setAuthenticated(false);
    else {
      showMessage($('admin-message'), error.status === 409 ? 'Η κατάσταση άλλαξε ή έληξε η προθεσμία. Γίνεται νέα ενημέρωση.' : error.message, 'error');
      await refreshOrders(false);
    }
  } finally { busyOrders.delete(order.id); renderOrders(); }
}

async function refreshOrders(clearMessage = true) {
  if (!authenticated) return;
  if (polling) { refreshQueued = true; return; }
  polling = true;
  const generation = pollingGeneration;
  try {
    const data = await api(`/api/admin/orders?status=${encodeURIComponent(filter)}&limit=${pageSize}&offset=${offset}`);
    if (generation !== pollingGeneration) { refreshQueued = true; return; }
    orders = data.orders;
    counts = data.counts || Object.fromEntries(['PENDING', 'ACCEPTED', 'REJECTED', 'COMPLETED'].map(status => [status, orders.filter(order => order.status === status).length]));
    total = data.total ?? orders.length;
    if (total && offset >= total) { offset = Math.max(0, Math.floor((total - 1) / pageSize) * pageSize); refreshQueued = true; return; }
    const pendingIds = new Set(data.pending_ids || orders.filter(order => order.status === 'PENDING').map(order => order.id));
    if ([...pendingIds].some(id => !seenPending.has(id))) playAlert();
    seenPending = pendingIds;
    renderOrders();
    $('last-update').textContent = `Ενημέρωση ${new Intl.DateTimeFormat('el-GR', {timeStyle: 'medium', timeZone: 'Europe/Athens'}).format(new Date())}`;
    if (clearMessage && $('admin-message').classList.contains('error')) showMessage($('admin-message'), 'Η σύνδεση αποκαταστάθηκε.');
  } catch (error) {
    if (error.status === 401) { setAuthenticated(false); showMessage($('login-message'), 'Η σύνδεση έληξε. Συνδέσου ξανά.', 'warning'); }
    else showMessage($('admin-message'), 'Δεν ανανεώθηκαν οι παραγγελίες. Τα δεδομένα μπορεί να είναι παλιά. ' + error.message, 'error');
  } finally {
    polling = false;
    if (refreshQueued) { refreshQueued = false; refreshOrders(false); }
  }
}

function renderSettings() {
  $('pause-button').disabled = settingsBusy;
  $('pause-button').textContent = acceptingOrders ? 'Παύση νέων παραγγελιών' : 'Επανέναρξη παραγγελιών';
  $('pause-button').setAttribute('aria-pressed', String(!acceptingOrders));
  showMessage($('accepting-state'), acceptingOrders ? 'Η λήψη δοκιμαστικών παραγγελιών είναι ενεργή.' : 'Η λήψη νέων παραγγελιών είναι σε παύση. Οι ήδη καταχωρισμένες παραγγελίες συνεχίζονται.', acceptingOrders ? 'subtle' : 'warning');
}

async function refreshSettings() {
  try { const settings = await api('/api/admin/settings'); acceptingOrders = settings.accepting_orders !== false; renderSettings(); }
  catch (error) { showMessage($('admin-message'), error.message, 'error'); }
}

$('pause-button').addEventListener('click', async () => {
  if (settingsBusy) return;
  settingsBusy = true; renderSettings();
  try {
    const result = await api('/api/admin/settings', {method: 'POST', body: JSON.stringify({accepting_orders: !acceptingOrders})});
    acceptingOrders = result.accepting_orders;
    showMessage($('admin-message'), 'Η ρύθμιση λήψης παραγγελιών αποθηκεύτηκε.');
  } catch (error) { showMessage($('admin-message'), error.message, 'error'); }
  finally { settingsBusy = false; renderSettings(); }
});

function renderAdminMenu() {
  const focused = document.activeElement?.id;
  $('admin-menu-list').replaceChildren();
  const visible = menuProducts.filter(product => normalize(`${product.name} ${product.category}`).includes(normalize(menuSearch)));
  if (!visible.length) $('admin-menu-list').append(element('p', 'muted', 'Δεν βρέθηκε προϊόν.'));
  for (const product of visible) {
    const row = element('div', 'admin-menu-row');
    const text = element('div');
    text.append(element('strong', '', product.name), element('span', 'small muted', `${product.category} · από ${money(product.price_cents)}`));
    const button = element('button', `button compact ${product.available ? 'secondary' : 'danger'}`, product.available ? 'Διαθέσιμο · Παύση' : 'Μη διαθέσιμο · Ενεργοποίηση');
    button.id = `availability-${product.id}`; button.type = 'button'; button.dataset.productId = product.id;
    button.setAttribute('aria-label', `${product.name}: ${product.available ? 'ορισμός ως μη διαθέσιμο' : 'ορισμός ως διαθέσιμο'}`);
    button.setAttribute('aria-pressed', String(product.available)); button.disabled = busyProducts.has(product.id);
    button.addEventListener('click', () => toggleAvailability(product));
    row.append(text, button); $('admin-menu-list').append(row);
  }
  if (focused) document.getElementById(focused)?.focus({preventScroll: true});
}

async function refreshAdminMenu() {
  try { const result = await api('/api/admin/menu'); menuProducts = result.products; renderAdminMenu(); }
  catch (error) { showMessage($('menu-management-message'), error.message, 'error'); }
}

async function toggleAvailability(product) {
  if (busyProducts.has(product.id)) return;
  busyProducts.add(product.id); renderAdminMenu();
  try {
    await api(`/api/admin/menu/${encodeURIComponent(product.id)}`, {method: 'POST', body: JSON.stringify({available: !product.available})});
    await refreshAdminMenu();
    showMessage($('menu-management-message'), `Η διαθεσιμότητα για ${product.name} ενημερώθηκε.`);
  } catch (error) { showMessage($('menu-management-message'), error.message, 'error'); }
  finally { busyProducts.delete(product.id); renderAdminMenu(); }
}

$('admin-menu-search').addEventListener('input', event => { menuSearch = event.target.value; renderAdminMenu(); });
$('refresh-admin-menu').addEventListener('click', refreshAdminMenu);

document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshOrders(); });
window.addEventListener('focus', () => refreshOrders());
window.addEventListener('online', () => refreshOrders());
setInterval(() => { if (!document.hidden) refreshOrders(); }, 5000);
setInterval(() => { tickCountdowns(); alertPending(); }, 1000);
api('/api/menu').then(data => { $('demo-banner').hidden = data.store?.demo === false; }).catch(() => {});
checkSession();
