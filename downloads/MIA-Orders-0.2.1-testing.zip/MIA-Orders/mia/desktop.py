"""Safe, local-only desktop startup for the MIA staff workstation."""

import argparse
import json
import os
import re
import shlex
import signal
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import webbrowser
from datetime import UTC, datetime
from pathlib import Path

from .config import Settings

ADMIN_KEYS = {"MIA_ADMIN_USERNAME", "MIA_ADMIN_PASSWORD_HASH"}
DESKTOP_STATE_VERSION = 1
FALLBACK_PORTS = range(8001, 8021)
WINDOWS_STATE_RENAME = os.name == "nt"


class NoHealthRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        # An unrelated listener must not turn a loopback readiness probe into an external request.
        return None


def load_admin_config(path: Path) -> dict[str, str]:
    """Read the generated config as data, never source/eval it as shell commands."""
    if not path.exists():
        return {}
    if not path.is_file() or path.stat().st_size > 16 * 1024:
        raise ValueError("Staff configuration is not a supported private configuration file")
    values = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        try:
            parts = shlex.split(raw, comments=False, posix=True)
        except ValueError:
            raise ValueError("Staff configuration has invalid quoting; it was not executed") from None
        if len(parts) != 2 or parts[0] != "export" or "=" not in parts[1]:
            raise ValueError("Staff configuration contains unsupported text; it was not executed")
        key, value = parts[1].split("=", 1)
        if key not in ADMIN_KEYS or key in values or not value:
            raise ValueError("Staff configuration contains unsupported or duplicate settings")
        if any(ord(char) < 32 for char in value):
            raise ValueError("Staff configuration contains invalid control characters")
        values[key] = value
    if set(values) != ADMIN_KEYS:
        raise ValueError("Staff configuration must contain a username and password hash")
    return values


def read_installation_id(database: Path) -> str | None:
    """Read only the non-authentication installation identifier of this local database."""
    if not database.is_file():
        return None
    try:
        with sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True, timeout=1) as connection:
            row = connection.execute("SELECT value FROM metadata WHERE key='installation_id'").fetchone()
    except sqlite3.Error:
        return None
    value = row[0] if row else None
    return value if isinstance(value, str) and re.fullmatch(r"[0-9a-f]{32}", value) else None


def is_expected_health(payload, installation_id: str | None, origin: str) -> bool:
    return bool(
        installation_id
        and isinstance(payload, dict)
        and payload.get("service") == "mia-orders"
        and payload.get("status") == "ok"
        and isinstance(payload.get("version"), str)
        and payload["version"].startswith("0.2.")
        and payload.get("installation_id") == installation_id
        and payload.get("public_origin") == origin
    )


def probe_server(origin: str) -> dict | None:
    # This function accepts only the launcher-generated numeric loopback origin.
    if not re.fullmatch(r"http://127\.0\.0\.1:[0-9]{1,5}", origin):
        raise ValueError("Desktop health checks are restricted to the local workstation")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoHealthRedirects())
    try:
        with opener.open(origin + "/api/health", timeout=1) as response:
            body = response.read(16 * 1024 + 1)
            if len(body) > 16 * 1024 or response.status != 200:
                return None
        value = json.loads(body)
        return value if isinstance(value, dict) else None
    except (OSError, urllib.error.URLError, ValueError, RecursionError):
        return None


def port_in_use(port: int) -> bool:
    """Test whether a new server can bind, including Windows excluded port ranges."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            # Windows SO_REUSEADDR can allow a second bind over another service.
            # Exclusive use also catches denied/excluded ports (WSAEACCES/10013).
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            listener.bind(("127.0.0.1", port))
    except OSError:
        return True
    return False


def _decode_desktop_state(contents: bytes) -> dict | None:
    def unique_object(pairs):
        value = dict(pairs)
        if len(value) != len(pairs):
            raise ValueError("Duplicate launcher state fields")
        return value

    try:
        if len(contents) > 4096:
            return None
        state = json.loads(contents.decode("utf-8"), object_pairs_hook=unique_object)
    except (UnicodeError, ValueError, RecursionError):
        return None
    if (
        not isinstance(state, dict)
        or set(state) != {"version", "installation_id", "port"}
        or type(state["version"]) is not int
        or state["version"] != DESKTOP_STATE_VERSION
        or not isinstance(state["installation_id"], str)
        or not re.fullmatch(r"[0-9a-f]{32}", state["installation_id"])
        or type(state["port"]) is not int
        or not 1 <= state["port"] <= 65535
    ):
        return None
    return state


def load_desktop_state(path: Path) -> dict | None:
    """Read only the bounded, non-secret launcher state; unknown files are not adopted."""
    try:
        if path.is_symlink() or not path.is_file():
            return None
        with path.open("rb") as stream:
            return _decode_desktop_state(stream.read(4097))
    except OSError:
        return None


def save_desktop_state(path: Path, installation_id: str, port: int) -> bool:
    """Atomically remember this installation's port without replacing an unknown file."""
    if (not isinstance(installation_id, str) or not re.fullmatch(r"[0-9a-f]{32}", installation_id)
            or type(port) is not int or not 1 <= port <= 65535):
        return False
    temporary = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if path.is_symlink():
            return False
        previous = None
        if path.exists():
            with path.open("rb") as stream:
                previous = stream.read(4097)
            state = _decode_desktop_state(previous)
            if state is None or state["installation_id"] != installation_id:
                return False
        descriptor, name = tempfile.mkstemp(prefix=".desktop-", suffix=".tmp", dir=path.parent)
        temporary = Path(name)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump({"version": DESKTOP_STATE_VERSION, "installation_id": installation_id, "port": port}, stream)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        if previous is None:
            # Windows rename refuses an existing destination and works on FAT
            # as well as NTFS. POSIX rename replaces existing files, so use an
            # exclusive hard link there. Neither can overwrite a file that
            # appeared while this state was being prepared.
            if WINDOWS_STATE_RENAME:
                os.rename(temporary, path)
            else:
                os.link(temporary, path)
        else:
            if path.is_symlink():
                return False
            with path.open("rb") as stream:
                current = stream.read(4097)
            if current != previous:
                return False
            os.replace(temporary, path)
        return True
    except OSError:
        # Remembering a port is optional; orders and private configuration are separate.
        return False
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass


def candidate_ports(preferred_port: int, saved_port: int | None = None) -> list[int]:
    return list(dict.fromkeys(port for port in (saved_port, preferred_port, *FALLBACK_PORTS) if port is not None))


def ephemeral_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        listener.bind(("127.0.0.1", 0))
        return listener.getsockname()[1]


def backup_before_start(database: Path, directory: Path) -> Path | None:
    """Keep a verified, consistent startup backup; never purge or overwrite previous backups."""
    if not database.exists():
        return None
    if not database.is_file():
        raise ValueError("Configured database is not a file")
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S.%fZ")
    destination = directory / f"mia-before-start-{stamp}.sqlite3"
    descriptor = os.open(destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(descriptor)
    try:
        with sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True) as source:
            with sqlite3.connect(destination) as target:
                source.backup(target)
                if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise RuntimeError("Existing database backup failed its integrity check")
    except BaseException:
        destination.unlink(missing_ok=True)
        raise
    return destination


def stop_owned_server(process: subprocess.Popen) -> None:
    if process.poll() is None:
        if os.name == "nt":
            try:
                # Uvicorn handles SIGBREAK; its dedicated process group lets Windows stop
                # the server gracefully without sending a signal to unrelated programs.
                process.send_signal(signal.CTRL_BREAK_EVENT)
            except OSError:
                process.terminate()
        else:
            process.terminate()
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def run(root: Path, *, no_browser: bool, skip_admin_init: bool) -> int:
    os.chdir(root)
    print("MIA Orders 0.2.1-testing")
    try:
        preferred_port = int(os.environ.get("MIA_PORT", "8000"))
    except ValueError:
        raise ValueError("MIA_PORT must be a number from 1 to 65535") from None
    if not 1 <= preferred_port <= 65535:
        raise ValueError("MIA_PORT must be a number from 1 to 65535")
    preferred_origin = f"http://127.0.0.1:{preferred_port}"
    # Capture the user's constraint before exporting any automatically selected origin.
    fixed_origin = os.environ.get("MIA_PUBLIC_ORIGIN")
    if fixed_origin is not None and fixed_origin != preferred_origin:
        raise ValueError("For desktop use, MIA_PUBLIC_ORIGIN must match the configured 127.0.0.1 port")
    database = Path(os.environ.get("MIA_DB_PATH", "runtime/mia.sqlite3"))
    state_path = root / "runtime/desktop.json"
    installation_id = read_installation_id(database)
    state = load_desktop_state(state_path)
    saved_port = state["port"] if state and state["installation_id"] == installation_id else None
    ports = [preferred_port] if fixed_origin is not None else candidate_ports(preferred_port, saved_port)
    attempted = set()
    ephemeral_attempts = 0

    def select_port() -> tuple[int, bool]:
        nonlocal ephemeral_attempts
        first_free = None
        # Search the bounded set for an existing verified server before creating
        # one, even when a stale saved port happens to be free now.
        for candidate in ports:
            if port_in_use(candidate):
                candidate_origin = f"http://127.0.0.1:{candidate}"
                if is_expected_health(probe_server(candidate_origin), read_installation_id(database), candidate_origin):
                    return candidate, True
            elif candidate not in attempted and first_free is None:
                first_free = candidate
        if first_free is not None:
            return first_free, False
        if fixed_origin is not None:
            raise RuntimeError(
                f"The fixed MIA_PUBLIC_ORIGIN address {fixed_origin} is unavailable or occupied by an unverified service. "
                "No process was stopped. Remove the explicit MIA_PUBLIC_ORIGIN setting to allow automatic local port "
                "selection, or configure MIA_PORT and MIA_PUBLIC_ORIGIN together to an available local port."
            )
        while ephemeral_attempts < 3:
            ephemeral_attempts += 1
            try:
                candidate = ephemeral_port()
            except OSError:
                continue
            if candidate not in attempted and not port_in_use(candidate):
                ports.append(candidate)
                return candidate, False
        raise RuntimeError(
            "No available local port could be opened. No other process was stopped. "
            "Check whether workstation security settings allow MIA to open a local server, then start MIA again."
        )

    def reuse_server(port: int) -> int:
        origin = f"http://127.0.0.1:{port}"
        identifier = read_installation_id(database)
        if identifier and not save_desktop_state(state_path, identifier, port):
            print("The launcher port could not be remembered; existing files were preserved.")
        print("MIA is already running for this installation. Existing data and server were preserved.")
        print(f"Staff: {origin}/admin")
        print(f"Customer test page: {origin}/")
        if not no_browser:
            webbrowser.open(origin + "/admin")
        return 0

    port, already_running = select_port()
    if already_running:
        return reuse_server(port)
    origin = f"http://127.0.0.1:{port}"
    os.environ["MIA_PUBLIC_ORIGIN"] = origin

    config_path = root / "runtime/admin.env"
    for key, value in load_admin_config(config_path).items():
        if not os.environ.get(key):
            os.environ[key] = value
    if not os.environ.get("MIA_ADMIN_PASSWORD_HASH"):
        if skip_admin_init:
            print("Staff login is unavailable until you initialize a private password with python -m mia.cli init-admin.")
        else:
            if not sys.stdin.isatty():
                raise RuntimeError(
                    "First staff setup needs an interactive terminal. Run this launcher in a terminal "
                    "or initialize the private password with python -m mia.cli init-admin."
                )
            username = os.environ.get("MIA_ADMIN_USERNAME", "admin")
            if not username or len(username) > 100 or any(ord(char) < 32 for char in username):
                raise ValueError("Configured staff username is invalid")
            print(f"First startup: create your staff password. Username: {username}. No default password exists.")
            result = subprocess.run(
                [sys.executable, "-m", "mia.cli", "init-admin", "--username", username], cwd=root,
            )
            if result.returncode:
                return result.returncode
            os.environ.update(load_admin_config(config_path))

    settings = Settings.from_env()
    settings.validate()
    backup = backup_before_start(database, root / "backups/startup")
    if backup:
        print("The existing database was backed up and verified before startup.")
    while True:
        origin = f"http://127.0.0.1:{port}"
        os.environ["MIA_PUBLIC_ORIGIN"] = origin
        command = [
            sys.executable, "-m", "uvicorn", "mia.app:app", "--host", "127.0.0.1",
            "--port", str(port), "--no-access-log", "--no-proxy-headers",
        ]
        process = subprocess.Popen(
            command, cwd=root,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
        )
        retry = False
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    # The availability check is deliberately repeated after a child
                    # exits: another program can claim the port between bind probe
                    # and Uvicorn startup. Retry only that conflict, not app errors.
                    if port_in_use(port):
                        retry = True
                        break
                    raise RuntimeError("The MIA server stopped during startup. Review the error above.")
                if is_expected_health(probe_server(origin), read_installation_id(database), origin):
                    break
                time.sleep(0.2)
            else:
                raise RuntimeError("MIA did not become ready within 20 seconds; only this launcher server was stopped.")
            if not retry:
                identifier = read_installation_id(database)
                if identifier and not save_desktop_state(state_path, identifier, port):
                    print("The launcher port could not be remembered; existing files were preserved.")
                if port != preferred_port:
                    print(f"MIA selected available local port {port} automatically.")
                print("MIA is ready for local testing with the real menu. Test orders do not charge customers.")
                print(f"Staff: {origin}/admin")
                print(f"Customer test page: {origin}/")
                print("Keep this terminal open. Press Ctrl+C here to stop MIA safely.")
                if not no_browser:
                    webbrowser.open(origin + "/admin")
                return process.wait()
        except KeyboardInterrupt:
            print("\nStopping this MIA server safely...")
            return 0
        finally:
            stop_owned_server(process)
        attempted.add(port)
        if fixed_origin is None:
            print(f"Local port {port} became unavailable during startup; trying another available port.")
        port, already_running = select_port()
        if already_running:
            return reuse_server(port)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--skip-admin-init", action="store_true")
    args = parser.parse_args(argv)
    try:
        return run(Path(__file__).resolve().parents[1], no_browser=args.no_browser,
                   skip_admin_init=args.skip_admin_init)
    except KeyboardInterrupt:
        print("\nMIA startup cancelled.")
        return 130
    except (OSError, sqlite3.Error, RuntimeError, ValueError) as error:
        print(f"MIA could not start: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
