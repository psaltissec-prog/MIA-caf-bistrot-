"""SQLite persistence; every state change uses an explicit transaction."""
import json
import os
import secrets
import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
    number INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    fulfillment TEXT NOT NULL CHECK (fulfillment = 'pickup'),
    notes TEXT NOT NULL,
    items_json TEXT NOT NULL,
    total_cents INTEGER NOT NULL CHECK (total_cents > 0),
    status TEXT NOT NULL CHECK (status IN ('PENDING','ACCEPTED','REJECTED','COMPLETED')),
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    rejected_at INTEGER,
    rejection_reason TEXT,
    demo INTEGER NOT NULL DEFAULT 1,
    idempotency_hash TEXT UNIQUE NOT NULL,
    request_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS orders_pending_expiry ON orders(status, expires_at);
CREATE INDEX IF NOT EXISTS orders_phone_time ON orders(phone, created_at);
CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL REFERENCES orders(id),
    status TEXT NOT NULL,
    reason TEXT,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS rate_limits (
    key TEXT PRIMARY KEY,
    count INTEGER NOT NULL,
    reset_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS catalog_overrides (
    product_id TEXT PRIMARY KEY,
    available INTEGER NOT NULL CHECK (available IN (0,1)),
    updated_at INTEGER NOT NULL,
    updated_by TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS store_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at INTEGER NOT NULL,
    updated_by TEXT NOT NULL
);
"""


class Database:
    def __init__(self, path: Path):
        self.path = Path(path)

    def connect(self):
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=10000")
        return connection

    def initialize(self):
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # SQLite derives journal/WAL permissions from the database file, so reserve
        # it privately before the first connection creates any auxiliary files.
        try:
            descriptor = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            self.path.chmod(0o600)
        else:
            os.close(descriptor)
        connection = self.connect()
        try:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.executescript(SCHEMA)
            connection.execute("INSERT OR IGNORE INTO metadata VALUES ('order_secret', ?)", (secrets.token_bytes(32),))
            connection.execute("INSERT OR IGNORE INTO metadata VALUES ('installation_id', ?)", (secrets.token_hex(16),))
            if connection.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise RuntimeError("Database integrity check failed")
        finally:
            connection.close()
        self.path.chmod(0o600)

    @contextmanager
    def transaction(self):
        connection = self.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def expire(self, connection, now: int):
        expired = connection.execute(
            "SELECT id FROM orders WHERE status='PENDING' AND expires_at<=?", (now,)
        ).fetchall()
        for row in expired:
            connection.execute(
                "UPDATE orders SET status='REJECTED', rejection_reason='AUTO_TIMEOUT_5_MIN', "
                "rejected_at=expires_at, updated_at=? WHERE id=? AND status='PENDING'",
                (now, row["id"]),
            )
            connection.execute(
                "INSERT INTO order_events(order_id,status,reason,created_at) "
                "SELECT id,'REJECTED','AUTO_TIMEOUT_5_MIN',expires_at FROM orders WHERE id=?",
                (row["id"],),
            )

    def consume_rate(self, key: str, now: int, limit: int, window: int) -> bool:
        with self.transaction() as connection:
            connection.execute("DELETE FROM rate_limits WHERE reset_at<=?", (now,))
            row = connection.execute("SELECT count FROM rate_limits WHERE key=?", (key,)).fetchone()
            if row and row["count"] >= limit:
                return False
            connection.execute(
                "INSERT INTO rate_limits VALUES (?,1,?) ON CONFLICT(key) "
                "DO UPDATE SET count=count+1", (key, now + window),
            )
            return True


def serialize_order(row) -> dict:
    return {
        key: row[key] for key in (
            "id", "number", "customer_name", "phone", "fulfillment", "notes",
            "total_cents", "status", "created_at", "expires_at", "updated_at",
            "rejected_at", "rejection_reason",
        )
    } | {"items": json.loads(row["items_json"]), "demo": bool(row["demo"])}
