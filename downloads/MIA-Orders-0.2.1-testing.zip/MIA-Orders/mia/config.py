"""Validated runtime configuration. No embedded credentials."""
import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit


def env_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    if value.lower() not in {"true", "false", "1", "0"}:
        raise ValueError(f"{name} must be true or false")
    return value.lower() in {"true", "1"}


@dataclass(frozen=True)
class Settings:
    db_path: Path = Path("runtime/mia.sqlite3")
    admin_username: str = "admin"
    admin_password_hash: str = ""
    public_origin: str = "http://127.0.0.1:8000"
    environment: str = "development"
    secure_cookie: bool = False
    live_orders: bool = False
    session_seconds: int = 8 * 60 * 60
    turnstile_site_key: str = ""
    turnstile_secret: str = ""

    def validate(self) -> None:
        try:
            origin = urlsplit(self.public_origin)
            origin.port
        except ValueError:
            raise ValueError("MIA_PUBLIC_ORIGIN must be an origin without path or credentials") from None
        if (origin.scheme not in {"http", "https"} or not origin.hostname
                or origin.path or origin.query or origin.fragment
                or origin.username is not None or origin.password is not None):
            raise ValueError("MIA_PUBLIC_ORIGIN must be an origin without path or credentials")
        if self.environment not in {"development", "test", "production"}:
            raise ValueError("MIA_ENV must be development, test or production")
        if self.session_seconds < 60 or self.session_seconds > 86400:
            raise ValueError("Session lifetime must be between 60 and 86400 seconds")
        if bool(self.turnstile_site_key) != bool(self.turnstile_secret):
            raise ValueError("Configure both Turnstile keys or neither")
        if self.environment == "production":
            if origin.scheme != "https" or not self.secure_cookie:
                raise ValueError("Production requires HTTPS and MIA_SECURE_COOKIE=true")
            if not self.admin_password_hash:
                raise ValueError("Production requires MIA_ADMIN_PASSWORD_HASH")
        if self.live_orders:
            raise ValueError(
                "Live orders are disabled: production deployment, delivery validation "
                "and customer verification must be configured and reviewed first"
            )
        if self.admin_password_hash:
            from .security import valid_password_hash
            if not valid_password_hash(self.admin_password_hash):
                raise ValueError("MIA_ADMIN_PASSWORD_HASH must be a supported scrypt hash")

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            db_path=Path(os.environ.get("MIA_DB_PATH", "runtime/mia.sqlite3")),
            admin_username=os.environ.get("MIA_ADMIN_USERNAME", "admin"),
            admin_password_hash=os.environ.get("MIA_ADMIN_PASSWORD_HASH", ""),
            public_origin=os.environ.get("MIA_PUBLIC_ORIGIN", "http://127.0.0.1:8000"),
            environment=os.environ.get("MIA_ENV", "development"),
            secure_cookie=env_bool("MIA_SECURE_COOKIE"),
            live_orders=env_bool("MIA_LIVE_ORDERS"),
            turnstile_site_key=os.environ.get("MIA_TURNSTILE_SITE_KEY", ""),
            turnstile_secret=os.environ.get("MIA_TURNSTILE_SECRET", ""),
        )
