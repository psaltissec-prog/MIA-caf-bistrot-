"""Local administrative commands. Passwords are read without terminal echo."""
import argparse
import getpass
import os
import shlex
import sqlite3
from pathlib import Path

from .security import hash_password


def main():
    parser = argparse.ArgumentParser(description="MIA Orders administration")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("hash-password", help="Generate a scrypt hash; never save a plaintext password")
    initialize = commands.add_parser("init-admin", help="Create private local admin configuration")
    initialize.add_argument("--username", default="admin")
    initialize.add_argument("--output", type=Path, default=Path("runtime/admin.env"))
    backup = commands.add_parser("backup", help="Create a consistent SQLite backup")
    backup.add_argument("source", type=Path)
    backup.add_argument("destination", type=Path)
    args = parser.parse_args()
    if args.command in {"hash-password", "init-admin"}:
        if args.command == "init-admin":
            if args.output.exists():
                parser.error("Admin configuration already exists; preserve it or explicitly remove it before recreating")
            if not args.username or len(args.username) > 100 or any(ord(c) < 32 for c in args.username):
                parser.error("Invalid admin username")
        password = getpass.getpass("Admin password (at least 12 characters): ")
        if password != getpass.getpass("Confirm password: "):
            parser.error("Passwords did not match")
        try:
            encoded = hash_password(password)
        except ValueError as error:
            parser.error(str(error))
        if args.command == "hash-password":
            print(encoded)
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            descriptor = os.open(args.output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(descriptor, "w") as output:
                output.write("export MIA_ADMIN_USERNAME=" + shlex.quote(args.username) + "\n")
                output.write("export MIA_ADMIN_PASSWORD_HASH=" + shlex.quote(encoded) + "\n")
            print("Private admin configuration created. No plaintext password was saved.")
    elif args.command == "backup":
        if not args.source.is_file():
            parser.error("Source database does not exist")
        if args.source.resolve() == args.destination.resolve():
            parser.error("Backup destination must differ from source")
        args.destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # Exclusive reservation prevents accidental overwrite of an earlier backup.
        descriptor = os.open(args.destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(descriptor)
        try:
            with sqlite3.connect(args.source.resolve().as_uri() + "?mode=ro", uri=True) as source:
                with sqlite3.connect(args.destination) as destination:
                    source.backup(destination)
                    if destination.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                        raise RuntimeError("Backup integrity check failed")
        except BaseException:
            args.destination.unlink(missing_ok=True)
            raise
        print("Backup created and integrity checked.")


if __name__ == "__main__":
    main()
