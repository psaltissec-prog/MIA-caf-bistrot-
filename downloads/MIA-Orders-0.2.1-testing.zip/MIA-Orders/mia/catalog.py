"""Validated catalogue imported from the owner's corrected menu.

The menu is real; demo=True describes the ordering mode, not fabricated products.
Consumers receive independent copies so per-request availability cannot mutate
the canonical source catalogue.
"""

from __future__ import annotations

import copy
import json
import re
from pathlib import Path

CATALOG_PATH = Path(__file__).resolve().parents[1] / "data" / "menu" / "catalog.json"
IDENTIFIER = re.compile(r"[a-z0-9][a-z0-9-]{0,79}\Z")


def _validate(data: dict) -> None:
    if not isinstance(data, dict) or data.get("schema_version") != 1 or data.get("currency") != "EUR":
        raise ValueError("Unsupported catalogue schema or currency")
    products = data.get("products")
    if not isinstance(products, list) or not products or len(products) != data.get("product_count"):
        raise ValueError("Missing or inconsistent catalogue products")
    product_ids = set()
    price_count = 0
    for product in products:
        if not isinstance(product, dict):
            raise ValueError("Every catalogue product must be an object")
        identifier = product.get("id", "")
        if not isinstance(identifier, str) or not IDENTIFIER.fullmatch(identifier) or identifier in product_ids:
            raise ValueError("Invalid or duplicate product identifier")
        product_ids.add(identifier)
        if not all(isinstance(product.get(key), str) and product[key] for key in ("name", "category")):
            raise ValueError("Product name and category are required")
        if not isinstance(product.get("description"), str) or type(product.get("available")) is not bool:
            raise ValueError("Invalid product description or availability")
        variants = product.get("variants")
        if not isinstance(variants, list) or not variants:
            raise ValueError("Every product requires a price variant")
        seen_variants = set()
        for variant in variants:
            if not isinstance(variant, dict):
                raise ValueError("Every catalogue variant must be an object")
            vid = variant.get("id", "")
            if not isinstance(vid, str) or not IDENTIFIER.fullmatch(vid) or vid in seen_variants:
                raise ValueError("Invalid or duplicate variant identifier")
            if not isinstance(variant.get("label"), str) or not variant["label"]:
                raise ValueError("Variant label is required")
            price = variant.get("price_cents")
            if type(price) is not int or not 0 < price <= 50000:
                raise ValueError("Prices must be positive integer cents")
            seen_variants.add(vid)
            price_count += 1
        if product.get("price_cents") != min(v["price_cents"] for v in variants):
            raise ValueError("Product minimum price differs from its variants")
        group_ids = set()
        groups = product.get("option_groups")
        if not isinstance(groups, list):
            raise ValueError("Invalid option groups")
        for group in groups:
            if not isinstance(group, dict):
                raise ValueError("Every option group must be an object")
            gid = group.get("id", "")
            if (not isinstance(gid, str) or not IDENTIFIER.fullmatch(gid) or gid in group_ids
                    or type(group.get("required")) is not bool
                    or not isinstance(group.get("label"), str) or not group["label"]):
                raise ValueError("Invalid option group")
            group_ids.add(gid)
            options = group.get("options")
            if not isinstance(options, list) or not options:
                raise ValueError("An option group requires options")
            option_ids = set()
            for option in options:
                if not isinstance(option, dict):
                    raise ValueError("Every catalogue option must be an object")
                oid = option.get("id", "")
                if (not isinstance(oid, str) or not IDENTIFIER.fullmatch(oid) or oid in option_ids
                        or not isinstance(option.get("label"), str) or not option["label"]):
                    raise ValueError("Invalid or duplicate option")
                option_ids.add(oid)
    if price_count != data.get("price_option_count"):
        raise ValueError("Catalogue price count mismatch")
    if any("Fresh garden Lentil" in p["name"] for p in products):
        raise ValueError("Owner-removed product present in catalogue")


def load_catalog(path: Path | None = None) -> list[dict]:
    data = json.loads((path or CATALOG_PATH).read_text(encoding="utf-8"))
    _validate(data)
    return copy.deepcopy(data["products"])


def catalog_metadata() -> dict:
    data = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    _validate(data)
    return {key: data[key] for key in (
        "catalog_version", "source_filename", "source_sha256", "product_count", "price_option_count",
    )}


STORE = {
    "name": "MIA café bistrot",
    "currency": "EUR",
    "demo": True,
    "live_orders": False,
    "delivery_enabled": False,
    "catalog_source": "owner_menu",
    "catalog_version": catalog_metadata()["catalog_version"],
    "catalog_products": 123,
    "catalog_price_options": 215,
    "address": "Ηρώων Πολυτεχνείου 17, Χαλάνδρι",
    "phone": "+302106728888",
    "email": "miacafe@outlook.com.gr",
    "opening_time": "09:00",
    "closing_time": "17:00",
    "timezone": "Europe/Athens",
    "opening_days": [1, 2, 3, 4, 5, 6, 7],
}
