"""Password hashing and opaque-token helpers."""
import base64
import hashlib
import hmac
import secrets

SCRYPT_N = 32768
SCRYPT_P = 3


def hash_password(password: str) -> str:
    if len(password) < 12 or len(password) > 1024:
        raise ValueError("Use a password of 12–1024 characters")
    salt = secrets.token_bytes(16)
    key = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=8, p=SCRYPT_P, dklen=32, maxmem=64 * 1024 * 1024)
    return "scrypt$32768$8$3$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(key).decode()


def valid_password_hash(encoded: str) -> bool:
    try:
        method, n, r, p, salt, key = encoded.split("$")
        return (method == "scrypt" and (n, r, p) == ("32768", "8", "3")
                and len(base64.b64decode(salt, validate=True)) == 16
                and len(base64.b64decode(key, validate=True)) == 32)
    except (ValueError, TypeError):
        return False


def verify_password(password: str, encoded: str) -> bool:
    if not valid_password_hash(encoded) or len(password) > 1024:
        return False
    _, _, _, _, salt, expected = encoded.split("$")
    actual = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt),
                            n=SCRYPT_N, r=8, p=SCRYPT_P, dklen=32, maxmem=64 * 1024 * 1024)
    return hmac.compare_digest(actual, base64.b64decode(expected))


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def order_token(secret: bytes, order_id: str) -> str:
    return hmac.new(secret, ("order:" + order_id).encode(), hashlib.sha256).hexdigest()
