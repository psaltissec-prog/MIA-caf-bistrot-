"""Create/reuse a private runtime environment, then start the local MIA desktop workflow."""

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import venv
from pathlib import Path


class DependencyInstallError(RuntimeError):
    def __init__(self, message: str, exit_code: int):
        super().__init__(message)
        self.exit_code = exit_code


def pinned_requirements(path: Path) -> dict[str, str]:
    """Accept only the reviewed, exact runtime pins; never interpret shell text."""
    pins = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9][A-Za-z0-9_.-]*)==([A-Za-z0-9][A-Za-z0-9_.+!-]*)", line)
        if not match:
            raise ValueError("Runtime requirements must contain exact package==version pins")
        name, version = match.groups()
        if name in pins:
            raise ValueError("Runtime requirements contain a duplicate package")
        pins[name] = version
    if not pins:
        raise ValueError("Runtime requirements are empty")
    return pins


def requirements_fingerprint(path: Path) -> dict:
    return {
        "requirements_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bootstrap_python": list(sys.version_info[:2]),
        "platform": sys.platform,
    }


def venv_python_path(path: Path, windows: bool | None = None) -> Path:
    windows = os.name == "nt" if windows is None else windows
    return path / ("Scripts/python.exe" if windows else "bin/python")


def runtime_ready(python: Path, requirements: Path) -> bool:
    """Check installed metadata and imports on every start; successful starts need no Internet."""
    if not python.is_file():
        return False
    pins = pinned_requirements(requirements)
    probe = (
        "import importlib.metadata as m,json,sys; "
        "assert sys.version_info >= (3,12); "
        "pins=json.loads(sys.argv[1]); "
        "assert all(m.version(k)==v for k,v in pins.items()); "
        "import fastapi,uvicorn,httpx; "
        "from zoneinfo import ZoneInfo; ZoneInfo('Europe/Athens')"
    )
    try:
        result = subprocess.run(
            [str(python), "-c", probe, json.dumps(pins)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def ensure_runtime(root: Path, venv_path: Path) -> Path:
    if sys.version_info < (3, 12):
        raise RuntimeError("Install Python 3.12 or newer from python.org, then run this launcher again.")
    requirements = root / "requirements.txt"
    pinned_requirements(requirements)
    if venv_path.exists() and not (venv_path / "pyvenv.cfg").is_file():
        if any(venv_path.iterdir()):
            raise RuntimeError("Selected runtime folder is not a virtual environment; choose an empty folder.")
    if not (venv_path / "pyvenv.cfg").is_file():
        print("Creating the local Python environment...")
        venv.EnvBuilder(with_pip=True).create(venv_path)
    python = venv_python_path(venv_path)
    if not runtime_ready(python, requirements):
        print("Installing the reviewed runtime dependencies. Internet is needed for this step.")
        result = subprocess.run(
            [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(requirements)],
            cwd=root,
        )
        if result.returncode:
            raise DependencyInstallError(
                "Dependency installation failed. Keep TLS verification enabled, check the connection "
                "and retry this launcher. Existing orders and staff settings were preserved.",
                result.returncode,
            )
        if not runtime_ready(python, requirements):
            raise RuntimeError("Installed dependencies could not be verified. The application was not started.")
    marker = venv_path / ".mia-runtime.json"
    content = json.dumps(requirements_fingerprint(requirements), indent=2) + "\n"
    if not marker.exists() or marker.read_text(encoding="utf-8") != content:
        marker.write_text(content, encoding="utf-8")
    if os.name != "nt":
        marker.chmod(0o600)
    return python


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true", help="Keep the browser closed")
    parser.add_argument("--skip-admin-init", action="store_true", help="Do not prompt for first-run staff setup")
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parent
    selected_venv = Path(os.environ.get("MIA_VENV_PATH", str(root / ".venv"))).expanduser()
    if not selected_venv.is_absolute():
        selected_venv = root / selected_venv
    try:
        python = ensure_runtime(root, selected_venv.resolve())
        command = [str(python), "-m", "mia.desktop"]
        if args.no_browser:
            command.append("--no-browser")
        if args.skip_admin_init:
            command.append("--skip-admin-init")
        return subprocess.run(command, cwd=root).returncode
    except KeyboardInterrupt:
        print("\nMIA startup stopped.")
        return 130
    except DependencyInstallError as error:
        print(f"MIA could not start: {error}", file=sys.stderr)
        return error.exit_code
    except subprocess.SubprocessError as error:
        print(f"MIA environment setup failed: {error}", file=sys.stderr)
        return getattr(error, "returncode", 1)
    except (OSError, RuntimeError, ValueError) as error:
        print(f"MIA could not start: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
