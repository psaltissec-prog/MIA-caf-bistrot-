#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"
MIA_VENV_PATH="${MIA_VENV_PATH:-$PROJECT_ROOT/.venv}"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-$MIA_VENV_PATH/.pip-cache}"
"$MIA_VENV_PATH/bin/python" -m pip check
"$MIA_VENV_PATH/bin/python" -m ruff check mia tests scripts START_MIA_ORDERS.py
"$MIA_VENV_PATH/bin/python" -m pytest --cov=mia --cov-report=term-missing
if command -v node >/dev/null 2>&1; then
  for file in mia/static/*.js; do node --check "$file"; done
fi
