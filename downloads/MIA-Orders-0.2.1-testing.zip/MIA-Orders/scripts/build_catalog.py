"""Build the application catalogue from the owner's corrected Word and extracted prices.

This is a source-preserving import, not a price generator. Run from any directory:
    python scripts/build_catalog.py
No third-party packages are required.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path
from xml.etree import ElementTree
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
MENU_ROOT = ROOT / "data" / "menu"
PRICE = re.compile(r"(\d+),(\d{2})\s*€")
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

CATEGORY_LABELS = {
    "Coffees / ΖΕΣΤΑ / HOT": "Ζεστοί καφέδες",
    "Coffees / ΚΡΥΑ/ICED": "Κρύοι καφέδες",
    "ΤΣΑΪ / TEA": "Τσάι",
    "ΚΡΥΟ ΤΣΑΪ ΜΕ ΑΓΑΥΗ/ ICED TEA WITH AGAVE": "Κρύο τσάι με αγαύη",
    "ΣΟΚΟΛΑΤΑ ΖΕΣΤΗ - ΚΡΥΑ / HOT - COLD CHOCOLATE": "Σοκολάτες & κακάο",
    "MIACCINO ICE BLENDED": "Miaccino",
    "MILKSHAKE THICK & CREAMY": "Milkshakes",
    "SMOOTHIE FRESHLY BLENDED": "Smoothies",
    "ΓΡΑΝΙΤΑ / GRANITA REFRESHING & ICE COLD": "Γρανίτες",
    "ΧΥΜΟΙ / JUICES 100% FRESH": "Φρέσκοι χυμοί",
    "ΑΝΑΨΥΚΤΙΚΑ & ENERGY DRINKS": "Αναψυκτικά & energy drinks",
    "BRUNCH": "Brunch",
    "YOGURTS": "Γιαούρτια",
    "SALADS": "Σαλάτες",
    "SANDWICHES": "Sandwiches",
    "CLUB SANDWICHES": "Club sandwiches & τοστ",
    "BURGERS": "Burgers",
    "ΓΕΥΜΑΤΑ / MAIN DISHES": "Κυρίως πιάτα",
    "PASTA": "Ζυμαρικά",
    "ΠΑΙΔΙΚΑ ΓΕΥΜΑΤΑ / KIDS MENU": "Παιδικά γεύματα",
    "HANDMADE DESSERTS": "Χειροποίητα γλυκά",
    "SWEET PANCAKES": "Γλυκά pancakes",
    "SWEET WAFFLES": "Γλυκές βάφλες",
    "CROISSANTS": "Κρουασάν",
}

KNOWN_IDS = {
    ("Coffees / ΖΕΣΤΑ / HOT", "Espresso"): "espresso",
    ("Coffees / ΖΕΣΤΑ / HOT", "Cappuccino"): "cappuccino",
    ("Coffees / ΚΡΥΑ/ICED", "Freddo Espresso"): "freddo-espresso",
    ("Coffees / ΚΡΥΑ/ICED", "Freddo Cappuccino"): "freddo-cappuccino",
    ("ΧΥΜΟΙ / JUICES 100% FRESH", "Φυσικός χυμός πορτοκάλι / Fresh Orange Juice"): "orange-juice",
    ("CLUB SANDWICHES", "Τοστ ζαμπόν / γαλοπούλα, τυρί / Ham / Turkey & Cheese Toast"): "toast",
    ("CROISSANTS", "Κρουασάν βουτύρου / Butter Croissant"): "croissant",
}


def slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", normalized).strip("-") or "item"


def group(identifier: str, label: str, options: list[tuple[str, str]]) -> dict:
    return {
        "id": identifier,
        "label": label,
        "required": True,
        "options": [{"id": identifier, "label": title} for identifier, title in options],
    }


def choices(entry: dict) -> list[dict]:
    name, section = entry["name"], entry["section"]
    if name == "Πράσινο / Green Tea":
        return [group("flavor", "Γεύση τσαγιού", [
            ("wellness", "Ευεξίας"), ("mint", "Μέντα"), ("classic", "Κλασσικό"),
            ("spices", "Μπαχαρικά"), ("forest-fruits", "Φρούτα του δάσους"),
        ])]
    if name == "Κόκκινο / Red Tea":
        return [group("flavor", "Γεύση τσαγιού", [
            ("red-garden", "Κόκκινος κήπος"), ("city-aroma", "Άρωμα πόλης"),
        ])]
    if name == "Μαύρο τσάι / Black Tea":
        return [group("flavor", "Γεύση τσαγιού", [
            ("garden-of-eden", "Ο κήπος της Εδέμ"), ("earl-grey", "Earl Grey"),
            ("english-breakfast", "English breakfast"),
        ])]
    if section == "SMOOTHIE FRESHLY BLENDED":
        return [group("flavor", "Γεύση smoothie", [
            ("mia", "MIA'S"), ("watermelon", "Watermelon"), ("strawberry", "Strawberry"),
            ("mango-passion", "Mango Passion"), ("protein", "Protein"),
        ])]
    if section == "ΓΡΑΝΙΤΑ / GRANITA REFRESHING & ICE COLD":
        return [group("flavor", "Γεύση γρανίτας", [
            ("strawberry", "Strawberry"), ("watermelon", "Watermelon"), ("passion", "Passion"),
        ])]
    if name == "Coca-Cola / Zero / Πορτοκαλάδα / Λεμονάδα / Σόδα":
        return [group("flavor", "Αναψυκτικό", [
            ("coca-cola", "Coca-Cola"), ("coca-cola-zero", "Coca-Cola Zero"),
            ("orange", "Πορτοκαλάδα"), ("lemon", "Λεμονάδα"), ("soda", "Σόδα"),
        ])]
    if name == "Χυμός πορτοκάλι / Motion":
        return [group("flavor", "Χυμός", [("orange", "Πορτοκάλι"), ("motion", "Motion")])]
    if name == "Red Bull 0,25lt / Monster 0,5lt":
        return [group("flavor", "Energy drink", [
            ("red-bull", "Red Bull 0,25 lt"), ("monster", "Monster 0,5 lt"),
        ])]
    if name == "Τοστ ζαμπόν / γαλοπούλα, τυρί / Ham / Turkey & Cheese Toast":
        return [group("filling", "Γέμιση τοστ", [
            ("ham", "Ζαμπόν & τυρί"), ("turkey", "Γαλοπούλα & τυρί"),
        ])]
    if name in {
        "Ζουμερό φιλέτο κοτόπουλο / Juicy Chicken Fillet",
        "Χειροποίητα μοσχαρίσια μπιφτέκια / Handmade Beef Patties",
    }:
        return [group("side", "Συνοδευτικό", [("rice", "Ρύζι"), ("fries", "Πατάτες τηγανητές")])]
    if name == "Carbonara al Pancetta":
        return [group("pasta", "Ζυμαρικό", [("spaghetti", "Spaghetti"), ("rigatoni", "Rigatoni")])]
    if name == "Waffle Black or White":
        return [group("praline", "Πραλίνα", [
            ("hazelnut", "Πραλίνα φουντουκιού"), ("white", "Λευκή πραλίνα"),
        ])]
    if section == "ΣΟΚΟΛΑΤΑ ΖΕΣΤΗ - ΚΡΥΑ / HOT - COLD CHOCOLATE":
        return [group("temperature", "Θερμοκρασία", [("hot", "Ζεστή"), ("cold", "Κρύα")])]
    return []


def read_paragraphs(source: Path) -> list[str]:
    with ZipFile(source) as archive:
        if archive.getinfo("word/document.xml").file_size > 2_000_000:
            raise ValueError("Unexpected oversized menu document")
        document = ElementTree.fromstring(archive.read("word/document.xml"))
    paragraphs = []
    for paragraph in document.findall(".//w:p", NS):
        parts = []
        for node in paragraph.iter():
            if node.tag == "{" + NS["w"] + "}t":
                parts.append(node.text or "")
            elif node.tag == "{" + NS["w"] + "}tab":
                parts.append("\t")
            elif node.tag in {"{" + NS["w"] + "}br", "{" + NS["w"] + "}cr"}:
                parts.append("\n")
        paragraphs.append("".join(parts))
    return paragraphs


def description_for(entry: dict, position: int, entries: list[dict], paragraphs: list[str]) -> str:
    current = entry["current_paragraph"] - 1
    start = paragraphs[current]
    matches = list(PRICE.finditer(start))
    if not matches:
        raise ValueError(f"Missing source price in paragraph {current + 1}")
    parts = [start[matches[-1].end():].strip()]
    end = entries[position + 1]["current_paragraph"] - 1 if position + 1 < len(entries) else len(paragraphs)
    headings = set(CATEGORY_LABELS) | {"BEVERAGES & DRINKS", "Coffees"}
    for text in paragraphs[current + 1:end]:
        text = text.strip()
        if not text:
            continue
        if text in headings or text.startswith(("ΖΕΣΤΑ / HOT", "ΚΡΥΑ/ICED")):
            break
        if ("Solo/Doppio" in text or "Petit/ Medio/ Grande" in text
                or re.fullmatch(r"[\d\s/mMlL]+", text)
                or text.startswith(("Ρωτήστε μας", "Ηρώων Πολυτεχνείου"))):
            continue
        parts.append(text)
    return "\n".join(part for part in parts if part)


def build() -> dict:
    extracted = json.loads((MENU_ROOT / "menu-current.json").read_text(encoding="utf-8"))
    source = MENU_ROOT / extracted["source_filename"]
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    if digest != extracted["sha256"]:
        raise ValueError("Corrected Word checksum differs from the owner-reviewed extraction")
    paragraphs = read_paragraphs(source)
    entries = extracted["entries"]
    products = []
    for position, entry in enumerate(entries):
        prices = entry["prices_cents"]
        if len(prices) == 1:
            sizes = [("standard", "Κανονικό")]
        elif len(prices) == 2:
            sizes = [("solo", "Solo"), ("doppio", "Doppio")]
        elif len(prices) == 3:
            sizes = [("petit", "Petit"), ("medio", "Medio"), ("grande", "Grande")]
        else:
            raise ValueError("Unsupported source price count")
        source_prices = [int(m[1]) * 100 + int(m[2]) for m in PRICE.finditer(paragraphs[entry["current_paragraph"] - 1])]
        if source_prices != prices:
            raise ValueError(f"Price mismatch for {entry['name']}")
        identifier = KNOWN_IDS.get((entry["section"], entry["name"]))
        if identifier is None:
            identifier = f"mia-{entry['source_paragraph']:03d}-{slug(entry['name'])[:60]}"
        product = {
            "id": identifier,
            "source_paragraph": entry["source_paragraph"],
            "current_paragraph": entry["current_paragraph"],
            "name": entry["name"],
            "description": description_for(entry, position, entries, paragraphs),
            "category": CATEGORY_LABELS[entry["section"]],
            "source_section": entry["section"],
            "price_cents": min(prices),
            "available": True,
            "variants": [{"id": identifier, "label": label, "price_cents": price}
                         for (identifier, label), price in zip(sizes, prices, strict=True)],
            "option_groups": choices(entry),
        }
        products.append(product)
    if len(products) != 123 or sum(len(p["variants"]) for p in products) != 215:
        raise ValueError("Unexpected owner-approved catalogue counts")
    if [v["price_cents"] for p in products for v in p["variants"]] != [
            price for entry in entries for price in entry["prices_cents"]]:
        raise ValueError("Catalogue price audit failed")
    return {
        "schema_version": 1,
        "catalog_version": digest[:12],
        "currency": "EUR",
        "source_filename": source.name,
        "source_sha256": digest,
        "source_type": "owner_corrected_menu",
        "product_count": len(products),
        "price_option_count": sum(len(p["variants"]) for p in products),
        "size_policy": "Prices in source order. Solo/Doppio for two-price rows; Petit/Medio/Grande for three-price rows. Volumes are not inferred for categories without explicit labels.",
        "products": products,
    }


def main():
    catalogue = build()
    destination = MENU_ROOT / "catalog.json"
    destination.write_text(json.dumps(catalogue, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Imported {catalogue['product_count']} products and {catalogue['price_option_count']} prices; source SHA-256 verified.")


if __name__ == "__main__":
    main()
