"""Real-browser workflow test using isolated temporary data and credentials.

Run with Python application dependencies, Playwright and system Chromium:
    python scripts/browser_smoke.py --screenshots /tmp/mia-browser
No real orders, external providers or persistent credentials are used.
"""
import argparse
import secrets
import socket
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path

import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mia.app import create_app  # noqa: E402
from mia.config import Settings  # noqa: E402
from mia.security import hash_password  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chromium", default="/usr/bin/chromium")
    parser.add_argument("--screenshots", type=Path)
    args = parser.parse_args()
    try:
        from playwright.sync_api import expect, sync_playwright
    except ImportError:
        raise SystemExit("Browser check needs the optional Python playwright package") from None
    if not Path(args.chromium).is_file():
        raise SystemExit("Chromium not found; supply --chromium /path/to/chromium")
    if args.screenshots:
        args.screenshots.mkdir(parents=True, exist_ok=True)
    with socket.socket() as socket_probe:
        socket_probe.bind(("127.0.0.1", 0))
        port = socket_probe.getsockname()[1]
    origin = f"http://127.0.0.1:{port}"
    password = secrets.token_urlsafe(24)
    with tempfile.TemporaryDirectory(prefix="mia-browser-") as temporary:
        app = create_app(Settings(
            db_path=Path(temporary) / "test.sqlite3",
            public_origin=origin,
            admin_password_hash=hash_password(password),
        ))
        server = uvicorn.Server(uvicorn.Config(
            app, host="127.0.0.1", port=port, log_level="error", proxy_headers=False,
        ))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            for _ in range(100):
                if server.started:
                    break
                time.sleep(0.05)
            if not server.started:
                raise RuntimeError("Test HTTP server failed to start")
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(
                    executable_path=args.chromium, headless=True, args=["--no-sandbox"],
                )
                try:
                    errors = []
                    customer = browser.new_page(viewport={"width": 1440, "height": 1000})
                    customer.on("pageerror", lambda error: errors.append(str(error)))
                    customer.goto(origin)
                    expect(customer.locator(".product-card")).to_have_count(123)
                    expect(customer.locator("#store-details")).to_contain_text("Ηρώων")
                    menu = customer.request.get(origin + "/api/menu").json()
                    assert sum(len(p["variants"]) for p in menu["products"]) == 215
                    assert not any("Fresh garden Lentil" in p["name"] for p in menu["products"])
                    penne = next(p for p in menu["products"] if p["name"].startswith("Penne Pomodoro"))
                    assert "vegan" not in penne["name"].lower()
                    coffee = next(p for p in menu["products"] if p["name"] == "Freddo Espresso")
                    customer.locator("#menu-search").fill("FREDDO ESPRESSO")
                    expect(customer.locator(".product-card")).to_have_count(1)
                    card = customer.locator(f'[data-product-id="{coffee["id"]}"]')
                    second, third = coffee["variants"][1:3]
                    card.locator(".variant-select").select_option(second["id"])
                    card.locator(".add-button").click()
                    card.locator(".variant-select").select_option(third["id"])
                    card.locator(".add-button").click()
                    expect(customer.locator(".cart-item")).to_have_count(2)
                    customer.locator("#customer-name").fill("Δοκιμή Πελάτη")
                    customer.locator("#customer-phone").fill("6912345678")
                    with customer.expect_response(lambda r: r.request.method == "POST" and r.url == origin + "/api/orders") as posted:
                        customer.locator("#checkout-button").click()
                    created = posted.value.json()["order"]
                    assert created["total_cents"] == second["price_cents"] + third["price_cents"]
                    expect(customer.locator("#tracking-status")).to_have_text("Αναμονή αποδοχής")
                    if args.screenshots:
                        customer.screenshot(path=str(args.screenshots / "customer-desktop.png"))

                    admin_context = browser.new_context(viewport={"width": 1440, "height": 1000})
                    admin = admin_context.new_page()
                    admin.on("pageerror", lambda error: errors.append(str(error)))
                    admin.goto(origin + "/admin")
                    admin.locator("#username").fill("admin")
                    admin.locator("#password").fill(password)
                    admin.locator("#login-button").click()
                    expect(admin.locator(".order-card")).to_have_count(1)
                    if args.screenshots:
                        admin.screenshot(path=str(args.screenshots / "admin-desktop.png"))
                    with admin.expect_popup() as receipt_popup:
                        admin.locator(".receipt-link").click()
                    receipt = receipt_popup.value
                    expect(receipt.locator("#print-receipt")).to_be_visible()
                    expect(receipt.locator("body")).to_contain_text("Δοκιμή Πελάτη")
                    receipt.close()
                    assert admin.request.get(origin + "/api/admin/orders.csv").status == 200
                    admin.get_by_role("button", name="Αποδοχή", exact=False).click()
                    customer.bring_to_front()
                    expect(customer.locator("#tracking-status")).to_have_text("Σε προετοιμασία", timeout=10000)
                    admin.bring_to_front()
                    admin.locator('[data-status="ACCEPTED"]').click()
                    admin.get_by_role("button", name="Ολοκλήρωση παραγγελίας").click()
                    customer.bring_to_front()
                    expect(customer.locator("#tracking-status")).to_have_text("Ολοκληρώθηκε", timeout=10000)
                    customer.locator("#tracking-clear").click()

                    lost_orders = []

                    def lose_first_response(route):
                        if not lost_orders:
                            response = route.fetch()
                            assert response.status == 201
                            lost_orders.append(response.json()["order"])
                            route.abort("failed")
                        else:
                            route.continue_()

                    customer.route("**/api/orders", lose_first_response)
                    customer.locator(".add-button").first.click()
                    customer.locator("#customer-name").fill("Δοκιμή Επανάληψης")
                    customer.locator("#customer-phone").fill("6998765432")
                    customer.locator("#checkout-button").click()
                    expect(customer.locator("#checkout-message")).to_contain_text("Το αποτέλεσμα είναι άγνωστο")
                    customer.reload()
                    expect(customer.locator("#checkout-message")).to_contain_text("Βρέθηκε αποστολή")
                    expect(customer.locator("#customer-name")).to_be_disabled()
                    customer.locator("#checkout-button").click()
                    expect(customer.locator("#tracking-number")).to_contain_text(f"#{lost_orders[0]['number']}")
                    assert customer.evaluate("sessionStorage.getItem('mia-pending-submission')") is None

                    admin.bring_to_front()
                    admin.locator("#pause-button").click()
                    expect(admin.locator("#accepting-state")).to_contain_text("σε παύση")
                    guest = browser.new_page(viewport={"width": 390, "height": 844})
                    guest.on("pageerror", lambda error: errors.append(str(error)))
                    guest.goto(origin)
                    expect(guest.locator("#store-state")).to_contain_text("σε παύση")
                    expect(guest.locator(".add-button").first).to_be_disabled()
                    admin.locator("#pause-button").click()
                    expect(admin.locator("#accepting-state")).to_contain_text("είναι ενεργή")
                    guest.locator("#refresh-menu").click()
                    guest.locator("#menu-search").fill("Freddo Espresso")
                    guest.locator(".add-button").click()
                    expect(guest.locator(".cart-item")).to_have_count(1)
                    admin.locator("#menu-management > summary").click()
                    admin.locator("#admin-menu-search").fill("Freddo Espresso")
                    availability = admin.locator(f'#availability-{coffee["id"]}')
                    availability.click()
                    expect(availability).to_have_attribute("aria-pressed", "false")
                    guest.locator("#refresh-menu").click()
                    guest.locator("#menu-search").fill("Freddo Espresso")
                    expect(guest.locator(".add-button")).to_be_disabled()
                    expect(guest.locator("#checkout-button")).to_be_disabled()
                    expect(guest.locator(".unavailable-warning")).to_be_visible()
                    guest.locator(".remove-button").click()
                    availability.click()
                    expect(availability).to_have_attribute("aria-pressed", "true")
                    guest.locator("#refresh-menu").click()
                    expect(guest.locator(".add-button")).to_be_enabled()
                    guest.locator("#menu-search").fill("Fresh garden Lentil")
                    expect(guest.locator(".product-card")).to_have_count(0)
                    guest.locator("#menu-search").fill("κοτοπουλο")
                    expect(guest.locator(".product-card").first).to_be_visible()
                    grouped = next(p for p in menu["products"] if p.get("option_groups"))
                    guest.locator("#menu-search").fill(grouped["name"])
                    grouped_card = guest.locator(f'[data-product-id="{grouped["id"]}"]')
                    expect(grouped_card.locator(".add-button")).to_be_disabled()
                    for group in grouped["option_groups"]:
                        grouped_card.locator(f'#option-{grouped["id"]}-{group["id"]}').select_option(group["options"][0]["id"])
                    expect(grouped_card.locator(".add-button")).to_be_enabled()
                    grouped_card.locator(".add-button").click()
                    guest.locator("#customer-name").fill("Δοκιμή Επιλογών")
                    guest.locator("#customer-phone").fill("6923456789")
                    guest.locator("#checkout-button").click()
                    expect(guest.locator("#tracking-status")).to_have_text("Αναμονή αποδοχής")

                    # Staff can exercise a full day of tests without weakening public abuse limits.
                    for number in range(25):
                        response = admin.request.post(origin + "/api/admin/test-orders", headers={"Origin": origin, "Idempotency-Key": uuid.uuid4().hex}, data={"customer_name": "Δοκιμή Ιστορικού", "phone": str(6900001000 + number), "fulfillment": "pickup", "items": [{"product_id": coffee["id"], "variant_id": second["id"], "option_ids": {}, "quantity": 1, "notes": ""}], "notes": ""})
                        assert response.status == 201, response.text()
                    admin.locator('[data-status="PENDING"]').click()
                    expect(admin.locator(".order-card")).to_have_count(24)
                    expect(admin.locator("#page-summary")).to_contain_text("από 27")
                    admin.locator("#next-page").click()
                    expect(admin.locator(".order-card")).to_have_count(3)
                    expect(admin.locator("#page-summary")).to_contain_text("25–27")
                    admin.locator("#previous-page").click()
                    expect(admin.locator(".order-card")).to_have_count(24)
                    # A staff-session expiry after a lost reply must retain the same key.
                    staff_page = admin.context.new_page()
                    staff_page.on("pageerror", lambda error: errors.append(str(error)))
                    staff_page.goto(origin)
                    expect(staff_page.locator("#staff-test-hint")).to_be_visible()
                    staff_page.locator("#menu-search").fill("Freddo Espresso")
                    staff_lost = []

                    def lose_staff_reply(route):
                        if not staff_lost:
                            reply = route.fetch()
                            assert reply.status == 201
                            staff_lost.append(reply.json()["order"])
                            route.abort("failed")
                        else:
                            route.continue_()

                    staff_page.route("**/api/admin/test-orders", lose_staff_reply)
                    staff_page.locator(".add-button").click()
                    staff_page.locator("#customer-name").fill("Δοκιμή Λήξης Σύνδεσης")
                    staff_page.locator("#customer-phone").fill("6934567890")
                    staff_page.locator("#checkout-button").click()
                    expect(staff_page.locator("#checkout-message")).to_contain_text("Το αποτέλεσμα είναι άγνωστο")
                    pending_key = staff_page.evaluate("JSON.parse(sessionStorage.getItem('mia-pending-submission')).key")
                    logout = admin.request.post(origin + "/api/admin/logout", headers={"Origin": origin})
                    assert logout.status == 200
                    staff_page.locator("#checkout-button").click()
                    expect(staff_page.locator("#checkout-message")).to_contain_text("Συνδέσου ξανά")
                    assert staff_page.evaluate("JSON.parse(sessionStorage.getItem('mia-pending-submission')).key") == pending_key
                    staff_page.reload()
                    expect(staff_page.locator("#checkout-message")).to_contain_text("Βρέθηκε αποστολή")
                    admin.reload()
                    admin.locator("#username").fill("admin")
                    admin.locator("#password").fill(password)
                    admin.locator("#login-button").click()
                    expect(admin.locator("#dashboard")).to_be_visible()
                    staff_page.locator("#checkout-button").click()
                    expect(staff_page.locator("#tracking-number")).to_contain_text(f"#{staff_lost[0]['number']}")
                    assert staff_page.evaluate("sessionStorage.getItem('mia-pending-submission')") is None
                    staff_page.close()
                    assert guest.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
                    if args.screenshots:
                        guest.screenshot(path=str(args.screenshots / "customer-mobile.png"))
                    cache_urls = guest.evaluate("""async () => {
                        const keys = await caches.keys();
                        const requests = await Promise.all(keys.map(async key => (await caches.open(key)).keys()));
                        return requests.flat().map(request => request.url);
                    }""")
                    assert all("/static/" in url for url in cache_urls), cache_urls
                    assert not errors, errors
                    print("PASS: real123catalog/215variants, search, variantpricing, separatecartlines")
                    print("PASS: checkout, staff login, receipt, CSV, accept, complete, customer tracking")
                    print("PASS: lost-response retries survive reload and staff-session expiry without duplicates")
                    print("PASS: pause/resume, persisted availability and stale-cart checkout protection")
                    print("PASS: required options, staff repeat testing and paginated full history")
                    print("PASS: mobile width, static-only PWA cache, no JavaScript page errors")
                finally:
                    browser.close()
        finally:
            server.should_exit = True
            thread.join(timeout=5)


if __name__ == "__main__":
    main()
