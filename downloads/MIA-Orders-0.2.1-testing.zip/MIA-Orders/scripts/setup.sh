#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"
MIA_VENV_PATH="${MIA_VENV_PATH:-$PROJECT_ROOT/.venv}"
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-$MIA_VENV_PATH/.pip-cache}"
python3 -c 'import sys; assert sys.version_info >= (3, 12), "Python 3.12 or newer is required"'
if [[ ! -x "$MIA_VENV_PATH/bin/python" ]]; then
  python3 -m venv "$MIA_VENV_PATH"
fi
"$MIA_VENV_PATH/bin/python" -m pip install -r requirements-dev.txt
"$MIA_VENV_PATH/bin/python" -m pip check
echo 'Dependencies installed. Set a staff password using python -m mia.cli init-admin in this virtual environment.'
