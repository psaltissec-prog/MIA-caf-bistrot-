#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"
MIA_VENV_PATH="${MIA_VENV_PATH:-$PROJECT_ROOT/.venv}"
if [[ ! -x "$MIA_VENV_PATH/bin/python" ]]; then
  echo 'Run bash scripts/setup.sh first (or set MIA_VENV_PATH).' >&2
  exit 1
fi
# The Python desktop runner parses private settings as data; never source/eval files.
# Cloud startup stays noninteractive. The owner launcher initializes staff on first use.
exec "$MIA_VENV_PATH/bin/python" -m mia.desktop --no-browser --skip-admin-init
