"""Consistent SQLite backup while the application is running. No customer data is printed."""

import argparse
import os
import sqlite3
from datetime import UTC, datetime
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", default=os.environ.get("MIA_DB_PATH", "runtime/mia.sqlite3"))
    parser.add_argument("--directory", default="backups")
    args = parser.parse_args()
    source = Path(args.database).resolve(strict=True)
    directory = Path(args.directory)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S.%fZ")
    target = directory / f"mia-{stamp}.sqlite3"
    # Exclusive creation prevents overwriting previous backups; permissions precede writing data.
    descriptor = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(descriptor)
    try:
        with sqlite3.connect(source.as_uri() + "?mode=ro", uri=True) as src:
            with sqlite3.connect(target) as dst:
                src.backup(dst)
                if dst.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise RuntimeError("Backup integrity check failed")
    except Exception:
        target.unlink(missing_ok=True)
        raise
    print(f"Backup verified: {target}")


if __name__ == "__main__":
    main()
