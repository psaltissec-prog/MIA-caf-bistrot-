@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 (
    py -3.12 "%~dp0START_MIA_ORDERS.py" %*
    goto done
)
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0START_MIA_ORDERS.py" %*
    goto done
)
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 (
    python "%~dp0START_MIA_ORDERS.py" %*
    goto done
)
echo Python 3.12 or newer was not found.
echo Install Python from https://www.python.org/downloads/windows/ and enable the Python launcher.
echo Then run START_MIA_ORDERS.bat again.
pause
exit /b 1
:done
set "MIA_EXIT_CODE=%errorlevel%"
if not "%MIA_EXIT_CODE%"=="0" (
    echo.
    echo MIA stopped with an error. Read the message above; existing data was not replaced.
    pause
)
exit /b %MIA_EXIT_CODE%
