"""HTTP API and static application entry point."""
import asyncio
import csv
import hashlib
import hmac
import io
import json
import logging
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager, suppress
from copy import deepcopy
from datetime import UTC, datetime
from html import escape
from pathlib import Path
from typing import Callable, Literal
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictInt, field_validator

from .catalog import STORE, load_catalog
from .config import Settings
from .db import Database, serialize_order
from .security import order_token, token_digest, verify_password

logger = logging.getLogger("mia")
STATIC = Path(__file__).parent / "static"
COOKIE = "mia_session"
MAX_BODY_BYTES = 16 * 1024


class InputModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class ItemInput(InputModel):
    product_id: str = Field(min_length=1, max_length=80)
    variant_id: str = Field(default="", max_length=80)
    option_ids: dict[str, str] = Field(default_factory=dict, max_length=10)
    quantity: StrictInt = Field(ge=1, le=20)
    notes: str = Field(default="", max_length=200)

    @field_validator("option_ids")
    @classmethod
    def validate_options(cls, options):
        if any(not re.fullmatch(r"[a-z0-9_-]{1,80}", key)
               or not re.fullmatch(r"[a-z0-9_-]{1,80}", value)
               for key, value in options.items()):
            raise ValueError("Μη έγκυρη επιλογή προϊόντος")
        return options


class OrderInput(InputModel):
    customer_name: str = Field(min_length=2, max_length=80)
    phone: str = Field(min_length=7, max_length=26)
    fulfillment: Literal["pickup"]
    notes: str = Field(default="", max_length=1000)
    items: list[ItemInput] = Field(min_length=1, max_length=20)
    turnstile_token: str = Field(default="", max_length=2048)

    @field_validator("customer_name")
    @classmethod
    def validate_name(cls, value):
        if any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError("Το όνομα περιέχει μη έγκυρους χαρακτήρες")
        return value

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, value):
        if not re.fullmatch(r"\+?[0-9][0-9 ()-]{6,24}", value):
            raise ValueError("Μη έγκυρο τηλέφωνο")
        digits = re.sub(r"[^0-9]", "", value)
        if value.startswith("00"):
            digits = digits[2:]
        elif len(digits) == 10 and not value.startswith("+"):
            digits = "30" + digits
        if not 10 <= len(digits) <= 15:
            raise ValueError("Μη έγκυρο μήκος τηλεφώνου")
        return "+" + digits


class LoginInput(InputModel):
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=1024)


class TransitionInput(InputModel):
    status: Literal["ACCEPTED", "REJECTED", "COMPLETED"]


class AvailabilityInput(InputModel):
    available: StrictBool


class StoreSettingsInput(InputModel):
    accepting_orders: StrictBool


class SecurityMiddleware:
    """Bound request bodies, enforce same-origin writes and add browser protections."""
    def __init__(self, app, settings: Settings):
        self.app, self.settings = app, settings

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = {key.decode("latin1").lower(): value.decode("latin1") for key, value in scope["headers"]}
        origin = self.settings.public_origin
        hostname = urlsplit(origin).hostname
        allowed_hosts = {hostname}
        if self.settings.environment != "production":
            allowed_hosts |= {"127.0.0.1", "localhost", "testserver"}
        try:
            supplied = urlsplit("//" + headers.get("host", ""))
            supplied.port  # Validate a supplied port even though host matching ignores it.
            supplied_host = supplied.hostname
            if supplied.username or supplied.password or supplied.path or supplied.query or supplied.fragment:
                supplied_host = None
        except ValueError:
            supplied_host = None

        async def secured_send(message):
            if message["type"] == "http.response.start":
                response_headers = list(message.get("headers", []))
                response_headers.extend([
                    (b"x-content-type-options", b"nosniff"),
                    (b"referrer-policy", b"no-referrer"),
                    (b"x-frame-options", b"DENY"),
                    (b"permissions-policy", b"camera=(), microphone=(), geolocation=()"),
                    (b"content-security-policy", (
                        "default-src 'self'; script-src 'self' https://challenges.cloudflare.com; "
                        "style-src 'self'; img-src 'self' data:; connect-src 'self' https://challenges.cloudflare.com; "
                        "frame-src https://challenges.cloudflare.com; object-src 'none'; "
                        "base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
                    ).encode()),
                ])
                if scope["path"].startswith("/api/"):
                    response_headers.append((b"cache-control", b"no-store"))
                if self.settings.environment == "production":
                    response_headers.append((b"strict-transport-security", b"max-age=31536000"))
                message = dict(message, headers=response_headers)
            await send(message)

        async def reject(status, message):
            await JSONResponse({"detail": message}, status_code=status)(scope, receive, secured_send)

        if supplied_host not in allowed_hosts:
            return await reject(400, "Μη επιτρεπόμενος host")
        body = b""
        if scope["method"] in {"POST", "PUT", "PATCH", "DELETE"}:
            if headers.get("origin") != origin or headers.get("sec-fetch-site") == "cross-site":
                return await reject(403, "Μη επιτρεπόμενη προέλευση αιτήματος")
            while True:
                message = await receive()
                if message["type"] == "http.disconnect":
                    return
                body += message.get("body", b"")
                if len(body) > MAX_BODY_BYTES:
                    return await reject(413, "Το αίτημα είναι πολύ μεγάλο")
                if not message.get("more_body", False):
                    break
            delivered = False

            async def replay():
                nonlocal delivered
                if not delivered:
                    delivered = True
                    return {"type": "http.request", "body": body, "more_body": False}
                return await receive()
            return await self.app(scope, replay, secured_send)
        await self.app(scope, receive, secured_send)


def create_app(settings: Settings | None = None, *, clock: Callable[[], float] = time.time) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.validate()
    database = Database(settings.db_path)
    catalog = load_catalog()
    product_map = {product["id"]: product for product in catalog}
    local_timezone = ZoneInfo("Europe/Athens")

    def now():
        return int(clock())

    def reconcile():
        with database.transaction() as connection:
            database.expire(connection, now())
            connection.execute("DELETE FROM sessions WHERE expires_at<=?", (now(),))

    @asynccontextmanager
    async def lifespan(application):
        database.initialize()
        credential_fingerprint = token_digest(settings.admin_username + "\0" + settings.admin_password_hash)
        with database.transaction() as connection:
            previous = connection.execute("SELECT value FROM metadata WHERE key='admin_credential_fingerprint'").fetchone()
            if previous is None or previous[0] != credential_fingerprint:
                connection.execute("DELETE FROM sessions")
                connection.execute(
                    "INSERT INTO metadata(key,value) VALUES ('admin_credential_fingerprint',?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (credential_fingerprint,),
                )
        reconcile()

        async def expiry_loop():
            while True:
                await asyncio.sleep(1)
                try:
                    await asyncio.to_thread(reconcile)
                except sqlite3.Error:
                    logger.error("order_expiry_database_error")

        task = asyncio.create_task(expiry_loop())
        try:
            yield
        finally:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task

    application = FastAPI(title="MIA Orders", version="0.2.0-testing", lifespan=lifespan,
                          docs_url=None, redoc_url=None, openapi_url=None)
    application.state.settings = settings
    application.state.database = database
    application.add_middleware(SecurityMiddleware, settings=settings)

    @application.exception_handler(RequestValidationError)
    async def invalid_input(request, error):
        # Never echo passwords, submitted names or phones into validation errors.
        errors = [{"loc": item["loc"], "msg": item["msg"], "type": item["type"]} for item in error.errors()]
        return JSONResponse({"detail": errors}, status_code=422)

    @application.exception_handler(sqlite3.Error)
    async def database_error(request, error):
        logger.error("database_operation_failed")
        return JSONResponse({"detail": "Προσωρινή αδυναμία αποθήκευσης. Δοκιμάστε ξανά."}, status_code=503)

    def ip_key(request: Request, category: str):
        # Forwarded headers are deliberately ignored unless a trusted proxy is configured separately.
        ip = request.client.host if request.client else "unknown"
        return category + ":" + token_digest(ip)

    def rate(request: Request, category: str, limit: int, seconds: int):
        if not database.consume_rate(ip_key(request, category), now(), limit, seconds):
            raise HTTPException(429, "Πάρα πολλές προσπάθειες. Δοκιμάστε αργότερα.", headers={"Retry-After": str(seconds)})

    def admin(request: Request):
        token = request.cookies.get(COOKIE, "")
        if not token or len(token) > 256:
            raise HTTPException(401, "Απαιτείται σύνδεση διαχειριστή")
        with database.transaction() as connection:
            row = connection.execute("SELECT username FROM sessions WHERE token_hash=? AND expires_at>?",
                                     (token_digest(token), now())).fetchone()
        if not row:
            raise HTTPException(401, "Η συνεδρία έληξε. Συνδεθείτε ξανά.")
        return row["username"]

    def accepting_orders(connection) -> bool:
        row = connection.execute(
            "SELECT value FROM store_settings WHERE key='accepting_orders'"
        ).fetchone()
        return row is None or row["value"] == "true"

    def available_products(connection) -> list[dict]:
        products = deepcopy(catalog)
        overrides = {
            row["product_id"]: bool(row["available"])
            for row in connection.execute("SELECT product_id,available FROM catalog_overrides")
        }
        for product in products:
            if product["id"] in overrides:
                product["available"] = overrides[product["id"]]
        return products

    def business_status(connection) -> dict:
        local = datetime.fromtimestamp(now(), UTC).astimezone(local_timezone)
        local_time = local.strftime("%H:%M")
        is_open = local.isoweekday() in STORE["opening_days"] and (
            STORE["opening_time"] <= local_time < STORE["closing_time"]
        )
        return {
            "accepting_orders": accepting_orders(connection),
            "is_open": is_open,
            "outside_hours_testing_allowed": True,
        }

    @application.get("/api/health")
    def health():
        with database.transaction() as connection:
            connection.execute("SELECT 1").fetchone()
            database.expire(connection, now())
            installation_id = connection.execute(
                "SELECT value FROM metadata WHERE key='installation_id'"
            ).fetchone()[0]
        return {"status": "ok", "service": "mia-orders", "version": "0.2.0-testing",
                "installation_id": installation_id, "public_origin": settings.public_origin, "demo": True,
                "live_orders": False, "server_time": now()}

    @application.get("/api/menu")
    def menu():
        with database.transaction() as connection:
            store = STORE | business_status(connection) | {
                "turnstile_site_key": settings.turnstile_site_key
            }
            products = available_products(connection)
        return {"store": store, "products": products, "server_time": now()}

    async def verify_turnstile(token: str):
        if not settings.turnstile_secret:
            return
        if not token:
            raise HTTPException(400, "Απαιτείται επαλήθευση ασφαλείας")
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.post("https://challenges.cloudflare.com/turnstile/v0/siteverify",
                                             data={"secret": settings.turnstile_secret, "response": token})
                response.raise_for_status()
                result = response.json()
        except (httpx.HTTPError, ValueError):
            raise HTTPException(503, "Η επαλήθευση ασφαλείας δεν είναι διαθέσιμη") from None
        if (not isinstance(result, dict) or result.get("success") is not True
                or result.get("hostname") != urlsplit(settings.public_origin).hostname):
            raise HTTPException(400, "Η επαλήθευση ασφαλείας απέτυχε")

    @application.post("/api/orders")
    async def create_order(payload: OrderInput, request: Request,
                           idempotency_key: str = Header(default="", alias="Idempotency-Key")):
        if not re.fullmatch(r"[A-Za-z0-9_-]{24,128}", idempotency_key):
            raise HTTPException(400, "Απαιτείται έγκυρο Idempotency-Key τουλάχιστον 24 χαρακτήρων")
        # Token consumption is excluded from the stable business-payload hash.
        canonical = payload.model_dump(exclude={"turnstile_token"})
        # Preserve the original request identity for a pre-upgrade pending retry.
        for item in canonical["items"]:
            if not item["variant_id"]:
                item.pop("variant_id")
            if not item["option_ids"]:
                item.pop("option_ids")
        request_hash = hashlib.sha256(json.dumps(canonical, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        idem_hash = token_digest(idempotency_key)

        def existing_response(connection, row):
            if not hmac.compare_digest(row["request_hash"], request_hash):
                raise HTTPException(409, "Το κλειδί έχει ήδη χρησιμοποιηθεί για άλλη παραγγελία")
            secret = connection.execute("SELECT value FROM metadata WHERE key='order_secret'").fetchone()[0]
            return {"order": serialize_order(row), "access_token": order_token(secret, row["id"]),
                    "server_time": now()}

        with database.transaction() as connection:
            database.expire(connection, now())
            existing = connection.execute("SELECT * FROM orders WHERE idempotency_hash=?", (idem_hash,)).fetchone()
            if existing:
                return JSONResponse(existing_response(connection, existing), status_code=200)
            if not accepting_orders(connection):
                raise HTTPException(503, "Οι παραγγελίες έχουν προσωρινά παγώσει από το κατάστημα")
        staff_test_order = bool(getattr(request.state, "staff_test_order", False))
        rate(request, "staff-test-order" if staff_test_order else "order",
             120 if staff_test_order else 30, 600)
        await verify_turnstile(payload.turnstile_token)
        items, quantity, total, seen = [], 0, 0, set()
        for item in payload.items:
            product = product_map.get(item.product_id)
            if not product or not product["available"]:
                raise HTTPException(422, "Μη διαθέσιμο προϊόν")
            variants = product["variants"]
            selected_variant = item.variant_id or variants[0]["id"]
            variant = next((v for v in variants if v["id"] == selected_variant), None)
            if variant is None:
                raise HTTPException(422, "Μη έγκυρο μέγεθος προϊόντος")
            groups = {group["id"]: group for group in product.get("option_groups", [])}
            if any(group_id not in groups for group_id in item.option_ids):
                raise HTTPException(422, "Μη έγκυρη ομάδα επιλογής προϊόντος")
            selected_labels = []
            for group_id, group in groups.items():
                selection = item.option_ids.get(group_id)
                if selection is None:
                    if group["required"]:
                        raise HTTPException(422, f"Επιλέξτε: {group['label']}")
                    continue
                option = next((option for option in group["options"] if option["id"] == selection), None)
                if option is None:
                    raise HTTPException(422, "Μη έγκυρη επιλογή προϊόντος")
                selected_labels.append(option["label"])
            identity = (item.product_id, variant["id"], tuple(sorted(item.option_ids.items())), item.notes)
            if identity in seen:
                raise HTTPException(422, "Συγχωνεύστε τις ποσότητες της ίδιας επιλογής προϊόντος")
            seen.add(identity)
            quantity += item.quantity
            unit_price = variant["price_cents"]
            total += unit_price * item.quantity
            details = ([variant["label"]] if variant["id"] != "standard" else []) + selected_labels
            name = product["name"] + (" · " + ", ".join(details) if details else "")
            items.append({"product_id": item.product_id, "name": name,
                          "variant_id": variant["id"], "variant_label": variant["label"],
                          "option_ids": item.option_ids, "options_label": ", ".join(selected_labels),
                          "quantity": item.quantity, "unit_price_cents": unit_price, "notes": item.notes})
        if quantity > 50 or total > 50000:
            raise HTTPException(422, "Η παραγγελία υπερβαίνει τα δοκιμαστικά όρια")
        order_id = str(uuid.uuid4())
        with database.transaction() as connection:
            timestamp = now()
            database.expire(connection, timestamp)
            existing = connection.execute("SELECT * FROM orders WHERE idempotency_hash=?", (idem_hash,)).fetchone()
            if existing:
                return JSONResponse(existing_response(connection, existing), status_code=200)
            if not accepting_orders(connection):
                raise HTTPException(503, "Οι παραγγελίες έχουν προσωρινά παγώσει από το κατάστημα")
            overrides = {
                row["product_id"]: bool(row["available"])
                for row in connection.execute("SELECT product_id,available FROM catalog_overrides")
            }
            if any(not overrides.get(item["product_id"], True) for item in items):
                raise HTTPException(422, "Μη διαθέσιμο προϊόν: ανανεώστε το μενού")
            count = connection.execute("SELECT count(*) FROM orders WHERE phone=? AND created_at>?",
                                       (payload.phone, timestamp - 600)).fetchone()[0]
            if count >= 3 and not staff_test_order:
                raise HTTPException(429, "Έως 3 νέες δοκιμαστικές παραγγελίες ανά 10 λεπτά", headers={"Retry-After": "600"})
            connection.execute(
                "INSERT INTO orders (id,customer_name,phone,fulfillment,notes,items_json,total_cents,status,"
                "created_at,expires_at,updated_at,idempotency_hash,request_hash) "
                "VALUES (?,?,?,?,?,?,?,'PENDING',?,?,?,?,?)",
                (order_id, payload.customer_name, payload.phone, payload.fulfillment, payload.notes,
                 json.dumps(items, ensure_ascii=False), total, timestamp, timestamp + 300, timestamp, idem_hash, request_hash),
            )
            connection.execute("INSERT INTO order_events(order_id,status,created_at) VALUES (?,'PENDING',?)", (order_id, timestamp))
            row = connection.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            response = existing_response(connection, row)
        return JSONResponse(response, status_code=201)

    @application.post("/api/admin/test-orders")
    async def create_staff_test_order(payload: OrderInput, request: Request,
                                     idempotency_key: str = Header(default="", alias="Idempotency-Key"),
                                     username: str = Depends(admin)):
        # State is set only after staff authentication, never from a client header.
        request.state.staff_test_order = True
        return await create_order(payload, request, idempotency_key)

    @application.get("/api/orders/{order_id}")
    def get_order(order_id: str, request: Request, authorization: str = Header(default="")):
        rate(request, "status", 120, 60)
        with database.transaction() as connection:
            database.expire(connection, now())
            secret = connection.execute("SELECT value FROM metadata WHERE key='order_secret'").fetchone()[0]
            supplied = authorization.removeprefix("Bearer ") if authorization.startswith("Bearer ") else ""
            valid = hmac.compare_digest(order_token(secret, order_id).encode(), supplied.encode())
            row = connection.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone() if valid else None
            if not row:
                raise HTTPException(404, "Η παραγγελία δεν βρέθηκε")
            return {"order": serialize_order(row), "server_time": now()}

    @application.post("/api/admin/login")
    def login(payload: LoginInput, request: Request):
        rate(request, "login", 10, 900)
        if not settings.admin_password_hash:
            raise HTTPException(503, "Ο διαχειριστής δεν έχει ρυθμιστεί ακόμη")
        valid = verify_password(payload.password, settings.admin_password_hash)
        if not valid or not hmac.compare_digest(payload.username.encode(), settings.admin_username.encode()):
            raise HTTPException(401, "Μη έγκυρα στοιχεία σύνδεσης")
        token = secrets.token_urlsafe(32)
        with database.transaction() as connection:
            connection.execute("DELETE FROM sessions WHERE expires_at<=?", (now(),))
            old_token = request.cookies.get(COOKIE)
            if old_token:
                connection.execute("DELETE FROM sessions WHERE token_hash=?", (token_digest(old_token),))
            connection.execute("INSERT INTO sessions VALUES (?,?,?)", (token_digest(token), settings.admin_username, now() + settings.session_seconds))
        response = JSONResponse({"authenticated": True, "username": settings.admin_username})
        response.set_cookie(COOKIE, token, max_age=settings.session_seconds,
                            httponly=True, secure=settings.secure_cookie, samesite="strict", path="/api/admin")
        return response

    @application.get("/api/admin/session")
    def session(username: str = Depends(admin)):
        return {"authenticated": True, "username": username}

    @application.post("/api/admin/logout")
    def logout(request: Request, username: str = Depends(admin)):
        with database.transaction() as connection:
            connection.execute("DELETE FROM sessions WHERE token_hash=?", (token_digest(request.cookies[COOKIE]),))
        response = JSONResponse({"authenticated": False})
        response.delete_cookie(COOKIE, path="/api/admin", secure=settings.secure_cookie, httponly=True, samesite="strict")
        return response

    @application.get("/api/admin/menu")
    def admin_menu(username: str = Depends(admin)):
        with database.transaction() as connection:
            products = available_products(connection)
        return {"products": products, "server_time": now()}

    @application.post("/api/admin/menu/{product_id}")
    def update_availability(product_id: str, payload: AvailabilityInput, username: str = Depends(admin)):
        if product_id not in product_map:
            raise HTTPException(404, "Το προϊόν δεν βρέθηκε")
        with database.transaction() as connection:
            connection.execute(
                "INSERT INTO catalog_overrides(product_id,available,updated_at,updated_by) VALUES (?,?,?,?) "
                "ON CONFLICT(product_id) DO UPDATE SET available=excluded.available, "
                "updated_at=excluded.updated_at,updated_by=excluded.updated_by",
                (product_id, int(payload.available), now(), username),
            )
        return {"product_id": product_id, "available": payload.available, "server_time": now()}

    @application.get("/api/admin/settings")
    def admin_settings(username: str = Depends(admin)):
        with database.transaction() as connection:
            status = business_status(connection)
        return status | {"server_time": now()}

    @application.post("/api/admin/settings")
    def update_store_settings(payload: StoreSettingsInput, username: str = Depends(admin)):
        with database.transaction() as connection:
            connection.execute(
                "INSERT INTO store_settings(key,value,updated_at,updated_by) "
                "VALUES ('accepting_orders',?,?,?) ON CONFLICT(key) DO UPDATE SET "
                "value=excluded.value,updated_at=excluded.updated_at,updated_by=excluded.updated_by",
                ("true" if payload.accepting_orders else "false", now(), username),
            )
            status = business_status(connection)
        return status | {"server_time": now()}

    @application.get("/api/admin/orders")
    def orders(status: Literal["PENDING", "ACCEPTED", "REJECTED", "COMPLETED"] | None = None,
               offset: int = Query(default=0, ge=0, le=10_000_000),
               limit: int = Query(default=500, ge=1, le=500), username: str = Depends(admin)):
        with database.transaction() as connection:
            database.expire(connection, now())
            counts = {state: 0 for state in ("PENDING", "ACCEPTED", "REJECTED", "COMPLETED")}
            for row in connection.execute("SELECT status,count(*) AS total FROM orders GROUP BY status"):
                counts[row["status"]] = row["total"]
            if status:
                rows = connection.execute(
                    "SELECT * FROM orders WHERE status=? ORDER BY created_at DESC,number DESC LIMIT ? OFFSET ?",
                    (status, limit, offset),
                ).fetchall()
                total = counts[status]
            else:
                rows = connection.execute(
                    "SELECT * FROM orders ORDER BY created_at DESC,number DESC LIMIT ? OFFSET ?", (limit, offset)
                ).fetchall()
                total = sum(counts.values())
            pending_ids = [row["id"] for row in connection.execute(
                "SELECT id FROM orders WHERE status='PENDING' ORDER BY number DESC LIMIT 500"
            )]
            return {"orders": [serialize_order(row) for row in rows], "server_time": now(),
                    "offset": offset, "limit": limit, "total": total,
                    "counts": counts, "pending_ids": pending_ids}

    @application.post("/api/admin/orders/{order_id}/transition")
    def transition(order_id: str, payload: TransitionInput, username: str = Depends(admin)):
        failure = None
        result = None
        with database.transaction() as connection:
            # Read time after taking the write lock: lock waits cannot extend the deadline.
            timestamp = now()
            database.expire(connection, timestamp)
            row = connection.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            if not row:
                failure = HTTPException(404, "Η παραγγελία δεν βρέθηκε")
            else:
                allowed = {"PENDING": {"ACCEPTED", "REJECTED"}, "ACCEPTED": {"COMPLETED"}}
                if payload.status not in allowed.get(row["status"], set()):
                    failure = HTTPException(409, "Η παραγγελία έχει ήδη αλλάξει κατάσταση ή έχει λήξει")
                else:
                    reason = "MANUAL" if payload.status == "REJECTED" else None
                    connection.execute("UPDATE orders SET status=?,updated_at=?,rejected_at=?,rejection_reason=? WHERE id=?",
                                       (payload.status, timestamp, timestamp if reason else None, reason, order_id))
                    connection.execute("INSERT INTO order_events(order_id,status,reason,created_at) VALUES (?,?,?,?)",
                                       (order_id, payload.status, reason, timestamp))
                    updated = connection.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
                    result = {"order": serialize_order(updated)}
        # Expiration is durable even when the requested transition fails.
        if failure:
            raise failure
        return result

    def safe_cell(value):
        value = str(value)
        if value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r", "\n")):
            return "'" + value
        return value

    def csv_response(status: str | None = None):
        with database.transaction() as connection:
            database.expire(connection, now())
            if status:
                rows = connection.execute(
                    "SELECT * FROM orders WHERE status=? ORDER BY number DESC", (status,)
                ).fetchall()
            else:
                rows = connection.execute("SELECT * FROM orders ORDER BY number DESC").fetchall()
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        columns = ["number", "customer_name", "phone", "created_at_unix", "rejected_at_unix",
                   "reason", "total_cents", "items"]
        if status is None:
            columns.extend(["status", "fulfillment", "notes", "demo"])
        writer.writerow(columns)
        for row in rows:
            values = [row["number"], safe_cell(row["customer_name"]), safe_cell(row["phone"]),
                      row["created_at"], row["rejected_at"], row["rejection_reason"], row["total_cents"],
                      safe_cell(row["items_json"])]
            if status is None:
                values.extend([row["status"], row["fulfillment"], safe_cell(row["notes"]), bool(row["demo"])])
            writer.writerow(values)
        filename = "mia-rejected.csv" if status else "mia-orders.csv"
        return Response("\ufeff" + output.getvalue(), media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="{filename}"'})

    @application.get("/api/admin/rejected.csv")
    def rejected_csv(username: str = Depends(admin)):
        return csv_response("REJECTED")

    @application.get("/api/admin/orders.csv")
    def all_orders_csv(username: str = Depends(admin)):
        return csv_response()

    @application.get("/api/admin/orders/{order_id}/receipt")
    def order_receipt(order_id: str, username: str = Depends(admin)):
        with database.transaction() as connection:
            database.expire(connection, now())
            row = connection.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            if row is None:
                raise HTTPException(404, "Η παραγγελία δεν βρέθηκε")
            order = serialize_order(row)
        def html(value):
            return escape(str(value), quote=True)
        def euros(cents):
            return f"{cents // 100},{cents % 100:02d} €"
        created = datetime.fromtimestamp(order["created_at"], UTC).astimezone(local_timezone)
        states = {"PENDING": "Αναμονή αποδοχής", "ACCEPTED": "Σε προετοιμασία",
                  "REJECTED": "Απορρίφθηκε", "COMPLETED": "Ολοκληρώθηκε"}
        item_rows = []
        for item in order["items"]:
            note = f'<p class="receipt-item-notes">{html(item["notes"])}</p>' if item.get("notes") else ""
            item_rows.append(
                f'<tr><td>{html(item["name"])}{note}</td><td>{item["quantity"]}</td>'
                f'<td>{euros(item["unit_price_cents"])}</td>'
                f'<td>{euros(item["unit_price_cents"] * item["quantity"])}</td></tr>'
            )
        body = f"""<!doctype html>
<html lang="el"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Δελτίο παραγγελίας #{order['number']} — MIA</title>
<link rel="stylesheet" href="/static/styles.css"><link rel="stylesheet" href="/static/print.css">
<script type="module" src="/static/print.js"></script></head>
<body class="receipt"><main class="receipt-content"><header class="receipt-header">
<h1>{html(STORE['name'])}</h1><p>{html(STORE['address'])}</p>
<p>Δελτίο δοκιμαστικής παραγγελίας #{order['number']}</p>
<p>ΔΟΚΙΜΑΣΤΙΚΟ — Δεν αποτελεί φορολογικό παραστατικό</p></header>
<p>{created.strftime('%d/%m/%Y %H:%M')} (ώρα Ελλάδας) · {html(states[order['status']])}</p>
<p><strong>Πελάτης:</strong> {html(order['customer_name'])}<br>
<strong>Τηλέφωνο:</strong> {html(order['phone'])}<br>Παραλαβή από το κατάστημα</p>
<table class="receipt-items"><thead><tr><th>Είδος / επιλογές</th><th>Ποσότητα</th><th>Τιμή</th><th>Ποσό</th></tr></thead>
<tbody>{''.join(item_rows)}</tbody></table>
<p class="receipt-total"><strong>Σύνολο: {euros(order['total_cents'])}</strong></p>
<p class="receipt-notes"><strong>Σημειώσεις:</strong> {html(order['notes'])}</p>
<div class="receipt-actions"><button class="button primary" type="button" id="print-receipt">Εκτύπωση δελτίου</button>
<a href="/admin">Επιστροφή στη διαχείριση</a></div></main></body></html>"""
        return Response(body, media_type="text/html; charset=utf-8", headers={"Cache-Control": "no-store"})

    # Static paths are explicit; customer/order data is never included in PWA caches.
    application.mount("/static", StaticFiles(directory=STATIC, check_dir=False), name="static")

    @application.get("/")
    def index():
        return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})

    @application.get("/admin")
    def dashboard():
        return FileResponse(STATIC / "admin.html", headers={"Cache-Control": "no-store"})

    @application.get("/manifest.webmanifest")
    def manifest():
        return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")

    @application.get("/sw.js")
    def service_worker():
        return FileResponse(STATIC / "sw.js", media_type="application/javascript",
                            headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})

    return application


app = create_app()
