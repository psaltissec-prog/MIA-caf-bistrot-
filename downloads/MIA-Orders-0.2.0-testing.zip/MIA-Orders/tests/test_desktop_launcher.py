from __future__ import annotations

import importlib.util
import shlex
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from mia import desktop

BOOTSTRAP_PATH = Path(__file__).resolve().parents[1] / "START_MIA_ORDERS.py"
spec = importlib.util.spec_from_file_location("mia_bootstrap", BOOTSTRAP_PATH)
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)


def write_config(path, username, password_hash):
    path.write_text(
        "export MIA_ADMIN_USERNAME=" + shlex.quote(username) + "\n"
        "export MIA_ADMIN_PASSWORD_HASH=" + shlex.quote(password_hash) + "\n",
        encoding="utf-8",
    )


def test_private_config_is_parsed_as_data_without_executing_shell(tmp_path, password_hash):
    marker = tmp_path / "should-never-exist"
    username = f"$(touch {marker}); ' untrusted literal"
    config = tmp_path / "admin.env"
    write_config(config, username, password_hash)
    values = desktop.load_admin_config(config)
    assert values == {"MIA_ADMIN_USERNAME": username, "MIA_ADMIN_PASSWORD_HASH": password_hash}
    assert not marker.exists()


@pytest.mark.parametrize("contents", [
    "export PATH=/tmp/attacker\n",
    "export MIA_ADMIN_USERNAME=admin\nexport MIA_ADMIN_USERNAME=other\n",
    "export MIA_ADMIN_USERNAME=admin; touch unwanted\n",
    "export MIA_ADMIN_USERNAME='unterminated\n",
    "export MIA_ADMIN_USERNAME=admin\n",
])
def test_unsupported_or_partial_private_config_fails_closed(tmp_path, contents):
    config = tmp_path / "admin.env"
    config.write_text(contents)
    with pytest.raises(ValueError):
        desktop.load_admin_config(config)


def test_missing_config_is_distinct_from_corrupt_config(tmp_path):
    assert desktop.load_admin_config(tmp_path / "not-created.env") == {}
    corrupt = tmp_path / "too-large.env"
    corrupt.write_bytes(b"x" * 17000)
    with pytest.raises(ValueError):
        desktop.load_admin_config(corrupt)


def test_health_identity_requires_matching_local_installation_and_service():
    origin = "http://127.0.0.1:8000"
    identifier = "a" * 32
    health = {"status": "ok", "service": "mia-orders", "version": "0.2.0-testing",
              "installation_id": identifier, "public_origin": origin}
    assert desktop.is_expected_health(health, identifier, origin)
    for altered in (
        health | {"service": "another-service"},
        health | {"installation_id": "b" * 32},
        health | {"public_origin": "http://127.0.0.1:9000"},
        health | {"version": "0.1.0"},
        health | {"status": "starting"},
    ):
        assert not desktop.is_expected_health(altered, identifier, origin)
    assert not desktop.is_expected_health(health, None, origin)


def test_installation_id_reader_accepts_only_valid_public_metadata(tmp_path):
    database = tmp_path / "identity.sqlite3"
    assert desktop.read_installation_id(database) is None
    with sqlite3.connect(database) as connection:
        connection.execute("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT)")
        connection.execute("INSERT INTO metadata VALUES ('installation_id',?)", ("c" * 32,))
    assert desktop.read_installation_id(database) == "c" * 32
    with sqlite3.connect(database) as connection:
        connection.execute("UPDATE metadata SET value='malformed' WHERE key='installation_id'")
    assert desktop.read_installation_id(database) is None


@pytest.mark.parametrize("origin", ["https://remote.example", "http://localhost:8000", "file:///tmp/private"])
def test_readiness_probe_cannot_contact_non_launcher_destination(origin):
    with pytest.raises(ValueError):
        desktop.probe_server(origin)


def test_local_health_redirect_is_not_followed_to_another_destination():
    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            received.append(self.path)
            self.send_response(302)
            self.send_header("Location", "/unexpected-redirect")
            self.end_headers()

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        assert desktop.probe_server(f"http://127.0.0.1:{server.server_port}") is None
        assert received == ["/api/health"]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_unrelated_occupied_port_is_preserved_and_no_server_is_started(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("MIA_PORT", "8765")
    monkeypatch.delenv("MIA_PUBLIC_ORIGIN", raising=False)
    monkeypatch.setattr(desktop, "port_in_use", lambda port: True)
    monkeypatch.setattr(desktop, "probe_server", lambda origin: {"service": "unrelated"})
    monkeypatch.setattr(desktop.subprocess, "Popen", lambda *a, **k: pytest.fail("must not start or stop unrelated service"))
    with pytest.raises(RuntimeError, match="already occupied"):
        desktop.run(tmp_path, no_browser=True, skip_admin_init=True)


def test_warm_runtime_starts_without_installation_or_network(tmp_path, monkeypatch):
    requirements = tmp_path / "requirements.txt"
    requirements.write_text("fastapi==1.2.3\n")
    environment = tmp_path / ".venv"
    environment.mkdir()
    (environment / "pyvenv.cfg").write_text("test environment")
    monkeypatch.setattr(bootstrap, "runtime_ready", lambda python, req: True)
    monkeypatch.setattr(bootstrap.subprocess, "run", lambda *a, **k: pytest.fail("warm runtime must not invoke pip"))
    assert bootstrap.ensure_runtime(tmp_path, environment) == bootstrap.venv_python_path(environment)
    assert (environment / ".mia-runtime.json").is_file()


def test_bootstrap_preserves_nonempty_unknown_runtime_directory(tmp_path):
    (tmp_path / "requirements.txt").write_text("fastapi==1.2.3\n")
    selected = tmp_path / "personal-files"
    selected.mkdir()
    marker = selected / "important.txt"
    marker.write_text("keep me")
    with pytest.raises(RuntimeError, match="not a virtual environment"):
        bootstrap.ensure_runtime(tmp_path, selected)
    assert marker.read_text() == "keep me"


@pytest.mark.parametrize("requirement", ["fastapi>=1", "--index-url=https://unexpected.example", "-r other.txt", "fastapi==1\nfastapi==2"])
def test_launcher_refuses_unpinned_or_interpreted_requirement_text(tmp_path, requirement):
    path = tmp_path / "requirements.txt"
    path.write_text(requirement)
    with pytest.raises(ValueError):
        bootstrap.pinned_requirements(path)


def test_windows_python_path_is_computed_without_assuming_unix_layout(tmp_path):
    assert bootstrap.venv_python_path(tmp_path, windows=True) == tmp_path / "Scripts" / "python.exe"
    assert bootstrap.venv_python_path(tmp_path, windows=False) == tmp_path / "bin" / "python"


def test_startup_backup_preserves_saved_order_and_never_overwrites_previous(settings, order, tmp_path):
    directory = tmp_path / "startup-backups"
    first = desktop.backup_before_start(settings.db_path, directory)
    second = desktop.backup_before_start(settings.db_path, directory)
    assert first != second
    assert first.is_file() and second.is_file()
    assert first.stat().st_mode & 0o777 == 0o600
    with sqlite3.connect(first) as connection:
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        saved = connection.execute("SELECT id,total_cents FROM orders").fetchall()
    assert saved == [(order["order"]["id"], order["order"]["total_cents"])]


def test_corrupt_database_does_not_leave_misleading_backup(tmp_path):
    database = tmp_path / "broken.sqlite3"
    database.write_bytes(b"not a database")
    directory = tmp_path / "backups"
    with pytest.raises(sqlite3.DatabaseError):
        desktop.backup_before_start(database, directory)
    assert list(directory.glob("*.sqlite3")) == []
