"""Build a source release with a complete hash manifest and no local private data."""

import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

VERSION = "0.2.0-testing"
ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "README.md", "START_HERE.txt", "START_MIA_ORDERS.py", "START_MIA_ORDERS.bat",
    ".gitignore", "pyproject.toml", "requirements.txt", "requirements-dev.txt",
    "requirements-browser.txt",
)
DIRECTORIES = ("mia", "docs", "scripts", "tests", "data/menu", ".github")
PRIVATE_PARTS = {"runtime", "backups", ".venv", ".git", "__pycache__", ".pytest_cache", ".ruff_cache"}


def permitted(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    return (
        not any(part in PRIVATE_PARTS for part in relative.parts)
        and not path.name.startswith(".env")
        and path.name != "admin.env"
        and path.suffix not in {".pyc", ".pyo", ".db", ".sqlite3", ".log"}
        and ".sqlite3-" not in path.name
    )


def build(output: Path) -> dict:
    if output.exists():
        raise FileExistsError("Release already exists; choose a new output name to preserve it")
    paths = {ROOT / name for name in FILES}
    for directory in DIRECTORIES:
        paths.update(path for path in (ROOT / directory).rglob("*") if path.is_file() and permitted(path))
    for path in paths:
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError("Release inputs must be regular files within the project")
    catalog = json.loads((ROOT / "data/menu/catalog.json").read_text(encoding="utf-8"))
    current = json.loads((ROOT / "data/menu/menu-current.json").read_text(encoding="utf-8"))
    if catalog["source_sha256"] != current["sha256"]:
        raise ValueError("Release catalogue does not match the current menu source")
    manifest = {
        "version": VERSION,
        "package_type": "local-testing-tool",
        "live_orders": False,
        "real_menu_imported_into_application": True,
        "catalog_products": catalog["product_count"],
        "catalog_price_options": catalog["price_option_count"],
        "files": {},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        with ZipFile(output, "x", ZIP_DEFLATED) as archive:
            for path in sorted(paths):
                relative = path.relative_to(ROOT).as_posix()
                content = path.read_bytes()
                manifest["files"][relative] = hashlib.sha256(content).hexdigest()
                archive.writestr("MIA-Orders/" + relative, content)
            archive.writestr("MIA-Orders/RELEASE-MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        with ZipFile(output) as archive:
            if archive.testzip() is not None:
                raise ValueError("Release ZIP integrity check failed")
            for relative, expected in manifest["files"].items():
                actual = hashlib.sha256(archive.read("MIA-Orders/" + relative)).hexdigest()
                if actual != expected:
                    raise ValueError("Release hash manifest verification failed")
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix + ".sha256").write_text(digest + "  " + output.name + "\n", encoding="utf-8")
    return {"path": str(output), "files": len(manifest["files"]) + 1, "sha256": digest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
